###############################################################################
## ejecutar_proceso.py - punto de entrada del endpoint "submit":
## - Importación de librerías
## - Inicializacion de variables de configuracion
## - Inicialización del logger
## - Cambio de status a PROCESANDO
## - Obtención de parámetros de entrada enviados por consola
## - Llamado al proceso principal
###############################################################################
# Importación de librerías
import os
import sys
import traceback
from datetime import datetime

from main_data_science import *

currentdir = os.path.dirname(os.path.realpath(__file__))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir)

from data import data_blob_storage as dbs
from functions import functions_blob_storage as f_blob
from functions import functions_logger
from functions import functions_utils as utils

# Constantes
CTE_status_PROCESANDO = "PROCESANDO"
CTE_status_STANDBY = "STANDBY"

# Lectura de parámetros enviados por consola
if len(sys.argv) > 1:
    ambiente = sys.argv[1]
else:
    ambiente = "DEV"

# Inicialización del logger
logger_name = "ejecucion_api"
logger_path_cfgs = "../config/config_api_logger.yml"
p_logger = functions_logger.crear_logger(
    logger_name=logger_name, config_file=logger_path_cfgs
)
p_logger.info("[__init__] Inicia")

# Inicialización de variables de configuración
cfgs = {}
cfgs["logger_name"] = logger_name  # nombre del logger
cfgs["path_cfg_loggers"] = logger_path_cfgs  # config logger
cfgs["conf_arc_blob"] = "../config/config_archivos_blob.yml"
cfgs["conf_api"] = "../config/config_api.yml"
cfgs["ambiente"] = ambiente
config_strg = utils.leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])
config_api = utils.leer_configuracion(cfgs["conf_api"], cfgs["ambiente"])

# Asignación de la variable de configuración en todos los modulos usados
dbs.cfgs = cfgs
utils.cfgs = cfgs
f_blob.cfgs = cfgs

try:
    # Cambio de status de la API a PROCESANDO. El cliente monitorea este estado
    # para saber si la API sigue procesando
    utils.change_fflag_status(CTE_status_PROCESANDO)

    # Copia de datos desde el Blob Storage a la carpetas local
    files = dbs.download_data_from_blob_storage()

    for fileName in files:
        p_logger.debug(f"""[__init__] archivo: {fileName}.""")
        # RUNID = '20220323165700_diego.gallart@ypf.com'
        RUNID = fileName.replace("_predecir.csv", "")

        # Llamado a la función principal
        predict(RUNID)

except:
    msg = f"Se produjo un error ejecutando el proceso. Error: {traceback.format_exc()}"
    p_logger.error(msg)
    msg = f"Se produjo un error ejecutando el proceso. Revise el archivo del log."
    mail_dest = config_api["mail_dest"]
    param_post_url = config_api["param_post_url"]
    functions_logger.logger_and_mail(
        p_logger, "error", msg, mail_dest, "Error Loma_Campana_API", msg, param_post_url
    )


# Comprime el directorio generado por la predicción para enviarlo al usuario
output_path = config_strg["path_folder_data"] + config_strg["path_output"] + RUNID
p_logger.debug(f"""[__init__] comprimir_directorio: {output_path}.""")
utils.comprimir_directorio(output_path, output_path)

# Copia de datos desde la carpeta local al Blob Storage
dbs.upload_data_to_blob_storage(RUNID + "/")

# Cambio de status de la API a STANDBY. El cliente monitorea este estado
# para saber si la API terminó el proceso
utils.change_fflag_status(CTE_status_STANDBY)

# Almacenamiento del log en el Blob Storage
p_logger.info("[__init__] Finaliza")
dbs.upload_log_to_blob_storage()
