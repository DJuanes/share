# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 11:47:31 2022

@author: RY25063
"""
import logging
import os
import sys

import pandas as pd
import yaml
from yaml.loader import SafeLoader


def predict(RUNID):
    # Open the file and load the file
    with open("../config/config_ds.yml") as f:
        Paths = yaml.load(f, Loader=SafeLoader)

    # Realative path
    relativo = "../../"
    InputDir = (
        relativo + Paths["InputDir"]
    )  # Directorio de donde se toman los csv de entrada con su nombre ya con el RUNID
    OutputDir = (
        relativo + Paths["OutputDir"]
    )  # Directorio de donde se creará una carpeta con el RUNID y la salida de la ejecución
    ProcessedDir = (
        relativo + Paths["ProcessedDir"]
    )  # Directorio para poner los archivos procesados
    ModelDir = (
        relativo + Paths["ModelDir"]
    )  # Directorio donde están los modelos en formato pkl

    # RUNID= '20220323165700_diego.gallart@ypf.com'
    # RootDir = 'C:/Users/ry25063/Documents/GitHub/LomaCampana_JJ/Fase3/Loma_Campana_REPO_INGDATOS'
    objetivo = "Np_210d_Kbbl_Norm_1000m"

    # Crear directorio en output
    try:
        os.mkdir(OutputDir + "/" + RUNID)
    except:
        pass

    # Log file
    logfile = OutputDir + "/" + RUNID + "/" + RUNID + ".log"
    logname = "DS_log"
    loglevel = logging.INFO
    formatter = logging.Formatter("%(asctime)s :: %(levelname)s :: %(message)s")
    handler = logging.FileHandler(logfile)
    handler.setFormatter(formatter)
    logger = logging.getLogger(logname)
    logger.setLevel(loglevel)
    logger.addHandler(handler)
    # for handler in logging.root.handlers[:]:
    #    logging.root.removeHandler(handler)

    logger.info("INICIA PROCESO :" + RUNID)

    # Datos y variables por modelo
    # Carga de datos desde csv
    file = InputDir + "/" + RUNID + "_predecir.csv"
    logger.info("Lectura de datos desde " + file)
    try:
        data = pd.read_csv(file)
        try:
            data = data.set_index("Pozo")
        except:
            logger.warning(
                "El archivo de entrada no tiene id de Pozo. Se asigna un ID secuencial de 0 a n"
            )
            data.index.name = "Pozo"
    except Exception as e:
        try:
            # Mover a processed
            logger.info("Moviendo archivo de input a processed...")
            file_dest = ProcessedDir + "/" + RUNID + "_predecir.csv"
            os.rename(file, file_dest)
            logger.critical(
                "El contenido del archivo " + file + " no es el adecuado.\n" + str(e)
            )
            sys.exit(1)
        except Exception as e:
            logger.critical(
                "El contenido del archivo "
                + file
                + " no es el adecuado. \n El archivo no pudo ser movido a "
                + file_dest
                + "\n"
                + str(e)
            )
            sys.exit(1)

    # Este es el orden en que debe recibir las variables el modelo
    OrganicoModelVars = [
        "CARB_V_Std",
        "Intensity_Total_Proppant_lbs_ft",
        "Pozos_Padres_dif_nivel",
        "PHIT_Avg",
        "CARB_V_Avg",
        "GR_Avg",
        "QFM_V_Std",
        "Effective_Lateral_Length_m",
        "Pct_Slickwater",
        "Intensity_Total_Fluid_bbl_ft",
        "Pct_30_70_Any",
        "Avg_Cluster_Spacing_m",
        "Avg_Final_Concentration_ppa",
    ]

    CocinaModelVars = [
        "PHIT_Avg",
        "CARB_V_Avg",
        "GR_Avg",
        "QFM_V_Std",
        "SHMIN_Std",
        "TVD_LP_m",
        "Intensity_Total_Proppant_lbs_ft",
        "Effective_Lateral_Length_m",
        "Pct_Slickwater",
        "Intensity_Total_Fluid_bbl_ft",
        "Pct_30_70_Any",
        "Avg_Cluster_Spacing_m",
        "Avg_Final_Concentration_ppa",
    ]

    # Predice Organico?
    OKOrganico = set(OrganicoModelVars).issubset(set(data.columns))
    logger.info("Columnas Orgánico? " + str(OKOrganico))
    # Predice Cocina?
    OKCocina = set(CocinaModelVars).issubset(set(data.columns))
    logger.info("Columnas Cocina? " + str(OKCocina))

    # Validar contenido
    # WARNING por rangos fuera de lo conocido por el modelo

    # Predecir
    if OKOrganico:
        from predict import Predict_Organico

        Predict_Organico(RUNID, ModelDir, OutputDir, objetivo, data[OrganicoModelVars])

    if OKCocina:
        from predict import Predict_Cocina

        Predict_Cocina(RUNID, ModelDir, OutputDir, objetivo, data[CocinaModelVars])

    # Mover a processed
    logger.info("Moviendo archivo de input a processed...")
    file_dest = ProcessedDir + "/" + RUNID + "_predecir.csv"
    os.rename(file, file_dest)

    # FINALIZA PROCESO
    logger.info("FIN PROCESO :" + RUNID)
    handler.close()
    # logging.shutdown()
