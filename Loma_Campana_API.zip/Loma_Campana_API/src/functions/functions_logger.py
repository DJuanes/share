import logging
import logging.config
import os
from datetime import datetime

import yaml
from pytz import timezone

from functions import functions_utils


##---------------------------------------------------------------------------##
## crear_logger - creacion del logger
## Parámetros :
##    - logger_name: nombre del logger
##    - config_file: path donde se encuentra la configuración del logger
## Retorno :
##    - logger: instancia del logger
##---------------------------------------------------------------------------##
def crear_logger(logger_name, config_file="config/cliente_api_scoring_logger.yml"):
    with open(config_file) as parameters:
        levantar_cfg = yaml.safe_load(parameters)

    logging.Formatter.converter = lambda *args: datetime.now(
        tz=timezone("America/Argentina/Buenos_Aires")
    ).timetuple()

    logging.config.dictConfig(levantar_cfg)
    logger = logging.getLogger(logger_name)

    logger.info("[crear_logger] Logger iniciado. ")

    return logger


##---------------------------------------------------------------------------##
## logger_default - generar un logger de consola default
## Retorno :
##    - logger: instancia de logger
##---------------------------------------------------------------------------##
def logger_default():
    logger = logging.getLogger("root")

    logger.info("[logger_default] Logger iniciado. ")
    return logger


##---------------------------------------------------------------------------##
## get_logger_from_param - obtiene una instancia del logger a partir de su
## nombre. Si no lo encuentra, retorna el default.
## Parámetros :
##    - p_logger: nombre del logger
##    - prefix_msg: prefijo para el mensaje
## Retorno :
##    - current_logger: instancia del logger
##---------------------------------------------------------------------------##
def get_logger_from_param(p_logger=None, prefix_msg="[LOGGER]"):
    current_logger = p_logger

    if current_logger is not None:
        current_msg = prefix_msg + " Logger ya configurado"
        current_logger.info(current_msg)

    if current_logger is None:
        current_logger = logger_default()
        current_msg = prefix_msg + " Iniciando logger default"
        current_logger.info(current_msg)

    return current_logger


##---------------------------------------------------------------------------##
## logger_and_mail - Loguea en el logger pasado como argumento y envia un mail
## Parámetros :
##    - logger: instancia del logger
##    - level: nivel de logueo
##    - msg: mensaje a enviar por mail
##    - to: destinatario/s del mail
##    - subject: asunto del mail
##    - body: contenido del mail
##    - p_cfg_param_post_url: url para envio de mail
##---------------------------------------------------------------------------##
def logger_and_mail(logger, level, msg, to, subject, body, p_cfg_param_post_url):
    try:
        # Logea en el logger pasado como argumento
        getattr(logger, level.lower())(msg)
        # Envia mail
        functions_utils.send_mail(to, subject, body, p_cfg_param_post_url)
    except Exception as e:
        print(type(e), e)
