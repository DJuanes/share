# Mineralogia

## Documentación

- [workflows](src/main.md): flujos de trabajo principales.
- [src](src/data.md): documentación de la funcionalidad.

## Documentación paso a paso

Aprenda a combinar machine learning con la ingeniería de software para crear aplicaciones de nivel de producción.

- Codigo: [DJuanes/coe-mlops-playbook](https://github.com/DJuanes/coe-mlops-playbook)
