"""Workflow principal"""

import logging
import os
import re
from datetime import datetime
from typing import Dict

import joblib
import lasio
import numpy as np
import pandas as pd
import typer

import model_with_IC
from config import config
from config.config import logger
from src import predict as pred

# Inicializar la aplicación CLI de Typer
app = typer.Typer()


def limpia_columna_repetida(df: pd.DataFrame) -> pd.DataFrame:
    """Función que toma un dataframe con perfiles y elimina los gnemonics
        que por estar repetidos en el .las fueron renombrados por lasio a :N
        No aceptamos mnemonics duplicados, nos quedamos con el primero
        La librería lasio agrega :N , siendo N un numero secuencial de comenzando en 1
        Entonces, si en los nombres de columna del archivo leíado hay :N debemos
        quedarnos con la primer columna :1 y dropear las demas.

    Args:
        df pd.DataFrame: dataframe a limpiar

    Returns:
        pd.DataFrame: Datos de los perfiles. Sin columnas duplicadas

        Utilizar esta funcion en read_perfil_las() antes del return y el append
        lasdf = limpia_columna_repetida(lasdf)
    """
    # La expresion regular esperada es :N donde N es un numero
    regexp = re.compile(r":[0-9]")
    for columna in df.columns:
        if regexp.search(columna):
            # Si la columna tiene la expresion regular
            # Separo nombre de numero
            nombre = columna.split(":", 1)[0]
            numero = columna.split(":", 1)[1]
            if numero == "1":
                # si es la numero 1 creo la columna con nombre solo
                df[nombre] = df[columna]
            df.drop(columna, axis=1, inplace=True)
    return df


def read_perfil_las(file: str) -> pd.DataFrame:
    """
    Genera un dataframe a partir de un archivo con formato las

    Args:
        file (str): archivo .las a cargar en un dataframe

    Returns:
        pd.DataFrame: dataframe con el contenido del .las
    """

    df_out = pd.DataFrame()

    # check de existencia de más de 1 columna en el archivo las
    try:
        with open(file, "r", encoding="utf-8") as f:
            arch = f.readlines()
        if len(arch) == 0:
            raise ValueError("El perfil está vacío.")
        columns = [x for x in arch[-2].split(" ") if x not in ["", "\n"]]
        if len(columns) < 2:
            raise ValueError("El perfil tiene menos de 2 columnas.")
    except Exception as e:
        raise ValueError(f"Error durante la lectura del archivo LAS. {e.args[0]}") from e

    try:
        las = lasio.read(file)
        df_out = las.df()
        df_out.reset_index(level=None, drop=False, inplace=True, col_level=0, col_fill="")
        # contenido de WELL en el header del .las
        df_out["WELL"] = las.well.WELL.value
        df_out = limpia_columna_repetida(df_out)

    except lasio.las.exceptions.LASHeaderError as e:
        raise ValueError(
            "Error durante la lectura de los datos del encabezado del archivo LAS."
        ) from e

    except lasio.las.exceptions.LASDataError as e:
        raise ValueError("Error durante la lectura de datos numéricos del archivo LAS.") from e

    except lasio.las.exceptions.LASUnknownUnitError as e:
        raise ValueError("Error de unidad desconocida en archivo LAS.") from e

    return df_out


def write_las_file(archivo: str, data: pd.DataFrame) -> None:
    """
    Guarda un dataframe como archivo .las

    Args:
        file_name (str): nombre del archivo .las
        well (str): nombre del pozo
        data (pd.DataFrame): dataframe con el contenido del archivo las
    """

    # ruta para guardar perfil
    archivo_las = archivo[:-4] + "_COE.las"
    path_salida_las = config.DATA_OUTPUT_DIR.joinpath(archivo, archivo_las)

    # procesamiento de datos
    for feature in data.dtypes[data.dtypes.values != object].index.to_list():
        if feature in ["LATITUD", "LONGITUD"]:
            data.loc[data[feature] > 0, feature] = np.nan
        else:
            data.loc[data[feature] < 0, feature] = np.nan

    # Creo el archivo las
    las = lasio.LASFile()
    las.well.WELL = data["WELL"].unique()[0]
    las.well.DATE = datetime.today().strftime("%d/%m/%Y")
    las.well.NULL = -999.0000
    for mnemonic in data.columns:
        if mnemonic != "WELL":
            las.append_curve(mnemonic, data[mnemonic])
    las.write(str(path_salida_las), version=2, mnemonics_header=True, data_section_header="~ASCII")


def transform_and_clean(df: pd.DataFrame) -> pd.DataFrame:
    """
    Transforma y limpia los datos de entrada a cada modelo

    Args:
        df (pd.DataFrame): dataframe con los datos de entrada

    Returns:
        pd.DataFrame: dataframe con los datos de entrada transformados y limpios
    """

    if "AT90" in df.columns:
        df.loc[df["AT90"] > 700, "AT90"] = 700
    if "RHOZ" in df.columns:
        df.loc[df["RHOZ"] > 3, "RHOZ"] = 3

    for feature in df.columns:
        if feature in ["LATITUD", "LONGITUD"]:
            df.loc[df[feature] > 0, feature] = np.nan
        else:
            df.loc[df[feature] < 0, feature] = np.nan

    return df.dropna()


def load_artifacts() -> Dict:
    """
    Cargar artefactos para la predicción.

    Returns:
        Dict: artefactos de ejecución.
    """
    artifacts_dir = config.MODELS_DIR
    logger.info("artifacts dir: %s", artifacts_dir)
    models = {}
    for objetivo in config.OBJETIVOS:
        model_fp = artifacts_dir.joinpath(config.MODELOS[objetivo])
        models[objetivo]: model_with_IC = joblib.load(model_fp)
        logger.info("Carga modelo %s", config.MODELOS[objetivo])
    return models


def inicializar_logger(logfile: str) -> logging.Logger:
    """
    Inicializa el logging interno de DS

    Args:
        logfile (str): nombre del archivo de log

    Returns:
        logging.Logger: objeto logger
    """

    logname = "DS_log"
    loglevel = logging.INFO
    formatter = logging.Formatter("%(asctime)s :: %(name)s :: %(levelname)s :: %(message)s")
    ds_logger = logging.getLogger(logname)
    ds_logger.setLevel(loglevel)
    handler = logging.FileHandler(logfile)
    handler.setLevel(loglevel)
    handler.setFormatter(formatter)
    ds_logger.addHandler(handler)

    return ds_logger


def finalizar_logger(ds_logger: logging.Logger) -> None:
    """
    Cierra todos los handlers del logger

    Args:
        ds_logger (logging.Logger): objeto logger
    """
    if ds_logger is None:
        return
    for handler in list(ds_logger.handlers):
        handler.close()
        ds_logger.removeHandler(handler)


@app.command()
def predict(archivo: str) -> None:
    """
    Ejecuta la predicción

    Args:
        archivo (str): nombre del archivo
    """

    artifacts = load_artifacts()

    os.makedirs(config.DATA_OUTPUT_DIR.joinpath(archivo), exist_ok=True)

    logname = archivo[:-4] + ".log"
    logfile = config.DATA_OUTPUT_DIR.joinpath(archivo).joinpath(logname)
    ds_logger = inicializar_logger(logfile=logfile)
    ds_logger.info("INICIA PROCESO: %s", archivo)

    ds_logger.info("Lectura de datos desde el perfil %s", archivo)
    input_fp = config.DATA_INPUT_DIR.joinpath(archivo)
    try:
        data = read_perfil_las(input_fp)
    except ValueError as e:
        ds_logger.critical("No se puede abrir el perfil %s", archivo)
        ds_logger.critical(e)
        ds_logger.info("No se pueden ejecutar los modelos de Mineralogía.")
        ds_logger.info("Moviendo archivo de la carpeta input a processed...")
        output_fp = config.DATA_PROCESSED_DIR.joinpath("/ERROR_LECTURA_" + archivo)
        os.rename(input_fp, output_fp)
        ds_logger.info("FIN PROCESO: %s", archivo)
        return

    # prediccion de los modelos individuales de cada mineral
    # en el dataframe df_predicciones se realizará el merge con las predicciones
    check_sum = 0
    df_predicciones = pd.DataFrame(index=data.index)
    for objetivo in config.OBJETIVOS[:10]:
        # ckeck de que existen las variables para predecir el modelo
        ok_features = set(config.MODEL_FEATURES[objetivo]).issubset(set(data.columns))
        ds_logger.info(
            "¿Están las columnas %s para el modelo %s?: %s",
            config.MODEL_FEATURES[objetivo],
            objetivo,
            str(ok_features),
        )
        # prediccion del modelo
        if ok_features:
            # transformaciones y check de la calidad de los datos
            df_aux = data[config.MODEL_FEATURES[objetivo]].copy()
            df_aux = transform_and_clean(df_aux)
            if df_aux.shape[0] == 0:
                ds_logger.info(
                    "Luego del check de calidad, no quedan registros para predición del modelo."
                )
            else:
                df_aux = pred.predict_model_mineral(model=artifacts[objetivo],
                                                    data=df_aux,
                                                    objetivo=objetivo)
                df_predicciones = df_predicciones.merge(df_aux, how='left',
                                                        left_index=True, right_index=True)
                check_sum += 1

    # reconciliacion de datos: hay que chequear que se hayan ejecutado los 10 modelos
    if check_sum == 0:
        ds_logger.critical("Luego del tratamiento de los datos quedó el DataFrame vacio.")
        ds_logger.info("No se pueden ejecutar los modelos de los minerales.")
        ds_logger.info("Moviendo archivo de la carpeta input a processed.")
        output_fp = config.DATA_PROCESSED_DIR.joinpath("/ERROR_PROCESAMIENTO_" + archivo)
        os.rename(input_fp, output_fp)
        ds_logger.info("FIN PROCESO: %s", archivo)
        return
    if check_sum < 10:
        ds_logger.warning("Solo se ejecutaron %s modelos. Revisar datos de entrada.", check_sum)
        ds_logger.info("No se puede realizar la reconciliciación de datos.")
        ds_logger.info("Escribiendo perfil de salida (LAS) %s", archivo[:-4] + "_COE.las")

        # se reordenan las columnas para que quede primero DEPTH
        data = data[['DEPTH']
                    + [col for col in sorted(data.columns) if col not in ['DEPTH']]]
        data.sort_values(by='DEPTH', inplace=True)

        # se unen las predicciones con los datos originales
        data = data.merge(df_predicciones, how='left',
                          left_index=True, right_index=True)

        write_las_file(archivo=archivo, data=data)
        ds_logger.info("Moviendo archivo de la carpeta input a processed.")
        output_fp = config.DATA_PROCESSED_DIR.joinpath(archivo)
        os.rename(input_fp, output_fp)
        ds_logger.info("FIN PROCESO: %s", archivo)
        finalizar_logger(ds_logger=ds_logger)
        return

    if check_sum == 12:
        ds_logger.info("Se ejecutaron todos los modelos. Inicia reconciliación de datos.")

        # se reordenan las columnas para que quede primero DEPTH
        data = data[['DEPTH']
                    + [col for col in sorted(data.columns) if col not in ['DEPTH']]]
        data.sort_values(by='DEPTH', inplace=True)

        # ejecutar modelos de suma 1 para modelo de 10 minerales
        ds_logger.info("Reconciliación de datos para 10 minerales.")
        df_aux = pred.reconciliacion_datos_minimize(predicciones=df_predicciones.copy(),
                                                    objetivos=config.MODELO_10,
                                                    rmse=config.RMSE)
        data = data.merge(df_aux, how='left',
                          left_index=True, right_index=True)

        # ejecutar modelos de suma 1 para modelo de 6 minerales
        ds_logger.info("Reconciliación de datos para 6 minerales agrupados.")
        df_aux = pred.reconciliacion_datos_minimize(predicciones=df_predicciones.copy(),
                                                    objetivos=config.MODELO_6,
                                                    rmse=config.RMSE)
        data = data.merge(df_aux, how='left',
                          left_index=True, right_index=True)

        # guardar datos de los minerales reconciliados
        ds_logger.info("Escribiendo perfil de salida (LAS) %s", archivo[:-4] + "_COE.las")
        write_las_file(archivo=archivo, data=data)
        ds_logger.info("Moviendo archivo de la carpeta input a processed.")
        output_fp = config.DATA_PROCESSED_DIR.joinpath(archivo)
        os.rename(input_fp, output_fp)
        ds_logger.info("FIN PROCESO: %s", archivo)
        finalizar_logger(ds_logger=ds_logger)
        return


if __name__ == "__main__":
    app()  # pragma: aplicación en vivo
