# Creator: Johann Cambra
# Project name: Intervalos de Confianza
# Date: 2023-03-02

import lightgbm
import numpy as np
import pandas as pd

# from matplotlib import pyplot as plt
import statsmodels.api as sm


class ModelwithMaronnaIC:
    """
    Clase para el calculo de los intervalos de confianza con el método de Maronna de un modelo.

    Parámetros:
    model (lightgbm.sklearn.LGBMRegressor): El modelo LGBMRegressor ajustado.
    X (pd.DataFrame): Los datos de entrada con el que se ajustó el modelo.
    y_obs (np.array): Los valores observados de la variable de salida.
    y_pred (np.array): Los valores predichos de la variable de salida.
    target (str): El nombre de la variable de objetivo.
    span (float, opcional): El ancho de banda de la ventana en el filtro LOESS. Por defecto es 0.5.
    alpha (float, opcional): El nivel de confianza para el intervalo de confianza de Maronna. \
        Por defecto es 0.1.

    Atributos:
    model (lightgbm.sklearn.LGBMRegressor): El modelo LGBMRegressor ajustado.
    X (pd.DataFrame): Los datos de entrada del modelo.
    y_obs (np.array): Los valores observados de la variable de salida.
    y_pred (np.array): Los valores predichos de la variable de salida.
    features (list): La lista de nombres de las variables predictoras.
    objetivo (str): El nombre de la variable de objetivo.
    model_tipe (str): El nombre del tipo de modelo ajustado.
    span (float): El ancho de banda de la ventana en el filtro LOESS.
    alpha (float): El nivel de confianza para el intervalo de confianza de Maronna.
    residuos (np.array): Los residuos calculados como y_obs - y_pred.
    loess (np.array): Los valores ajustados por el filtro LOESS.
    ti (np.array): Los residuos normalizados de Maronna.

    Métodos:
    Residuals(): Calcula los residuos entre los valores observados y predichos.
    PlotResiduals(): Grafica los residuos.
    SetSpanLowess(): Permite ajustar el spam ajustar los residuos con el filtro LOESS.
    predict(): Predice la variable de objetivivo con el modelo ajustado.
    """

    def __init__(
        self,
        model: lightgbm.sklearn.LGBMRegressor,
        X: pd.DataFrame,
        y_obs: np.array,
        y_pred: np.array,
        target: str,
        span: float = 0.5,
        alpha: float = 0.1,
    ):
        """
        Inicializa los parámetros necesarios para calcular los residuos.

        model (lightgbm.sklearn.LGBMRegressor): El modelo LGBMRegressor a ajustar.
        X (pd.DataFrame): Los datos de entrada para ajustar el modelo.
        y_obs (np.array): Los valores observados de la variable de salida.
        y_pred (np.array): Los valores predichos de la variable de salida.
        span (float, opcional): El ancho de banda de la ventana en el filtro LOESS. \
            Por defecto es 0.5.
        alpha (float, opcional): El nivel de confianza para el intervalo de confianza de Maronna. \
            Por defecto es 0.1.
        """
        self.model = model
        self.X = X
        self.y_obs = y_obs.reshape(-1, 1)
        self.y_pred = y_pred.reshape(-1, 1)
        self.features = self.X.columns.to_list()
        self.objetivo = target
        self.model_tipe = type(self.model).__name__
        self.span = span if span <= 1 else 1
        self.alpha = alpha if alpha <= 1 else 1
        self.residuos = self.Residuals()
        self.loess = None
        self.ti = None

    def Residuals(self):
        """
        Calcula los residuos entre dos np.arrays de la clase ModelwithMaronnaIC.

        Retorna:
        np.array: El resultado de la resta de los dos np.arrays, self.y_obs - self.y_pred.

        Si ocurre una excepción, imprime un mensaje de error y devuelve None.
        """
        try:
            return self.y_obs - self.y_pred
        except Exception as error:
            print(
                "No se puede realizar el cálculo de los residuos, Exception ocurrida: {}".format(
                    error
                )
            )
        return

    """
    def PlotResiduals(self):

        PlotResiduals crea un gráfico de dispersión de los residuos del modelo
        en función de la estimación.

        #plt.rcParams['figure.figsize'] = [10, 5]
        plt.suptitle('Residuals vs Fitted')
        plt.scatter(self.y_pred, self.residuos, s=5)
        plt.ylabel('Residuals')
        plt.xlabel('Fitted values')
        plt.show()
        return
    """

    def SetSpanLowess(self, span: float = None, ylim: float = None):
        """MaronnaSetSpan usa la función Loess para ajustar los residuos del
           modelo en función de la estimación del modelo.

                " residuos_suavizados = Loess(y_pred) "

        Args:
            span (float [0,1]): Ventana de suavizado para el ajuste de la
                            función Loess.
            ylim (float, optional): parámetro para ajustar la escala "y" del
                                    gráfico creado con el ajuste de los
                                    residuos. Defaults to None.
        """

        if span is not None:
            self.span = span if span <= 1 else 1

        # Ajuste de Loess function
        self.loess = sm.nonparametric.lowess(
            endog=self.residuos.squeeze() ** 2, exog=self.y_pred.squeeze(), frac=self.span
        )
        smooth = self.loess[:, 1]
        smooth[smooth <= 0] = 0.0000001

        # normalización residuos y calculo de ti
        sigma_est = np.sqrt(smooth)
        self.ti = self.residuos / sigma_est.reshape(-1, 1)
        """
        # Plot Loess ajuste
        #plt.rcParams['figure.figsize'] = [10, 5]
        plt.suptitle(f'Span = {self.span}')
        plt.scatter(self.y_pred, self.residuos.squeeze()**2, s=5)
        plt.plot(self.y_pred, smooth, color='red')
        plt.ylabel('Residuals')
        plt.xlabel('Fitted values')
        if ylim is not None:
            plt.ylim((0, ylim))
        plt.show()
        """
        return

    def predict(self, X: pd.DataFrame = None, IC: bool = True):
        """predict calcula las predicciones del modelo con los datos de entrada x.
           Si no se pasa X se devuelve el valor de self.y_pred de la etapa de entenamiento.

        Args:
            X (pd.DataFrame): Datos de entrada para calcular las predicciones.
            IC (bool, optional): Si es True, calcula los intervalos de confianza

        Returns:
            pd.DataFrame or np.array: Predicciones del modelo.
        """
        if X is None:
            if IC is False:
                return self.y_pred
            else:
                # Usando el resultado de Loess calculamos el error de normalizado
                # de la predicción
                sigma_est = np.sqrt(
                    np.interp(self.y_pred, self.loess[:, 0], self.loess[:, 1])
                ).reshape(-1, 1)

                # calculo ta y tb usando el alpha del intervalo de confianza
                ta = np.quantile(self.ti, self.alpha / 2)
                tb = np.quantile(self.ti, 1 - (self.alpha / 2))

                # Se calculan los intervalos de confianza
                interval = pd.DataFrame(
                    data=self.y_pred, columns=[self.objetivo], index=self.X.index
                )
                interval[self.objetivo + "_INF"] = self.y_pred + (sigma_est * ta)
                interval[self.objetivo + "_SUP"] = self.y_pred + (sigma_est * tb)
                return interval
        else:
            if IC is False:
                return self.model.predict(X)
            else:
                # se calcula la predicción del modelo
                y_pred = self.model.predict(X).reshape(-1, 1)
                # Usando el resultado de Loess calculamos el error de normalizado
                # de la predicción
                sigma_est = np.sqrt(np.interp(y_pred, self.loess[:, 0], self.loess[:, 1])).reshape(
                    -1, 1
                )

                # calculo ta y tb usando el alpha del intervalo de confianza
                ta = np.quantile(self.ti, self.alpha / 2)
                tb = np.quantile(self.ti, 1 - (self.alpha / 2))

                # Se calculan los intervalos de confianza
                interval = pd.DataFrame(data=y_pred, columns=[self.objetivo], index=X.index)
                interval[self.objetivo + "_INF"] = y_pred + (sigma_est * ta)
                interval[self.objetivo + "_SUP"] = y_pred + (sigma_est * tb)
                return interval
