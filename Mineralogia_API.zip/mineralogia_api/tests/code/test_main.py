# from typer.testing import CliRunner
# from pathlib import Path
# import sys

# BASE_DIR = Path(__file__).parent.parent.parent.absolute()
# SRC_DIR = Path(BASE_DIR, "src")
# sys.path.append(str(SRC_DIR))

# from src import main
# from src.main import app

# runner = CliRunner()


# def test_load_artifacts():
#     artifacts = main.load_artifacts()
#     assert len(artifacts) == 2


# def test_predict():
#    archivo = "20230201152433_diego.juanes@ypf.com_Nq.SOil-174.las"
#    result = runner.invoke(app, ["predict", f"--archivo={archivo}"])
#    assert result.exit_code == 0
