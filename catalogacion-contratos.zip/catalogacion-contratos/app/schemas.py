from pydantic import BaseModel


class Archivo(BaseModel):
    archivo: str

    class Config:
        schema_extra = {
            "example": {
                "archivo": "80_pp_V3_R02.xlsx",
            }
        }
