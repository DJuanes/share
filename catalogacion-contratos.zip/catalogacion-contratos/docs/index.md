# Catalogacion-Contratos

Catalogacion de Contratos

## Equipo

* Cientifico de datos: Gabriel Pachado
* Ingeniero de ml: Diego Juanes / Cristian Perez Andaur
* Líder técnico: Gabriel Horowitz
* Domain owner: No se
* Scrum master: Cristian Calvo
* Key user: No se
* Sponsor: No se

## Virtual environment

```bash
python3 -m venv venv
source ./venv/scripts/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -e ".[dev]"
pre-commit install
pre-commit autoupdate
```

## Variables de entorno

Se debe crear el archivo .env tomando como base .env.ejemplo y completando los valores requeridos.
Esto es para no subir claves al repositorio

## Directorio

```bash
src/
├── data.py                 - utilidades de procesamiento de datos
├── evaluate.py             - componentes de evaluación
├── main.py                 - workflow principal (procesamiento, predicción, etc)
├── predict.py              - utilidades de inferencia
├── shared/
    ├── blob_storage.py     - modulo para mamejo de blobs
    ├── pi.py               - modulo para obtención de datos de pi
    └── utils.py            - utilidades suplementarias
```

## Automatización

```bash
make style                      # ejecuta el formato de estilo
make test                       # ejecuta pruebas sobre código y datos
```

## Documentación (Código)

```bash
python -m mkdocs serve          # disponibiliza la documentación localmente
python -m mkdocs build          # genera el site con la documentación
```

## Documentación (Datos)

```bash
great_expectations docs build   # disponibiliza la documentación localmente
```

## Workflow

```bash
python src/main.py process-input "80_pp_V3_R02.xlsx"
```

## API

```bash
uvicorn app.api:app --host 0.0.0.0 --port 8000 --reload --reload-dir src --reload-dir app  # dev
gunicorn -c app/gunicorn.py -k uvicorn.workers.UvicornWorker app.api:app  # prod
```

## Código

* [workflows](src/main.md): flujos de trabajo principales.
* [src](src/data.md): documentación de la funcionalidad.
