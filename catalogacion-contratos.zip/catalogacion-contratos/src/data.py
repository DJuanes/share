"""utilidades de procesamiento de datos"""

import sys

from config import config
from config.config import logger
from src.shared import blob_storage as blob


def download_novedades(archivo: str) -> None:
    """Descarga archivo del blob storage

    Args:
        archivo (str): Nombre del nuevo archivo
    """

    try:
        blob.download_data_from_blob_storage(
            storage_account_key=config.STORAGE_ACCOUNT_KEY,
            container_name=config.CONTAINER_NAME,
            local_fp=config.DATA_INPUT_DIR,
            blob_name=archivo,
        )
        logger.info("Archivo descargado: %s", archivo)
    except blob.ArchivoInexistente as e:
        logger.error(e)
        upload_log()
        sys.exit(1)


def download_vector() -> None:
    """Descarga vector del blob storage"""

    blob.download_vector_from_blob_storage(
        storage_account_key=config.STORAGE_ACCOUNT_KEY,
        container_name=config.CONTAINER_NAME,
        local_fp=config.VECTOR_DIR,
    )
    logger.info("Base de vectores descargada")


def upload_log() -> None:
    """Copiar el archivo de logs al correspondiente contenedor de blobs"""
    blob.upload_log_to_blob_storage(
        storage_account_key=config.STORAGE_ACCOUNT_KEY,
        container_name=config.CONTAINER_NAME,
        log_fp=config.LOGS_DIR,
    )


def upload_data() -> None:
    """Copiar los archivos generados al blob storage"""

    blob.upload_data_to_blob_storage(
        storage_account_key=config.STORAGE_ACCOUNT_KEY,
        container_name=config.CONTAINER_NAME,
        output_fp=config.DATA_OUTPUT_DIR,
    )
