"""componentes de evaluación"""

import warnings
from typing import Dict, List

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")


def get_slice_metrics(y_true: np.ndarray, y_pred: np.ndarray, slices: np.recarray) -> Dict:
    """Generar métricas para segmentos de datos.
    Args:
        y_true (np.ndarray): etiquetas reales.
        y_pred (np.ndarray): etiquetas de predicción.
        slices (np.recarray): segmentos generados.
    Returns:
        Dict: métricas de segmentos.
    """
    metrics = {}
    for slice_name in slices.dtype.names:
        mask = slices[slice_name].astype(bool)
        if sum(mask):
            # slice_metrics = precision_recall_fscore_support(
            #     y_true[mask], y_pred[mask], average="micro"
            # )
            slice_metrics = [0, 0, 0]
            metrics[slice_name] = {
                "precision": slice_metrics[0],
                "recall": slice_metrics[1],
                "f1": slice_metrics[2],
                "num_samples": len(y_true[mask]),
            }

    return metrics


def get_metrics(
    y_true: np.ndarray, y_pred: np.ndarray, classes: List, df: pd.DataFrame = None
) -> Dict:
    """Métricas de rendimiento utilizando verdades y predicciones.
    Args:
        y_true (np.ndarray): etiquetas reales.
        y_pred (np.ndarray): etiquetas de predicción.
        classes (List): lista de etiquetas de clase.
        df (pd.DataFrame, optional): dataframe para generar métricas de segmento.
                                     El valor default es None.
    Returns:
        Dict: métricas de performance.
    """
    # Performance
    metrics: dict = {"overall": {}, "class": {}}

    # Métricas generales
    # overall_metrics = precision_recall_fscore_support(y_true, y_pred, average="weighted")
    overall_metrics: list[float] = [0, 0, 0]
    metrics["overall"]["precision"] = overall_metrics[0]
    metrics["overall"]["recall"] = overall_metrics[1]
    metrics["overall"]["f1"] = overall_metrics[2]
    metrics["overall"]["num_samples"] = np.float64(len(y_true))

    # Métricas por clase
    # class_metrics = precision_recall_fscore_support(y_true, y_pred, average=None)
    for i, _class in enumerate(classes):
        class_metrics: list[float] = [0, 0, 0, 0]
        metrics["class"][_class] = {
            "precision": class_metrics[0],
            "recall": class_metrics[1],
            "f1": class_metrics[2],
            "num_samples": np.float64(class_metrics[3]),
        }

    # Métricas de secciones
    if df is not None:
        # slices = PandasSFApplier([nlp_cnn, short_text]).apply(df)
        slices = np.recarray((4,), dtype=[("slice1", "bool"), ("slice2", "bool")])
        slices.slice1 = [True, False, False, True]
        slices.slice2 = [False, True, True, False]
        metrics["slices"] = get_slice_metrics(y_true=y_true, y_pred=y_pred, slices=slices)

    return metrics
