"""Workflow principal"""

import warnings
from argparse import Namespace
from pathlib import Path
from typing import Dict

import joblib
import typer

from config import config
from config.config import logger
from src import data, predict
from src.shared import utils

warnings.filterwarnings("ignore")

# Inicializar la aplicación CLI de Typer
app = typer.Typer()


@app.command()
def elt_data():
    """Extraer, cargar y transformar nuestros activos de datos."""
    # Extract + Load

    # Transform


def load_artifacts() -> Dict:
    """
    Cargar artefactos para la predicción.

    Returns:
        Dict: artefactos de ejecución.
    """
    # Cargar objetos desde la ejecución
    config_dir = config.CONFIG_DIR
    artifacts_dir = config.MODELS_DIR
    args = Namespace(**utils.load_dict(filepath=str(Path(config_dir, "args.json"))))
    models = {}
    for item in config.MODELOS.items():
        modelo_clave = item[0]
        modelo = item[1]
        model_fp = artifacts_dir.joinpath(modelo)
        models[modelo_clave] = joblib.load(str(model_fp))
        logger.info("Carga modelo %s", str(model_fp))

    performance = utils.load_dict(filepath=str(Path(config_dir, "performance.json")))
    data.download_vector()
    logger.info("Vectores cargados")

    return {
        "args": args,
        "model": models,
        "performance": performance,
    }


@app.command()
def process_input(data_input: str):
    """Esta funcion carga el modelo entrenado y usarlo para predecir,
    creando un excel con una semaforizacion de los valores predichos"""

    data.download_novedades(archivo=data_input)

    # Inferencia sobre los archivos de input
    df_result, df_data = predict.inference_fun(data_input)
    df_result.to_excel(config.DATA_OUTPUT_DIR.joinpath("df_result.xlsx"))
    logger.info("Archivo df_result.xlsx generado")

    # Inferencia con regresor para predecir si el campo propuesto por GPT es correcto o no
    predict.inference_regresor(df_result, df_data=df_data)
    logger.info("Archivo resultados.xlsx generado")

    data.upload_log()
    data.upload_data()


if __name__ == "__main__":  # pragma: no cover
    app()
    # Para debugear comentar la linea anterior y descomentar la siguiente
    # El archivo debe existir en el blob storage
    # path = 'C:/Users/mlanza/Downloads/YPF/REPO/catalogacion-contratos_3/data/input/Template itemizado.xlsx'
    # process_input(path)
