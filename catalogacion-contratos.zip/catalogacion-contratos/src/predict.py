"""utilidades de inferencia"""

import os
import re
import warnings

import chromadb
import joblib
import numpy as np
import openai
import openpyxl
import pandas as pd
from dotenv import load_dotenv
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from openpyxl.styles import Color, Font
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler

from config import config
# from config.config import logger
from src.shared import utils

warnings.filterwarnings("ignore")


def inference_fun(data_input: str) -> pd.DataFrame:
    """La funcion"""
    load_dotenv()

    # ### 🔬📊 INFERENCE
    # Crear archivo .env basandose en .env.ejemplo y completando las variables de entorno
    openai.api_type = os.environ["OPENAI_API_TYPE"]
    openai.api_key = os.environ["OPENAI_API_KEY"]
    openai.api_base = os.environ["OPENAI_API_BASE"]
    openai.api_version = os.environ["OPENAI_API_VERSION"]

    # ### 🗃️ Carga de Datos a predecir
    df_data = pd.read_excel(config.DATA_INPUT_DIR.joinpath(data_input))
    df_data = df_data[~df_data["Alcance"].isna()]

    # Aplicamos la función a la columna utilizando apply()
    df_data["Alcance"] = df_data["Alcance"].apply(utils.agregar_punto)

    # ### 🔍Buscamos los 3 casos más similares
    # Indicamos Modelo para los embeddings
    embeddings = OpenAIEmbeddings(
        deployment="embeddingada002",  # "your-embeddings-deployment-name"
        openai_api_base=openai.api_base,
    )

    # Carga de base de vectores
    vectordb = Chroma(
        persist_directory=str(config.PERSIST_DIRECTORY_DESCRIPTION),
        embedding_function=embeddings,
        collection_name=config.COLLECTION_NAME_DESCRIPTION,
    )

    lista_outputs = []
    lista_casos = df_data["Alcance"]

    for text in lista_casos[:]:
        # text = lista_casos[0]
        try:
            (
                out,
                ejemplo,
                des_0,
                ac_0,
                acmod_0,
                ob_0,
                obmod_0,
                aplica_0,
                cosine_0,
                des_1,
                ac_1,
                acmod_1,
                ob_1,
                obmod_1,
                aplica_1,
                cosine_1,
                des_2,
                ac_2,
                acmod_2,
                ob_2,
                obmod_2,
                aplica_2,
                cosine_2,
            ) = main(text, vectordb)

            # Añadir los outputs como una tupla o una lista a la lista_outputs
            lista_outputs.append(
                (
                    out,
                    ejemplo,
                    des_0,
                    ac_0,
                    acmod_0,
                    ob_0,
                    obmod_0,
                    aplica_0,
                    cosine_0,
                    des_1,
                    ac_1,
                    acmod_1,
                    ob_1,
                    obmod_1,
                    aplica_1,
                    cosine_1,
                    des_2,
                    ac_2,
                    acmod_2,
                    ob_2,
                    obmod_2,
                    aplica_2,
                    cosine_2,
                )
            )
        except Exception as e:
            print(
                f"Ocurrió un error en el request de la API: {str(e)}"
            )  # ######Consultar Diego########
            # En caso de excepción, añadir NaN a la lista_outputs
            lista_outputs.append(
                (
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    0,
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    0,
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    0,
                )
            )  # Añadir 17 NaNs para mantener la misma estructura de datos
            continue

    # Convertir la lista en un dataframe
    df_result = pd.DataFrame(lista_outputs)

    # Asignar una lista con los nombres de las columnas al atributo df.columns
    df_result.columns = [
        "y_pred",
        "context",
        "descrption_0",
        "action_0",
        "action_mod_0",
        "object_0",
        "object_mod_0",
        "aplica_0",
        "cosine_0",
        "descrption_1",
        "action_1",
        "action_mod_1",
        "object_1",
        "object_mod_1",
        "aplica_1",
        "cosine_1",
        "descrption_2",
        "action_2",
        "action_mod_2",
        "object_2",
        "object_mod_2",
        "aplica_2",
        "cosine_2",
    ]

    # #### Post procesamiento
    list_accion = []
    list_accionmod = []
    list_objeto = []
    list_objetomod = []
    list_aplica = []
    for x in df_result["y_pred"]:

        # texto_sin_tildes = unidecode(str(x))
        texto_sin_tildes = utils.eliminar_tildes(str(x))
        matches = re.search(r"Accion: ([A-Za-z\/ ]+)", texto_sin_tildes)
        matches_acmod = re.search(r"Modificador de la accion: ([A-Za-z\/ ]+)", texto_sin_tildes)
        matches_ob = re.search(r"Objeto: ([A-Za-z\/ ]+)", texto_sin_tildes)
        matches_obmod = re.search(r"Modificador del objeto: ([A-Za-z\/ ]+)", texto_sin_tildes)
        matches_aplica = re.search(r"Aplica: ([A-Za-z\/ ]+)", texto_sin_tildes)

        if matches:
            # Obtener la parte coincidente de la expresión regular
            list_accion.append(matches.group(1))
        else:
            list_accion.append("")

        if matches_acmod:
            # Obtener la parte coincidente de la expresión regular
            list_accionmod.append(matches_acmod.group(1))
        else:
            list_accionmod.append("")

        if matches_ob:
            list_objeto.append(matches_ob.group(1))
        else:
            list_objeto.append("")

        if matches_obmod:
            list_objetomod.append(matches_obmod.group(1))
        else:
            list_objetomod.append("")

        if matches_aplica:
            list_aplica.append(matches_aplica.group(1))
        else:
            list_aplica.append("")

    df_result["AC_pred"] = list_accion
    df_result["ACMOD_pred"] = list_accionmod
    df_result["OB_pred"] = list_objeto
    df_result["OBMOD_pred"] = list_objetomod
    df_result["APLICA_pred"] = list_aplica

    # Eliminamos las tildes, ya que la base de datos esta en mayúscula y sin estos
    cols = ["AC_pred", "ACMOD_pred", "OB_pred", "OBMOD_pred", "APLICA_pred"]
    for col in cols:
        df_result[col] = df_result[col].fillna("")
        df_result[col] = df_result[col].str.strip().apply(utils.eliminar_tildes)

    # ### Corregimos el campos ACTION, para los casos donde el coseno está por encima de un umbral
    flags = []
    ac_emb = []
    # ob_emb = []
    df_result["ac_corr"] = df_result["AC_pred"]

    df_result.reset_index(drop=True, inplace=True)
    df_result = pd.concat([df_data, df_result], axis=1)
    for i in range(len(df_result)):
        row = df_result.iloc[i]
        umbral = 0.95
        if (
            ("TARIFA C" in row["Alcance"])
            & ("TARIFA C" in row["descrption_0"])
            & (row["cosine_0"] > umbral)
        ) or (
            ~("TARIFA C" in row["Alcance"])
            & ~("TARIFA C" in row["descrption_0"])
            & (row["cosine_0"] > umbral)
        ):
            flag_des = 0  # Toma los campos de la descripción 0
            ac = row["action_0"]

            ac_emb.append(ac)
            df_result.loc[i, "ac_corr"] = ac

        elif (
            ("TARIFA C" in row["Alcance"])
            & ("TARIFA C" in row["descrption_1"])
            & (row["cosine_1"] > umbral)
        ) or (
            ~("TARIFA C" in row["Alcance"])
            & ~("TARIFA C" in row["descrption_1"])
            & (row["cosine_1"] > umbral)
        ):
            flag_des = 1  # Toma los campos de la descripcion 1
            ac = row["action_1"]

            ac_emb.append(ac)
            df_result.loc[i, "ac_corr"] = ac

        else:
            flag_des = 3  # Toma los campos del output de GPT
            ac_emb.append("")

        flags.append(flag_des)

    df_result["flag_emb"] = flags

    return df_result, df_data


def main(text: str, vectordb: Chroma):
    """La funcion que le pide a chat gpt que prediga la accion, objeto y modificador
    de objeto de una descripcion, a partir de 3 ejemplos proporcionados"""

    (
        des_0,
        ac_0,
        acmod_0,
        ob_0,
        obmod_0,
        aplica_0,
        cosine_0,
        des_1,
        ac_1,
        acmod_1,
        ob_1,
        obmod_1,
        aplica_1,
        cosine_1,
        des_2,
        ac_2,
        acmod_2,
        ob_2,
        obmod_2,
        aplica_2,
        cosine_2,
    ) = get_similar(text, vectordb)

    def get_OBJECT(description: str):

        objetivo = 'Sos un especialista en categorizar textos. Ayudame a completar la siguiente tarea: \nA partir de un texto "Descripción" se extraen las categorias "Acción", "Modificador de la acción", "Objeto", "Modificador del objeto" y "Aplica". \nTe daré ejemplos de cómo realizar esta tarea y luego tendrás que decirme la "Acción", "Modificador de la acción", "Objeto", "Modificador del objeto" y "aplica" para la última descripción. \nEn la respuesta se requiere solo la "Acción", "Modificador de la acción", el "Objeto", el "Modificador del objeto" y "Aplica", para la cuarta "Descripción" sin información adicional ni código, solo texto. \n'

        ejemplo = f"""\
            \nDescripción: {des_0}\
            \nAcción: {ac_0}\
            \nModificador de la acción: {acmod_0}\
            \nObjeto: {ob_0}\
            \nModificador del objeto: {obmod_0}\
            \nAplica: {aplica_0}\n\
            \nDescripción: {des_1}\
            \nAcción: {ac_1}\
            \nModificador de la acción: {acmod_1}\
            \nObjeto:  {ob_1}\
            \nModificador del objeto: {obmod_1}\
            \nAplica: {aplica_1}\n\
            \nDescripción: {des_2}\
            \nAcción: {ac_2}\
            \nModificador de la acción: {acmod_2}\
            \nObjeto: {ob_2}\
            \nModificador del objeto: {obmod_2}\
            \nAplica: {aplica_2}\n"""

        query = objetivo + ejemplo + "\n" + "Descripción: " + description
        # print("QUERY: \n" + query)

        text = openai.Completion.create(
            engine="davinci", prompt=query, temperature=0, max_tokens=50
        )
        return text["choices"][0]["text"], ejemplo

    out, ejemplo = get_OBJECT(text)

    return (
        out,
        ejemplo,
        des_0,
        ac_0,
        acmod_0,
        ob_0,
        obmod_0,
        aplica_0,
        cosine_0,
        des_1,
        ac_1,
        acmod_1,
        ob_1,
        obmod_1,
        aplica_1,
        cosine_1,
        des_2,
        ac_2,
        acmod_2,
        ob_2,
        obmod_2,
        aplica_2,
        cosine_2,
    )


# Creamos una funcion que traiga el campo más similar y su distancia (score)
def get_similar(campo: str, vectordb: Chroma):
    """Esta función busca los k campos más similares por descripción"""

    out = vectordb.similarity_search_with_score(campo, k=3)

    des_0 = out[0][0].page_content
    ac_0 = out[0][0].metadata["ACTION"]
    acmod_0 = out[0][0].metadata["ACTIONMODIFIER"]
    ob_0 = out[0][0].metadata["OBJECT.1"]
    obmod_0 = out[0][0].metadata["OBJECTMODIFIER.1"]
    aplica_0 = out[0][0].metadata["APLICA"]
    cosine_0 = 1 - out[0][1]

    des_1 = out[1][0].page_content
    ac_1 = out[1][0].metadata["ACTION"]
    acmod_1 = out[0][0].metadata["ACTIONMODIFIER"]
    ob_1 = out[1][0].metadata["OBJECT.1"]
    obmod_1 = out[1][0].metadata["OBJECTMODIFIER.1"]
    aplica_1 = out[1][0].metadata["APLICA"]
    cosine_1 = 1 - out[1][1]

    des_2 = out[2][0].page_content
    ac_2 = out[2][0].metadata["ACTION"]
    acmod_2 = out[0][0].metadata["ACTIONMODIFIER"]
    ob_2 = out[2][0].metadata["OBJECT.1"]
    obmod_2 = out[2][0].metadata["OBJECTMODIFIER.1"]
    aplica_2 = out[2][0].metadata["APLICA"]
    cosine_2 = 1 - out[2][1]

    return (
        des_0,
        ac_0,
        acmod_0,
        ob_0,
        obmod_0,
        aplica_0,
        cosine_0,
        des_1,
        ac_1,
        acmod_1,
        ob_1,
        obmod_1,
        aplica_1,
        cosine_1,
        des_2,
        ac_2,
        acmod_2,
        ob_2,
        obmod_2,
        aplica_2,
        cosine_2,
    )


def inference_regresor(df_result: pd.DataFrame, df_data):
    """Funcion que hace la inferencia sobre el modelo ya entrenado. Predice"""

    load_dotenv()
    # #### 🔍 Buscamos similaridad
    # Crear archivo .env basandose en .env.ejemplo y completando las variables de entorno
    openai.api_type = os.environ["OPENAI_API_TYPE"]
    openai.api_key = os.environ["OPENAI_API_KEY"]
    openai.api_base = os.environ["OPENAI_API_BASE"]
    openai.api_version = os.environ["OPENAI_API_VERSION"]

    embeddings = OpenAIEmbeddings(
        deployment="embeddingada002",  # "your-embeddings-deployment-name"
        openai_api_base=openai.api_base,
    )

    # Cargamos la base de datos
    # Example setup of the client to connect to your chroma server
    client = chromadb.PersistentClient(str(config.PERSIST_DIRECTORY_REGRESSOR))
    collection = client.get_collection(name=config.COLLECTION_NAME_REGRESSOR)

    # ACTION
    df_result["ac_corr"] = df_result["ac_corr"].astype(str)
    df_result[["AC_emb", "ACTION_distance", "AC_similar", "AC_abreviatura"]] = df_result[
        "ac_corr"
    ].apply(lambda x: pd.Series(get_similar_reg(x, "ACTION", embeddings, collection)))

    # ACTION MODIFIER
    df_result["ACMOD_pred"] = df_result["ACMOD_pred"].astype(str)
    df_result[
        ["ACMOD_emb", "ACTIONMOD_distance", "ACMOD_similar", "ACMOD_abreviatura"]
    ] = df_result["ACMOD_pred"].apply(
        lambda x: pd.Series(get_similar_reg(x, "ACTIONMODIFIER", embeddings, collection))
    )

    # OBJETC
    df_result["OB_pred"] = df_result["OB_pred"].astype(str)
    df_result[["OB_emb", "OBJECT_distance", "OBJECT_Similar", "OBJECT_abreviatura"]] = df_result[
        "OB_pred"
    ].apply(lambda x: pd.Series(get_similar_reg(x, "OBJECT", embeddings, collection)))

    # OBJETC MODIFIER
    df_result["OBMOD_pred"] = df_result["OBMOD_pred"].astype(str)
    df_result[
        [
            "OBMOD_emb",
            "OBJECTMODIFIER_distance",
            "OBJECTMODIFIER_Similar",
            "OBJECTMODIFIER_abreviatura",
        ]
    ] = df_result["OBMOD_pred"].apply(
        lambda x: pd.Series(get_similar_reg(x, "OBJECTMODIFIER", embeddings, collection))
    )

    # APLICA
    df_result["APLICA_pred"] = df_result["APLICA_pred"].astype(str)
    df_result[
        ["APLICA_emb", "APLICA_distance", "APLICA_Similar", "APLICA_abreviatura"]
    ] = df_result["APLICA_pred"].apply(
        lambda x: pd.Series(get_similar_reg(x, "APLICA", embeddings, collection))
    )

    # NORMALIZACION
    # Llama a la función para normalizar columnas específicas en df_data
    columns_to_normalize = ["flag_emb"]
    df_data_normalized = normalize_dataframe(df_result, columns_to_normalize)

    # Llama a la función para aplicar PCA a columnas
    columns_to_pca = ["AC_emb", "OB_emb", "OBMOD_emb"]

    # Aplico PCA
    df_data_with_pca = apply_pca_to_columns(df_data_normalized, columns_to_pca)

    df_data_normalized.columns

    # INFERENCE
    # Define las columnas relevantes para Action y Object
    cols_action = [
        "flag_emb",
        # 'AC_pred_cos_sim_action_0',
        # 'AC_pred_cos_sim_action_1',
        # 'OB_pred_cos_sim_object_0',
        # 'OB_pred_cos_sim_object_1',
        "cosine_0",
        "cosine_1",
        "ACTION_distance",
        "OBJECT_distance",
        "AC_emb_pca",
    ]

    cols_object = [
        "flag_emb",
        # 'AC_pred_cos_sim_action_0',
        # 'AC_pred_cos_sim_action_1',
        # 'OB_pred_cos_sim_object_0',
        # 'OB_pred_cos_sim_object_1',
        "cosine_0",
        "cosine_1",
        "ACTION_distance",
        "OBJECT_distance",
        "OB_emb_pca",
    ]

    cols_obmod = [
        "flag_emb",
        # 'AC_pred_cos_sim_action_0',
        # 'AC_pred_cos_sim_action_1',
        # 'OB_pred_cos_sim_object_0',
        # 'OB_pred_cos_sim_object_1',
        "cosine_0",
        "cosine_1",
        "ACTION_distance",
        "OBJECT_distance",
        "OBJECTMODIFIER_distance",
        "OBMOD_emb_pca",
    ]

    # Define el umbral que deseas utilizar
    umbral_accion = 0.8  # encontrar_umbrales(resultados)[0]
    umbral_accionmod = 0.8
    umbral_objeto = 0.8  # encontrar_umbrales(resultados)[1]
    umbral_objetomod = 0.8
    umbral_aplica = 0.8

    # Llama a la función para cargar modelos, predecir y filtrar
    resultados_filtrados = cargar_modelos_y_predecir(
        df_data_with_pca, cols_action, cols_object, cols_obmod
    )
    resultados_filtrados["AC_abreviatura"] = df_result["AC_abreviatura"]
    resultados_filtrados["ACMOD_abreviatura"] = df_result["ACMOD_abreviatura"]
    resultados_filtrados["OBJECT_abreviatura"] = df_result["OBJECT_abreviatura"]
    resultados_filtrados["OBJECTMODIFIER_abreviatura"] = df_result["OBJECTMODIFIER_abreviatura"]
    resultados_filtrados["APLICA_abreviatura"] = df_result["APLICA_abreviatura"]
    resultados_filtrados["Item solicitado"] = df_data["Item solicitado"]
    resultados_filtrados["UM"] = df_data["UM"]
    resultados_filtrados["N° de Servicio"] = df_data["N° de Servicio"]
    resultados_filtrados["Texto Largo"] = df_data["Texto Largo"]
    resultados_filtrados["Observaciones"] = df_data["Observaciones"]
    resultados_filtrados["UM_"] = df_data["UM"]
    resultados_filtrados["GA"] = df_data["GA"]

    resultados_proba = resultados_filtrados.copy()
    col_a_borrar = [
        "pred_proba_action",
        "pred_proba_object",
        "pred_proba_objectmod",
        "action",
        "object",
        "object_modifier",
    ]
    resultados_filtrados = resultados_filtrados.drop(columns=col_a_borrar)
    resultados_filtrados = resultados_filtrados[
        [
            "Item solicitado",
            "Alcance",
            "UM",
            "N° de Servicio",
            "UM_",
            "GA",
            "Texto Largo",
            "AC_abreviatura",
            "ACMOD_abreviatura",
            "OBJECT_abreviatura",
            "OBJECTMODIFIER_abreviatura",
            "APLICA_abreviatura",
            "Observaciones",
        ]
    ]

    # OUTPUT EXCEL
    # Crear un archivo Excel
    # Abre el archivo Excel
    workbook = openpyxl.load_workbook(config.DATA_INPUT_DIR.joinpath("Template itemizado.xlsx"))

    # Selecciona una hoja específica (puedes cambiar el nombre de la hoja)
    worksheet = workbook["Prop.CAT"]

    # Establecer colores para resaltar las celdas
    fill_verde = Font(color=Color(rgb="00FF00"))
    fill_rojo = Font(color=Color(rgb="FF0000"))

    for row_idx, row in enumerate(
        resultados_filtrados.itertuples()
    ):  # Comenzar desde la fila 2 (ignorando encabezados)
        # Agregamos unidad de medida
        worksheet.cell(row=row_idx + 2, column=6).value = row.UM

        # Comprobar condiciones y aplicar colores
        if resultados_proba.loc[row_idx]["pred_proba_action"] > umbral_accion:
            worksheet.cell(row=row_idx + 2, column=10).value = row.AC_abreviatura
            worksheet.cell(row=row_idx + 2, column=10).font = fill_verde
        else:
            worksheet.cell(row=row_idx + 2, column=10).value = row.AC_abreviatura
            worksheet.cell(row=row_idx + 2, column=10).font = fill_rojo

        if 0.3 > umbral_accionmod:
            worksheet.cell(row=row_idx + 2, column=11).value = row.ACMOD_abreviatura
            worksheet.cell(row=row_idx + 2, column=11).font = fill_verde
        else:
            worksheet.cell(row=row_idx + 2, column=11).value = row.ACMOD_abreviatura
            worksheet.cell(row=row_idx + 2, column=11).font = fill_rojo

        if resultados_proba.loc[row_idx]["pred_proba_object"] > umbral_objeto:
            worksheet.cell(row=row_idx + 2, column=12).value = row.OBJECT_abreviatura
            worksheet.cell(row=row_idx + 2, column=12).font = fill_verde
        else:
            worksheet.cell(row=row_idx + 2, column=12).value = row.OBJECT_abreviatura
            worksheet.cell(row=row_idx + 2, column=12).font = fill_rojo

        if resultados_proba.loc[row_idx]["pred_proba_objectmod"] > umbral_objetomod:
            worksheet.cell(row=row_idx + 2, column=13).value = row.OBJECTMODIFIER_abreviatura
            worksheet.cell(row=row_idx + 2, column=13).font = fill_verde
        else:
            worksheet.cell(row=row_idx + 2, column=13).value = row.OBJECTMODIFIER_abreviatura
            worksheet.cell(row=row_idx + 2, column=13).font = fill_rojo

        if 0.3 > umbral_aplica:
            worksheet.cell(row=row_idx + 2, column=14).value = row.APLICA_abreviatura
            worksheet.cell(row=row_idx + 2, column=14).font = fill_verde
        else:
            worksheet.cell(row=row_idx + 2, column=14).value = row.APLICA_abreviatura
            worksheet.cell(row=row_idx + 2, column=14).font = fill_rojo

    # Crear una nueva columna con una fórmula visible
    for row_idx in range(2, len(resultados_filtrados) + 2):
        # valor_C = diccionario_unidad.get(worksheet.cell(row=row_idx, column=3).value, worksheet.cell(row=row_idx, column=3).value)
        formula = f'=J{row_idx} & " " & K{row_idx} & " " & L{row_idx} & " " & M{row_idx} & " " & N{row_idx} & " " & F{row_idx}'
        worksheet.cell(row=row_idx, column=8).value = formula

    # Guardar el archivo Excel
    workbook.save("data/output/resultados.xlsx")

    return resultados_filtrados


# Creamos una funcion que traiga el campo más similar y su distancia (score)
def get_similar_reg(campo, caracteristica, embeddings, collection):
    """Esta función busca los k campos más similares.
    Se debe ingresar el campo y el detalle (ACTION, OBJECT, OBJECTMODIFIER)"""

    if campo != "":
        emb_campo = embeddings.embed_query(campo)

        n_similar = collection.query(
            query_embeddings=emb_campo,
            n_results=1,
            where={"Característica": caracteristica},
            include=["metadatas", "documents", "distances", "embeddings"],
        )

        return (
            emb_campo,
            n_similar["distances"][0][0],
            n_similar["documents"][0][0],
            n_similar["metadatas"][0][0]["Valor"],
        )  # , n_similar['embeddings'][0][0]

    else:
        return None, None, None, ""


def normalize_dataframe(input_dataframe, columns_to_normalize):
    """Funcion que normaliza columnas"""

    # Crea un objeto MinMaxScaler
    scaler = MinMaxScaler()

    # Copia el DataFrame de entrada para no modificarlo directamente
    normalized_df = input_dataframe.copy()

    # Aplica la normalización a las columnas especificadas
    normalized_df[columns_to_normalize] = scaler.fit_transform(normalized_df[columns_to_normalize])

    return normalized_df


def apply_pca_to_columns(input_dataframe, columns_to_pca):
    """Función que aplica PCA a columnas que contienen vectores."""
    # Copia el DataFrame de entrada para no modificarlo directamente
    pca_df = input_dataframe.copy()

    # Crear una instancia de PCA
    pca = PCA(n_components=1)  # Reducir a 1 componente principal

    # Crear nuevas columnas para los valores PCA
    pca_column_names = [col + "_pca" for col in columns_to_pca]

    for col, pca_col in zip(columns_to_pca, pca_column_names):
        # Calcula la media de los vectores en la columna
        pca_df[pca_col] = pca_df[col].apply(lambda x: np.mean(x) if np.any(x) else np.nan)

    return pca_df


def cargar_modelos_y_predecir(df_a_predecir, cols_action, cols_object, cols_obmod):
    """Funcion que carga el modelo entrenado"""

    # Cargar los modelos desde los archivos .pkl
    modelo_action = joblib.load(config.MODELS_DIR.joinpath(config.MODELOS["action"]))
    modelo_object = joblib.load(config.MODELS_DIR.joinpath(config.MODELOS["object"]))
    modelo_objectmod = joblib.load(config.MODELS_DIR.joinpath(config.MODELOS["objectmod"]))

    # Crear instancias de SimpleImputer para cada conjunto de columnas
    imputer = SimpleImputer(strategy="mean")

    # Aplicar la imputación a las columnas específicas
    df_a_predecir[cols_action] = imputer.fit_transform(df_a_predecir[cols_action])
    df_a_predecir[cols_object] = imputer.fit_transform(df_a_predecir[cols_object])
    df_a_predecir[cols_obmod] = imputer.fit_transform(df_a_predecir[cols_obmod])

    # Filtrar el DataFrame de entrada para incluir solo las columnas relevantes
    df_a_predecir_action = df_a_predecir[cols_action]
    df_a_predecir_object = df_a_predecir[cols_object]
    df_a_predecir_objectmod = df_a_predecir[cols_obmod]

    # Realizar predicciones de probabilidad para Action
    pred_proba_action = modelo_action.predict_proba(df_a_predecir_action)

    # Realizar predicciones de probabilidad para Object
    pred_proba_object = modelo_object.predict_proba(df_a_predecir_object)

    # Realizar predicciones de probabilidad para Object
    pred_proba_objectmod = modelo_objectmod.predict_proba(df_a_predecir_objectmod)

    # Filtrar el DataFrame por el umbral
    resultados = pd.DataFrame()
    pred_proba_action_filtradas = [x[1] for x in pred_proba_action if x[1]]
    pred_proba_object_filtradas = [x[1] for x in pred_proba_object if x[1]]
    pred_proba_objectmod_filtradas = [x[1] for x in pred_proba_objectmod if x[1]]

    # Crear un DataFrame para almacenar los resultados
    resultados["pred_proba_action"] = pred_proba_action_filtradas
    resultados["pred_proba_object"] = pred_proba_object_filtradas
    resultados["pred_proba_objectmod"] = pred_proba_objectmod_filtradas
    resultados["Alcance"] = df_a_predecir["Alcance"]
    resultados["action"] = df_a_predecir["ac_corr"]
    # resultados['Action_modifier'] = df_a_predecir['ACMOD_pred']
    resultados["object"] = df_a_predecir["OB_pred"]
    resultados["object_modifier"] = df_a_predecir["OBMOD_pred"]

    return resultados
