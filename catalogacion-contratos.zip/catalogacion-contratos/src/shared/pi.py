"""Módulo de funciones para interactuar con PI"""

import base64
import json
import traceback

import requests
import urllib3
from requests.auth import HTTPBasicAuth

from config.config import logger


class PiWebapi:
    """
    Clase para encapsular las llamadas a la API de PI
    """

    def __init__(
        self,
        webapi_url: str,
        path: str,
        webapi_security_method: str,
        verify_ssl: bool,
        webapi_user: str,
        webapi_password: str,
    ):
        self._webapi_url = webapi_url
        self._path = path
        self._webapi_security_method = webapi_security_method
        self._verify_ssl = verify_ssl
        self._webapi_user = webapi_user
        self._webapi_password = webapi_password

        urllib3.disable_warnings()

    @property
    def web_api_url(self) -> str:
        """
        Returns:
            str: URL de la PI WebAPI
        """
        return self._webapi_url

    @web_api_url.setter
    def web_api_url(self, value):
        self._webapi_url = value

    @property
    def path(self) -> str:
        """
        Returns:
            str: Path de la PI WebAPI
        """
        return self._path

    @path.setter
    def path(self, value):
        self._path = value

    @property
    def webapi_security_method(self) -> str:
        """
        Returns:
            str: Método de autenticación
        """
        return self._webapi_security_method

    @webapi_security_method.setter
    def webapi_security_method(self, value):
        self._webapi_security_method = value

    @property
    def verify_ssl(self) -> bool:
        """
        Returns:
            bool: Verificación para conexión segura
        """
        return self._verify_ssl

    @verify_ssl.setter
    def verify_ssl(self, value):
        self._verify_ssl = value

    @property
    def webapi_user(self) -> str:
        """
        Returns:
            str: Usuario para conectarse a la PI WebAPI
        """
        return self._webapi_user

    @webapi_user.setter
    def webapi_user(self, value):
        self._webapi_user = value

    @property
    def webapi_password(self) -> str:
        """
        Returns:
            str: Password para conectarse a la PI WebAPI
        """
        return self._webapi_password

    @webapi_password.setter
    def webapi_password(self, value):
        self._webapi_password = value

    def call_security_method(self):
        """Método de seguridad de llamada de la API
        Propiedades:
        webapi_security_method string: Método de seguridad a usar: basic o kerberos
        webapi_user string: Nombre de la credencial del usuario
        webapi_password string: Contraseña de la credencial del usuario
        """

        logger.debug("[callSecurityMethod] Inicia")

        security_auth = None

        try:
            if self.webapi_security_method.lower() == "basic":
                security_auth = HTTPBasicAuth(self.webapi_user, self.webapi_password)
            else:
                logger.warning(
                    "El metodo de autenticación Kerberos no está admitido en entornos Linux"
                )
                # securityAuth = HTTPKerberosAuth(mutual_authentication='REQUIRED',
                #                                sanitize_mutual_error_response=False)

            logger.debug("[callSecurityMethod] Finaliza")

        except requests.RequestException as e:
            logger.error("Se produjo un error al tratar de autenticar: %s.", str(e))
            logger.error("Error: %s", traceback.format_exc())

        return security_auth

    def generate_webid_from_path(self, full_path):
        """Genera el WebId encodificando el Path completo (Path + Tag) pasado como parámetro
        @param full_path string: Nombre de Path + Tag a convertir
        """

        logger.debug("[generateWebIdFromPath] Inicia")

        webid = ""
        fullpath_string = full_path.upper()
        fullpath_bytes = fullpath_string.encode("utf-8")

        webid = base64.b64encode(fullpath_bytes)
        webid = webid.decode("utf-8")
        webid = "P1AbE" + webid
        # P1AbE = header interno. https://docs.osisoft.com/bundle/
        # pi-web-api-reference/page/help/topics/webid-encoded-datatypes.html

        logger.debug("[generateWebIdFromPath] Finaliza")

        return webid

    def get_summary_data(
        self,
        security_auth,
        webid,
        start_time="-1d",
        end_time="*",
        summary_type="Average",
        duration="5m",
    ):
        """Devuelve un diccionario con una serie de tiempo para el WebId pasado como parámetro
        @param security_auth: Referencia securityAuth
        @param webid string: ID del Stream
        @param start_time string: Inicio del Stream (default -1d, es decir,
                                de la fecha actual, un día para atras)
        @param end_time string: Fin del Stream (default *, es decir, hasta el último valor)
        @param summary_type string: Clase de agregación (default es Average)
        @param duration string: Duración de cada intervalo (default es 5m, es decir,
                                cada 5 minutos)
        Propiedades:
        web_api_url string: URL de PI Web API
        verify_ssl bool: Si se realizará la verificación del certificado

        Ejemplo:
        https://swpnqntaspi23.grupo.ypf.com/piwebapi/streams/I1DPaYSBql4duEeKhGnk4sJJsw044AAA/summary?
            summaryType=Average&startTime=%222020-12-17%2012:49:00.000%22&
            endTime=%222020-12-17%2015:40:00.000%22&summaryDuration=5m&
            selectedfields=items.value.timestamp;items.value.value
        """

        logger.debug("[getSummaryData] Inicia")

        data = ""
        status = 0

        proxies = {
            "http": "http://proxy-ypf.grupo.ypf.com",
            "https": "http://proxy-ypf.grupo.ypf.com",
        }

        try:
            #  armo la URL y obtengo los datos del Stream para los parámetros especificados
            request_url = (
                f"{self.web_api_url}/streams/{webid}/summary?summaryType={summary_type}&"
                f"startTime=%22{start_time}%22&endTime=%22{end_time}%22&summaryDuration={duration}&"
                "maxCount=10000&selectedfields=items.value.timestamp;items.value.value"
            )

            logger.debug("request_url: %s", request_url)

            # Leer el conjunto de valores
            respuesta = requests.get(
                request_url,
                auth=security_auth,
                verify=self.verify_ssl,
                timeout=120,
                proxies=proxies,
            )
            status = respuesta.status_code

            if status == 200:
                data = json.loads(respuesta.text)
            else:
                logger.error(
                    "Se produjo un error al tratar de obtener los datos de PI. Error: %s, %s",
                    status,
                    respuesta.reason,
                )

            logger.debug("[getSummaryData] Finaliza")

        except requests.RequestException as e:
            logger.error("Se produjo un error al tratar de obtener los datos de PI: %s.", str(e))
            logger.error("Error: %s", traceback.format_exc())

        return [status, data]

    def get_recorded_data(
        self,
        security_auth,
        webid,
        start_time="-1d",
        end_time="*",
    ):
        """Devuelve un diccionario con una serie de tiempo para el WebId pasado como parámetro
        @param security_auth: Referencia securityAuth
        @param webid string: ID del Stream
        @param start_time string: Inicio del Stream (default -1d, es decir,
                                de la fecha actual, un día para atras)
        @param end_time string: Fin del Stream (default *, es decir, hasta el último valor)
        Propiedades:
        web_api_url string: URL de PI Web API
        verify_ssl bool: Si se realizará la verificación del certificado

        Ejemplo:
        https://swpnqntaspi23.grupo.ypf.com/piwebapi/streams/I1DPaYSBql4duEeKhGnk4sJJsw044AAA/summary?
            summaryType=Average&startTime=%222020-12-17%2012:49:00.000%22&
            endTime=%222020-12-17%2015:40:00.000%22&summaryDuration=5m&
            selectedfields=items.value.timestamp;items.value.value
        """

        logger.debug("[get_recorded_data] Inicia")

        data = ""
        status = 0

        proxies = {
            "http": "http://proxy-ypf.grupo.ypf.com",
            "https": "http://proxy-ypf.grupo.ypf.com",
        }

        try:
            #  armo la URL y obtengo los datos del Stream para los parámetros especificados
            request_url = (
                f"{self.web_api_url}/streams/{webid}/recorded?startTime=%22{start_time}%22&"
                f"endTime=%22{end_time}%22&maxCount=10000&selectedfields=items.timestamp;"
                "items.value"
            )

            logger.debug("request_url: %s", request_url)

            # Leer el conjunto de valores
            respuesta = requests.get(
                request_url,
                auth=security_auth,
                verify=self.verify_ssl,
                timeout=120,
                proxies=proxies,
            )
            status = respuesta.status_code

            if status == 200:
                data = json.loads(respuesta.text)
            else:
                logger.error(
                    "Se produjo un error al tratar de obtener los datos de PI. Error: %s",
                    respuesta,
                )

            logger.debug("[get_recorded_data] Finaliza")

        except requests.RequestException as e:
            logger.error("Se produjo un error al tratar de obtener los datos de PI: %s.", str(e))
            logger.error("Error: %s", traceback.format_exc())

        return [status, data]
