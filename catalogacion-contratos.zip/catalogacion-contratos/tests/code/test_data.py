"""utilidades de procesamiento de datos - test"""

import os
import shutil
import pytest
from unittest import mock
from config import config
from src.shared import blob_storage as blob
import sys

from src.data import (
    upload_log,
    upload_data,
    download_novedades,
    download_vector,
)


@pytest.fixture
def setup_test_environment(tmp_path):
    # Configura el directorio de entrada de datos simulados
    config.DATA_INPUT_DIR = tmp_path / "input"

    # Copia datos de entrada simulados a tmp_path
    test_input_dir = os.path.join("tests", "code", "test_data", "input")
    shutil.copytree(test_input_dir, config.DATA_INPUT_DIR)

    yield

@pytest.fixture
def mock_blob_upload_data_to_blob_storage():
    # Creamos un mock del método blob_storage.upload_data_to_blob_storage()
    with mock.patch("src.shared.blob_storage.upload_data_to_blob_storage") as mock_upload:
        yield mock_upload

@pytest.fixture
def mock_blob_upload_log_to_blob_storage():
    # Creamos un mock del método blob_storage.upload_log_to_blob_storage()
    with mock.patch("src.shared.blob_storage.upload_log_to_blob_storage") as mock_upload:
        yield mock_upload

@pytest.fixture
def mock_blob_download_data_from_blob_storage():
    # Creamos un mock del método blob_storage.download_data_from_blob_storage()
    with mock.patch("src.shared.blob_storage.download_data_from_blob_storage") as mock_download:
        yield mock_download

@pytest.fixture
def mock_blob_download_vector_from_blob_storage():
    # Creamos un mock del método blob_storage.download_vector_from_blob_storage()
    with mock.patch("src.shared.blob_storage.download_vector_from_blob_storage") as mock_download_vector:
        yield mock_download_vector

@pytest.fixture
def mock_sys_exit():
    # Creamos un mock de sys.exit
    with mock.patch.object(sys, 'exit') as mock_exit:
        yield mock_exit

@pytest.fixture
def mock_logger():
    # Creamos un mock del objeto logger
    with mock.patch("src.data.logger") as mock_logger:
        yield mock_logger

def test_upload_log(mock_blob_upload_log_to_blob_storage):
    upload_log()
    mock_blob_upload_log_to_blob_storage.assert_called_once()

def test_upload_data(mock_blob_upload_data_to_blob_storage):
    upload_data()
    mock_blob_upload_data_to_blob_storage.assert_called_once()

def test_download_vector(mock_blob_download_vector_from_blob_storage):
    download_vector()
    mock_blob_download_vector_from_blob_storage.assert_called_once()

def test_download_novedades_archivo_existente(setup_test_environment, tmp_path, mock_logger, mock_blob_download_data_from_blob_storage, mock_blob_upload_log_to_blob_storage):
    input_file = tmp_path / "input/80_pp_V3_R02.xlsx"

    download_novedades(input_file)

    # Asegura que el archivo se descargó correctamente
    assert mock_blob_download_data_from_blob_storage.call_count == 1
    assert mock_logger.info.call_count == 1
    mock_logger.info.assert_called_with("Archivo descargado: %s", input_file)
    assert input_file.exists()

def test_download_novedades_archivo_inexistente(setup_test_environment, tmp_path, mock_logger, mock_sys_exit, mock_blob_download_data_from_blob_storage, mock_blob_upload_log_to_blob_storage):
    input_file = tmp_path / "input/archivo_inexistente.xlsx"

    # Configura el blob para lanzar una excepción de archivo inexistente
    mock_blob_download_data_from_blob_storage.side_effect = blob.ArchivoInexistente("No existe el archivo")

    download_novedades(input_file)

    # Asegura que el logger registró el error y se llamó para cargar el log
    assert mock_logger.error.call_count == 1
    assert mock_logger.error.call_args[0][0].value == 'No existe el archivo'
    assert not input_file.exists()

    # Asegura que sys.exit(1) se llamó
    mock_sys_exit.assert_called_once_with(1)
