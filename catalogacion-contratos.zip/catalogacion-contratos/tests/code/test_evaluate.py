"""componentes de evaluación - test"""

import warnings

import numpy as np
import pandas as pd
from numpy.testing import assert_almost_equal

from src import evaluate

warnings.filterwarnings("ignore")


def test_get_slice_metrics():
    # Arrange
    y_true = np.array([1, 0, 1, 1, 0, 1])
    y_pred = np.array([1, 0, 1, 0, 1, 1])
    slices = np.recarray((6,), dtype=[("slice1", "bool"), ("slice2", "bool"), ("slice3", "bool")])
    slices.slice1 = [True, False, False, True, True, False]
    slices.slice2 = [False, True, True, False, False, False]
    slices.slice3 = [False, False, False, False, True, True]

    # Act
    metrics = evaluate.get_slice_metrics(y_true, y_pred, slices)

    # Assert
    assert_almost_equal(metrics["slice1"]["precision"], 0.0, decimal=2)
    assert_almost_equal(metrics["slice1"]["recall"], 0.0, decimal=2)
    assert_almost_equal(metrics["slice1"]["f1"], 0.0, decimal=2)
    assert metrics["slice1"]["num_samples"] == 3

    assert_almost_equal(metrics["slice2"]["precision"], 0.0, decimal=2)
    assert_almost_equal(metrics["slice2"]["recall"], 0.0, decimal=2)
    assert_almost_equal(metrics["slice2"]["f1"], 0.0, decimal=2)
    assert metrics["slice2"]["num_samples"] == 2

    assert_almost_equal(metrics["slice3"]["precision"], 0.0, decimal=2)
    assert_almost_equal(metrics["slice3"]["recall"], 0.0, decimal=2)
    assert_almost_equal(metrics["slice3"]["f1"], 0.0, decimal=2)
    assert metrics["slice3"]["num_samples"] == 2


def test_get_metrics():
    # Arrange
    y_true = np.array([1, 2, 3, 4])
    y_pred = np.array([2, 3, 1, 4])
    classes = [1, 2, 3, 4]
    df = pd.DataFrame({"text": ["This is a sentence.", "Another sentence."], "label": [1, 2]})

    # Test class metrics
    # Act
    metrics = evaluate.get_metrics(y_true, y_pred, classes)

    # Assert
    assert np.isclose(metrics["overall"]["precision"], 0.0)
    assert np.isclose(metrics["overall"]["recall"], 0.0)
    assert np.isclose(metrics["overall"]["f1"], 0.0)
    assert metrics["overall"]["num_samples"] == 4

    assert np.isclose(metrics["class"][1]["precision"], 0.0)
    assert np.isclose(metrics["class"][1]["recall"], 0.0)
    assert np.isclose(metrics["class"][1]["f1"], 0.0)
    assert metrics["class"][1]["num_samples"] == 0.0

    assert np.isclose(metrics["class"][2]["precision"], 0.0)
    assert np.isclose(metrics["class"][2]["recall"], 0.0)
    assert np.isclose(metrics["class"][2]["f1"], 0.0)
    assert metrics["class"][2]["num_samples"] == 0.0

    assert np.isclose(metrics["class"][3]["precision"], 0.0)
    assert np.isclose(metrics["class"][3]["recall"], 0.0)
    assert np.isclose(metrics["class"][3]["f1"], 0.0)
    assert metrics["class"][3]["num_samples"] == 0.0

    assert np.isclose(metrics["class"][4]["precision"], 0.0)
    assert np.isclose(metrics["class"][4]["recall"], 0.0)
    assert np.isclose(metrics["class"][4]["f1"], 0.0)
    assert metrics["class"][4]["num_samples"] == 0.0

    # Test slice metrics
    # Act
    metrics = evaluate.get_metrics(y_true, y_pred, classes, df)

    # Assert
    assert metrics["slices"] is not None
    assert np.isclose(metrics["slices"]["slice1"]["precision"], 0.0)
    assert np.isclose(metrics["slices"]["slice1"]["recall"], 0.0)
    assert np.isclose(metrics["slices"]["slice1"]["f1"], 0.0)
    assert metrics["slices"]["slice1"]["num_samples"] == 2
    assert np.isclose(metrics["slices"]["slice2"]["precision"], 0.0)
    assert np.isclose(metrics["slices"]["slice2"]["recall"], 0.0)
    assert np.isclose(metrics["slices"]["slice2"]["f1"], 0.0)
    assert metrics["slices"]["slice2"]["num_samples"] == 2
