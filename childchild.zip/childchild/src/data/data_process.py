"""Módulo para las funciones ETL especificas del proyecto"""
import logging as log
import sys
import traceback
from datetime import timedelta
from typing import Dict

import numpy as np
import pandas as pd

import functions.function_for_childchild as f_child
import functions.functions_download as f_down
import functions.functions_pi as pi

cfgs: Dict[str, str] = {}


def get_webid(pi_webapi: pi.PiWebapi, tag: str) -> str:
    """
    Genera el id que corresponde al tag, para, posteriormente, consultar la base de PI

    Args:
        pi_webapi (pi.PiWebapi): instancia de la clase PiWebapi, la cual contiene los atributos
                                 para conectarse y extraer datos de PI
        tag (str): Tag a buscar en PI

    Returns:
        str: webid para poder armar la query para PI
    """
    webid = pi_webapi.generate_webid_from_path(rf"{pi_webapi.path}\{tag}")
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("Path: %s, tag: %s, webid: %s", pi_webapi.path, tag, webid)

    return webid


def get_presion(
    pi_webapi: pi.PiWebapi, tag: str, inicio: str, fin: str
) -> pd.DataFrame:
    """
    Ejecuta la consulta en la base de PI

    Args:
        pi_webapi (pi.PiWebapi): instancia de la clase PiWebapi, la cual contiene los atributos
                                 para conectarse y extraer datos de PI
        tag (str): Tag a buscar en PI
        inicio (str): fecha de inicio para la bajada de datos
        fin (str): fecha de fin para la bajada de datos

    Returns:
        pd.DataFrame: dataframe con los valores obtenidos de PI
    """
    webid = get_webid(pi_webapi=pi_webapi, tag=tag)

    security_auth = pi_webapi.call_security_method()
    presiones = pi_webapi.get_summary_data(
        security_auth=security_auth, webid=webid, start_time=inicio, end_time=fin
    )
    list_data = list(presiones[1].values())
    data = list_data[0]
    df_data = pd.json_normalize(data)

    return df_data


def bajada_presiones(
    eventos_fp: str, eventos_procesados: list, **data_struct
) -> pd.DataFrame:
    """
    Genera un dataframe con la base de presiones.
    Realiza la bajada de presiones dsede PI para cada registro de la base de eventos.

    Args:
        eventos_fp (str): file path de la base de eventos
        eventos_procesados (list): lista de eventos a excluir.

    Returns:
        pd.DataFrame: dataframe con la base de presiones
    """
    pi_webapi_user = "YS01480"
    pi_webapi_password = "2gY7akMz"
    pi_webapi_security_method = "basic"
    pi_verify_ssl = False
    pi_webapi_url = "https://swpnqntaspi23.grupo.ypf.com/piwebapi"
    pi_path = "ssbuetmspi01"

    pi_webapi = pi.PiWebapi(
        pi_webapi_url,
        pi_path,
        pi_webapi_security_method,
        pi_verify_ssl,
        pi_webapi_user,
        pi_webapi_password,
    )

    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[bajada_presiones] Inicia")

    pi.cfgs = cfgs

    try:
        # Estructura de los archivos, con valores default
        column_inicio = data_struct.get("column_inicio_bajada", "inicioBajadaDatos")
        column_fin = data_struct.get("column_fin_bajada", "finBajadaDatos")
        column_tag = data_struct.get("column_tag_hermano", "TAG_HERMANO")
        column_evento_id = data_struct.get("column_evento_id", "ID_EVENTO")

        df_eventos = pd.read_csv(eventos_fp)
        # Eliminamos los que no tienen tag
        df_eventos.dropna(subset=[column_tag], inplace=True)
        # Excluimos los eventos ya procesados
        df_eventos = df_eventos[~df_eventos[column_evento_id].isin(eventos_procesados)]
        p_logger.info("Cantidad eventos a procesar: %s", len(df_eventos.index))

        df_data_full = pd.DataFrame()
        for evento_id, tag, inicio, fin in zip(
            df_eventos[column_evento_id],
            df_eventos[column_tag],
            df_eventos[column_inicio],
            df_eventos[column_fin],
        ):
            df_data = get_presion(
                pi_webapi=pi_webapi,
                tag=tag,
                inicio=inicio,
                fin=fin,
            )
            p_logger.debug("Evento: %s", evento_id)
            df_data[column_evento_id] = evento_id
            df_data.rename(
                columns={
                    "Value.Timestamp": "Timestamp",
                    "Value.Value": "Valor",
                    "Value.Errors": "Error",
                },
                inplace=True,
            )

            list_from_str_to_datetime = [
                "Timestamp",
            ]
            df_data = f_down.to_datetime(df_data, list_from_str_to_datetime)
            df_data["Timestamp"] = df_data["Timestamp"] - timedelta(hours=3)
            df_data["Timestamp"] = pd.to_datetime(df_data["Timestamp"]).dt.tz_convert(
                None
            )
            df_data_full = pd.concat([df_data_full, df_data])

        p_logger.info("Cantidad de registros de presiones: %s", len(df_data_full.index))
        p_logger.debug("[bajada_presiones] Finaliza")

        return df_data_full

    except OSError as e:
        p_logger.error("Se produjo un error(%s): %s", e.errno, e.strerror)
        p_logger.error(traceback.format_exc())
        return None


def armado_df_para_bajada_presiones(
    sensores_fp: str,
    childchild_fp: str,
    eventos_procesados: list,
    fecha_minima: str = None,
    **data_struct,
) -> pd.DataFrame:
    """
    Genera un dataframe para la base de eventos.
    Realiza algunas verificaciones y transformaciones.
    Luego unifica las bases de child child y la de sensores.
    Por último agrega las fechas de inicio y fin, para la bajada de presiones.

    Args:
        sensores_fp (str): file path de la base de sensores.
        childchild_fp (str): file path de la base child child.
        eventos_procesados (list): lista de eventos a excluir.
        fecha_minima (str, optional): permite acotar los eventos. Defaults to None.
        data_struct (dict): diccionario con los nombres de los campos.
            Este diccionario tiene que tener las siguientes claves.
            A las claves que no vengan en el diccionario, se le asigna el default
            column_hijo ("HIJO")
            column_tag_hijo ("TAG_P")
            column_hermano ("HERMANO")
            column_rig ("RIG")
            column_inicio_frac ("INICIO_FRAC")
            column_fin_frac ("FIN_FRAC")
            column_inicio_bu ("INICIO_BU")
            column_inicio_fo ("INICIO_FO")
            column_evento_id ("ID_EVENTO")
            column_etapa ("ETAPA")

    Returns:
        pd.DataFrame: dataframe con la base de eventos
    """

    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[armado_df_para_bajada_presiones] Inicia")

    try:

        # Estructura de los archivos, con valores default
        column_hijo = data_struct.get("column_hijo", "HIJO")
        column_tag_hijo = data_struct.get("column_tag_hijo", "TAG_P")
        column_hermano = data_struct.get("column_hermano", "HERMANO")
        column_rig = data_struct.get("column_rig", "RIG")
        column_inicio_frac = data_struct.get("column_inicio_frac", "INICIO_FRAC")
        column_fin_frac = data_struct.get("column_fin_frac", "FIN_FRAC")
        column_inicio_bu = data_struct.get("column_inicio_bu", "INICIO_BU")
        column_inicio_fo = data_struct.get("column_inicio_fo", "INICIO_FO")
        column_evento_id = data_struct.get("column_evento_id", "ID_EVENTO")
        column_etapa = data_struct.get("column_etapa", "ETAPA")

        # Las siguientes son columnas agregadas al dataset de origen
        # no pertenece al set de input features
        column_tag_hermano = "TAG_HERMANO"
        inicio_bajada_datos = "inicioBajadaDatos"
        fin_bajada_datos = "finBajadaDatos"

        # 1 -- Lectura de dos archivos:
        # archivo 1 --> datos de los eventos (base child child)
        # archivo 2 --> datos de los TAGs de los eventos (base sensores)
        df = pd.read_csv(childchild_fp)
        # Excluimos los eventos ya procesados
        df = df[~df[column_evento_id].isin(eventos_procesados)]
        p_logger.info("Cantidad eventos a procesar: %s", len(df.index))

        df_sensores_tmp = pd.read_csv(sensores_fp, sep=";")
        # Tomamos solo los sensores "buenos"
        df_sensores = df_sensores_tmp[df_sensores_tmp["SENSORES Y/N"] == "Y"]
        df_sensores = df_sensores.dropna(subset=[column_tag_hijo])
        p_logger.info("Cantidad sensores: %s", len(df_sensores.index))

        listfeatures_df_childchild = [
            column_hijo,
            column_hermano,
            column_rig,
            column_inicio_frac,
            column_fin_frac,
            column_inicio_bu,
            column_inicio_fo,
        ]

        #  chequeamos que todas las variables esten en los dfs de entrada
        if len(f_down.features_in_df(df, listfeatures_df_childchild)) > 0:
            p_logger.error(
                "[armado_df_para_bajada_presiones] faltan o cambiaron de nombre "
                "las siguientes variables %s",
                str(f_down.features_in_df(df, listfeatures_df_childchild)),
            )
            sys.exit()

        list_from_str_to_datetime = [
            column_inicio_frac,
            column_fin_frac,
            column_inicio_bu,
            column_inicio_fo,
        ]
        df = f_down.to_datetime(df, list_from_str_to_datetime)

        #  'Opcional:'
        # ' Si queremos acotar los eventos luego de una determinada fecha'
        if fecha_minima is not None:
            p_logger.info(
                "[armado_df_para_bajada_presiones] "
                "Acotamos los eventos luego de una determinada fecha"
            )
            df = f_down.fecha_inicial(df, column_inicio_frac, fecha_minima)
            if df.empty:
                p_logger.warning(
                    "[armado_df_para_bajada_presiones] No hay datos a partir de %s",
                    fecha_minima,
                )
                sys.exit()

        # 2 -- Unificamos en un solo archivo los datos particulares de cada evento con los TAG
        # de los pozos "HIJO"
        # Registro de mas de un sensor/TAG por pozo HIJO (estimulado)

        #  IMPORTANTE: luego de conversar con Yann, él nos comento que el tiempo de inicio de FO,
        #  la mayoria de las veces, es posterior a la fecha del fin de fractura, por lo que nos
        #  conviene poner como tiempo de fin de bajada de datos --> "finBajadaDatos" + 60 min,
        #  para segurarnos que tendremos el momento de inico de FO registrado en los perfiles
        df_eventos_clasificados = f_down.merge_dfs(
            df,
            df_sensores,
            column_hijo,
            column_hermano,
            column_rig,
        )
        p_logger.info(
            "Cantidad eventos despues de mergear con sensores: %s",
            len(df_eventos_clasificados.index),
        )

        df_eventos_clasificados = df_eventos_clasificados.drop(
            columns={column_inicio_frac, column_fin_frac}
        )
        df_eventos_clasificados = df_eventos_clasificados.rename(
            columns={
                "INICIO_FRAC_x": column_inicio_frac,
                "FIN_FRAC_x": column_fin_frac,
                "HIJO_x": column_hijo,
                "TAG_P_x": column_tag_hijo,
                "TAG_P_y": column_tag_hermano,
            }
        )

        # 3 -- Agragamos dos columnas al df para fines de bajada de datos:
        # Transformamos las columnas de tiempo que estan en "str" a numpy.datetime64()
        ref_maxtime = np.datetime64("2050-08-09T17:47:00.000000000")
        add_time_units = "m"
        add_time_value = 60

        #  fecha inicial para bajar datos 'inicioBajadaDatos'
        df_eventos_clasificados[inicio_bajada_datos] = f_down.get_list_min_time(
            df_eventos_clasificados,
            inicio_bajada_datos,
            column_inicio_frac,
            column_inicio_bu,
            ref_maxtime,
        )

        #  fecha final para bajar datos 'finBajadaDatos'
        df_eventos_clasificados[fin_bajada_datos] = f_down.get_list_max_time(
            df_eventos_clasificados,
            column_fin_frac,
            column_inicio_fo,
            add_time_units,
            add_time_value,
        )

        df_eventos_clasificados = df_eventos_clasificados[
            [
                column_evento_id,
                column_hijo,
                column_etapa,
                column_hermano,
                column_inicio_frac,
                column_fin_frac,
                column_tag_hijo,
                inicio_bajada_datos,
                fin_bajada_datos,
                column_tag_hermano,
            ]
        ]

        p_logger.info(
            "Cantidad eventos a clasificar: %s", len(df_eventos_clasificados.index)
        )
        p_logger.debug("[armado_df_para_bajada_presiones] Finaliza")

        # 4 --  Archivo listo para bajar los datos de presion por evento
        return df_eventos_clasificados

    except OSError as e:
        p_logger.error("Se produjo un error(%s): %s", e.errno, e.strerror)
        p_logger.error(traceback.format_exc())
        return None


def get_eventos_procesados(
    eventos_procesados_fp: str,
    column_evento_id: str,
) -> list:
    """
    Obtener lista de eventos que ya fueron procesados

    Args:
        eventos_procesados_fp (str): file path del archivo con los eventos que ya fueron procesados
        column_evento_id (str): nombre de la columna que identifica el registro

    Returns:
        list: lista de eventos procesados
    """
    df_eventos_procesados = pd.read_csv(
        eventos_procesados_fp, usecols=[column_evento_id]
    )
    eventos = df_eventos_procesados[column_evento_id].tolist()

    return eventos


def set_eventos_procesados(
    eventos: list,
    eventos_procesados_fp: str,
    column_evento_id: str,
) -> None:
    """
    Guardar el archivo de eventos procesados.
    Se debe pasar una lista con los eventos originalmente procesados
    mas los eventos procesados en la última ejecución.
    Si queremos reprocesar todo hay que pasar una lista vacía.

    Args:
        eventos (list): lista de eventos procesados
        eventos_procesados_fp (str): file path del archivo con los eventos que ya fueron procesados.
        column_evento_id (str): nombre de la columna que identifica el registro
    """
    df_eventos_procesados = pd.DataFrame(eventos, columns=[column_evento_id])
    df_eventos_procesados.to_csv(eventos_procesados_fp, index=False)


def generate_eventos_procesados(
    resultado_fp: str,
    eventos_procesados_fp: str,
    column_evento_id: str,
) -> None:
    """
    Genera el archivo de eventos procesados.
    Esta función debe usarse si queremos volver a generar el archivos
    de eventos procesados a partir del archivo de resultados.

    Args:
        resultado_fp (str): file path del archivo final que usará Power BI.
        eventos_procesados_fp (str): file path del archivo con los eventos que ya fueron procesados.
        column_evento_id (str): nombre de la columna que identifica el registro
    """
    df_resultado = pd.read_csv(resultado_fp, usecols=[column_evento_id])
    df_resultado.to_csv(eventos_procesados_fp, index=False)


def armado_df_para_clasificacion(
    eventos_fp: str,
    presiones_fp: str,
    eventos_presiones_fp: str,
    time_limit: int,
    porcentaje_filtrado: int,
    numero_datos: int,
    **data_struct,
) -> pd.DataFrame:
    """
    Genera el dataframe para ser consumido por el modelo

    Args:
        eventos_fp (str): file path de la base de eventos.
        presiones_fp (str): file path de la base de presiones.
        eventos_presiones_fp (str): file path de la base combinada de eventos y presiones.
        time_limit (int): valor para acotar el limite temporal de los eventos.
        porcentaje_filtrado (int): porcentaje de datos NaN para decidir si incluimos el evento.
        numero_datos (int): cantidad de datos a interpolar.

    Returns:
        pd.DataFrame: dataframe de eventos con predicciones
    """
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[armado_df_para_clasificacion] Inicia")

    try:

        # Estructura de los archivos, con valores default
        column_inicio_frac = data_struct.get("column_inicio_frac", "INICIO_FRAC")
        column_fin_frac = data_struct.get("column_fin_frac", "FIN_FRAC")
        column_evento_id = data_struct.get("column_id_evento", "ID_EVENTO")
        column_time = data_struct.get("column_time", "Timestamp")
        column_presion = data_struct.get("column_presion", "Valor")

        # Lectura de los dos archivos:"
        # (1) primer archivo:  caracteristicas de las interferencias
        # (2) segundo archivo:  distribucion de presiones por cada evento
        df_presiones = pd.read_csv(presiones_fp)
        df_referencia = pd.read_csv(eventos_fp)
        p_logger.info("Cantidad eventos a procesar: %s", len(df_referencia.index))

        # Como la columna "Valor" es un str, la cambiamos a float
        # Transformamos la columna 'Timestamp' de str a numpy.datetime64()
        df_presiones[column_presion] = pd.to_numeric(
            df_presiones[column_presion], errors="coerce"
        )
        list_from_str_to_datetime = [
            column_time,
        ]
        df_presiones = f_down.to_datetime(df_presiones, list_from_str_to_datetime)

        # Abrimos el archivo con los perfiles de presiones
        # Hacemos el merge entre el df de eventos clasificados y de presiones de los
        # pozos hermanos (este merge es un pozo rústico, ver si hay otras opciones
        # para mergeara las dos columnas del archivo de presiones de pozos hermanos como listas
        df_eventos = df_referencia.merge(df_presiones, how="inner", on=column_evento_id)
        p_logger.info(
            "Cantidad eventos despues de mergear con sensores: %s",
            len(df_eventos.index),
        )
        if len(df_eventos.index) == 0:
            return None

        list_from_str_to_datetime = [
            column_inicio_frac,
            column_fin_frac,
            column_time,
        ]
        df_eventos = f_down.to_datetime(df_eventos, list_from_str_to_datetime)
        df_eventos.to_csv(eventos_presiones_fp, index=False)

        # Objetivos -->
        # (1) dado un set de datos de entrada, armar un df listo para aplicarsele el modelo
        # (2) a este df con las predicciones, calcular los ptos criticos
        #     de los eventos interferidos

        # Acota la lista de valores de presiones a medicionas hechas hasta un limte
        # temporal fijo para todos los tipos de eventos.
        df_referencia_filtrado = f_child.df_with_time_limit(
            df_eventos,
            column_fin_frac,
            column_time,
            column_evento_id,
            time_limit,
        )

        # Si cada evento tiene mas del 50% de los datos Nan, lo quitamos del df
        df_referencia_filtrado_clean = f_child.clean_data(
            df_referencia_filtrado,
            column_evento_id,
            column_presion,
            porcentaje_filtrado,
        )
        if df_referencia_filtrado_clean.empty:
            return None

        # (1) Interpolamos a {numeroDatos} puntos de presion
        # desde el inicio de la fractura hasta 30 min luego del fin del la fractura
        # A partir de aca, el df generado sólo contiene los puntos de presion por cada evento
        df_referencia_filtrado_clean_norm = (
            f_child.ajuste_number_of_data_df_for_model_v2(
                df_referencia_filtrado_clean,
                column_evento_id,
                column_time,
                column_presion,
                numero_datos,
            )
        )

        # Agregamos los "ID" de cada evento
        df_referencia_filtrado_clean_norm_with_id = (
            f_child.ajuste_number_of_data_df_for_model_with_id(
                df_referencia_filtrado_clean_norm,
                df_referencia_filtrado_clean,
                column_evento_id,
            )
        )

        columns_to_include = [
            "1_diff",
            "2_diff",
            "3_diff",
            "4_diff",
            "5_diff",
            "6_diff",
            "7_diff",
            "8_diff",
            "9_diff",
            "10_diff",
            "11_diff",
            "12_diff",
            "13_diff",
            "14_diff",
            "15_diff",
            "16_diff",
            "17_diff",
            "18_diff",
            "19_diff",
            "20_diff",
            "21_diff",
            "22_diff",
            "23_diff",
            "24_diff",
            "25_diff",
            "26_diff",
            "27_diff",
            "28_diff",
            "29_diff",
            "30_diff",
            "31_diff",
            "32_diff",
            "33_diff",
            "34_diff",
        ]

        # recive eventos por filas (1 evento = 1 fila)
        df_derivadas_presiones = f_child.calculate_derivadas(
            df_referencia_filtrado_clean_norm, columns_to_include
        )

        # Finalmente concatemanmos POR COLUMNA las tres df
        df_final_for_model = f_child.concat_dfder_dfpres(
            df_referencia_filtrado_clean_norm,
            df_referencia_filtrado_clean_norm_with_id,
            df_derivadas_presiones,
            column_evento_id,
        )

        p_logger.info("Cantidad final de registros: %s", len(df_final_for_model.index))
        p_logger.debug("[armado_df_para_clasificacion] Finaliza")

        # 4 --  Archivo listo para bajar los datos de presion por evento
        return df_final_for_model

    except OSError as e:
        p_logger.error("Se produjo un error(%s): %s", e.errno, e.strerror)
        p_logger.error(traceback.format_exc())
        return None

    except Exception as e:
        p_logger.error("Se produjo un error: %s", e)
        p_logger.error(traceback.format_exc())
        return None
