"""ejecutar_proceso.py - punto de entrada del endpoint "submit":
    - Importación de librerías
    - Inicializacion de variables de configuracion
    - Inicialización del logger
    - Cambio de status a PROCESANDO
    - Obtención de parámetros de entrada enviados por consola
    - Llamado al proceso principal
"""
import logging as log
import os
import sys
import traceback
from typing import Dict

currentdir = os.path.dirname(os.path.realpath(__file__))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir)

import data.data_blob_storage as dbs
import data.data_process as dp
from ds import main
from functions import functions_blob_storage as f_blob
from functions import functions_logger as f_log
from functions import functions_utils as f_util
from functions.functions_logger import MailInfo

CTE_STATUS_PROCESANDO = "PROCESANDO"
CTE_STATUS_STANDBY = "STANDBY"

# Lectura de parámetros enviados por consola
if len(sys.argv) > 1:
    AMBIENTE = sys.argv[1]
else:
    AMBIENTE = "DEV"

cfgs: Dict[str, str] = {}


def inicializar() -> None:
    """Acá colocamos todos los seteos iniciales de configuración"""
    # Inicialización del logger
    logger_name = "ejecucion_test"
    # logger_path_cfgs = "./src/config/config_api_logger.yml"
    logger_path_cfgs = "../config/config_api_logger.yml"
    f_log.crear_logger(logger_name=logger_name, config_file=logger_path_cfgs)

    # blob_path_cfgs = "./src/config/config_archivos_blob.yml"
    blob_path_cfgs = "../config/config_archivos_blob.yml"

    # Inicialización de variables de configuración
    cfgs["logger_name"] = logger_name  # nombre del logger
    cfgs["path_cfg_loggers"] = logger_path_cfgs  # config logger
    cfgs["conf_arc_blob"] = blob_path_cfgs  # config path files
    # cfgs["conf_api"] = "./src/config/config_api.yml"
    cfgs["conf_api"] = "../config/config_api.yml"
    cfgs["ambiente"] = AMBIENTE

    # Asignación de la variable de configuración en todos los modulos usados
    dbs.cfgs = cfgs
    f_util.cfgs = cfgs
    f_blob.cfgs = cfgs
    dp.cfgs = cfgs
    main.cfgs = cfgs


def predict(test: bool = False):
    """
    Función que realiza el proceso de predicción.
    """

    inicializar()

    logger = log.getLogger(cfgs["logger_name"])
    logger.info("[predict] Inicia")

    # config_strg = f_util.leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])
    config_api = f_util.leer_configuracion(cfgs["conf_api"], cfgs["ambiente"])

    try:
        # Cambio de status de la API a PROCESANDO. El cliente monitorea este estado
        # para saber si la API sigue procesando
        f_util.change_fflag_status(CTE_STATUS_PROCESANDO)

        # Copia de datos desde el Blob Storage a la carpetas local
        dbs.download_data_from_blob_storage()

        if test:
            base = "TEST_BASE_CHILD-CHILD.csv"
            sensores = "Sensores.csv"
            eventos = "TEST_EVENTOS.csv"
            presiones = "TEST_PRESIONES.csv"
            eventos_presiones = "TEST_EVENTOS_PRESIONES.csv"
            clasificacion = "TEST_CLASIFICACION.csv"
            resultados = "TEST_RESULTADOS_COE_CHILD-CHILD.csv"
        else:
            base = "BASE_CHILD-CHILD.csv"
            sensores = "Sensores.csv"
            eventos = "EVENTOS.csv"
            presiones = "PRESIONES.csv"
            eventos_presiones = "EVENTOS_PRESIONES.csv"
            clasificacion = "CLASIFICACION.csv"
            resultados = "RESULTADOS_COE_CHILD-CHILD.csv"

        etl_result = main.elt_data(
            base=base,
            sensores=sensores,
            eventos=eventos,
            presiones=presiones,
            eventos_presiones=eventos_presiones,
            clasificacion=clasificacion,
        )
        if etl_result != "Sin datos":
            main.predict(
                eventos=eventos_presiones,
                clasificacion=clasificacion,
                resultados=resultados,
            )

    except Exception:  # pylint: disable=broad-except
        msg = f"Se produjo un error ejecutando el proceso. Error: {traceback.format_exc()}"
        logger.error(msg)
        msg = "Se produjo un error ejecutando el proceso. Revise el archivo del log."
        mail_dest = config_api["mail_dest"]
        subject = "Error ChildChild_API"
        param_post_url = config_api["param_post_url"]
        mailinfo = MailInfo(
            msg=msg,
            to=mail_dest,
            subject=subject,
            body=msg,
            p_cfg_param_post_url=param_post_url,
        )
        f_log.logger_and_mail(logger, "error", mailinfo)

    # Copia de datos desde la carpeta local al Blob Storage
    dbs.upload_data_to_blob_storage(eliminar=False)

    # Cambio de status de la API a STANDBY. El cliente monitorea este estado
    # para saber si la API terminó el proceso
    f_util.change_fflag_status(CTE_STATUS_STANDBY)

    logger.info("[predict] Finaliza")
    dbs.upload_log_to_blob_storage()


if __name__ == "__main__":
    predict()
