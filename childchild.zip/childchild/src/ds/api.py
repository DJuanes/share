"""Entrypoint del proyecto"""
import json
import os
import subprocess
import time
import traceback
import uuid

from flask import Flask, request

PROYECTO = "ChildChild"
FLAG_FILE = f"""/{PROYECTO}/fflag.txt"""
PID_FILE = f"""/{PROYECTO}/pidfile.txt"""

PCOMANDO = "python3"
SCRIPTPYTHON = f"""/{PROYECTO}/src/ds/__init__.py"""

CUR_DIR = os.getcwd()
LOG_DIR = os.path.join(CUR_DIR, "logs")
os.makedirs(LOG_DIR, exist_ok=True)

API = Flask(__name__)


@API.route("/")
def init():
    """endpoint (/) - Descripción de la api
    Retorno :
    - JSON con la descripción
    """
    return json.dumps(
        f"""API de control de {PROYECTO}: Para ejecutarla usar endpoint /submit, , \
        para verificar status usar /check"""
    )


@API.route("/submit")
def submit():
    """endpoint (/submit) - Ejecución del proceso que ejecuta el modelo.
    Chequea que no haya otro proceso en ejecución. En ese caso, inicia la ejecución.
    Retorna "OK" como status si no hay errores en el submit.
    Parámetros:
    - ambiente: DEV, TEST o PRD (para que el Blob Storage apunte al ambiente correspondiente)
    - fecha_ejecucion: Opcional - se utiliza para asegurar que los datos de entrada
    son capturados desde el mismo momento para todos los pozos.
    Retorno :
    - JSON con el estado del submit y el timestamp
    """
    ambiente = request.args.get("ambiente")
    if ambiente == "":
        ambiente = "DEV"  # default

    print("API Ambiente: ", ambiente)
    # seteo la variable de ambiente para que la usen los procesos posteriores
    os.environ["AMBIENTE"] = ambiente

    out = ""
    hora = ""
    status = ""

    try:
        with open(FLAG_FILE, "r", encoding="utf-8") as fflag:
            status = fflag.read()
            hora = time.ctime(os.path.getmtime(FLAG_FILE))
            if status == "PROCESANDO":
                out = f"""API de {PROYECTO} ya se estaba ejecutando. \
                    Consultar status utilizando /check"""

    except OSError as e:
        out = "Error. No se pudo hacer submit()"
        print(f"""Error : {traceback.format_exc()}""")
        print(f"OS error({e.errno}): {e.strerror}")
        out = traceback.format_exc()

    # si out está vacío: no hubo errores y la API no se estaba ejecutando, continuo con el submit
    if out == "":
        id_log = uuid.uuid4()

        open(os.path.join(LOG_DIR, f"{id_log}.log"), "w", encoding="utf-8")
        print("Ejecutar: ", PCOMANDO, " ", SCRIPTPYTHON)

        pid = subprocess.Popen(
            [PCOMANDO, SCRIPTPYTHON], cwd=f"""/{PROYECTO}/src/ds"""
        ).pid
        print("PID: ", pid)

        with open(PID_FILE, "w", encoding="utf-8") as fpid:
            fpid.write(str(pid))
        out = "OK"
        # tomo el horario de modificación del archivo pid_file (horario en que se disparó la API)
        hora = time.ctime(os.path.getmtime(PID_FILE))

    return json.dumps({"status": "".join(out), "hora": "".join(hora)})


# @API.route("/regenerate_eventos_procesados")
# def regenerate_eventos_procesados():
#    """
#    Volver a generar la lista de eventos procesados
#    """
#
#    with subprocess.Popen(
#        [PCOMANDO, REGENERATE], cwd=f"""/{PROYECTO}/src/ds"""
#    ).pid as pid:
#        print("PID: ", pid)
#
#    with open(PID_FILE, "w", encoding="utf-8") as fpid:
#        fpid.write(str(pid))


@API.route("/check")
def check():
    """endpoint (/check) - Chequeo del status de la API
    Devuelve el status que esta guardado en el archivo flag_file
    Retorno :
    - JSON con el estado de la API y el timestamp
    """
    out = "Ha ocurrido un error en el check()"
    hora = ""
    try:
        with open(FLAG_FILE, "r", encoding="utf-8") as fflag:
            out = fflag.read()
            hora = time.ctime(os.path.getmtime(FLAG_FILE))

    except OSError as e:
        contents = f"No se pudo abrir el archivo. OS error({e.errno}): {e.strerror}"
        return json.dumps(
            {"logger": "".join(contents), "error": "".join(traceback.format_exc())}
        )

    return json.dumps({"status": "".join(out), "hora": "".join(hora)})


@API.route("/kill")
def kill():
    """endpoint (/check) - Detiene el proceso que se está ejecutando y
    escribe el status de la api en flag_file en "STANDBY"
    Retorno :
    - JSON con el estado de la API y el timestamp
    """
    out = ""
    hora = time.ctime(os.path.getmtime(FLAG_FILE))
    try:
        with open(PID_FILE, "r", encoding="utf-8") as fpid:
            pid = fpid.read()
        os.kill(int(pid), 9)
        out = "KILLED"

        with open(FLAG_FILE, "w", encoding="utf-8") as fflag:
            fflag.write("STANDBY")

    except OSError as e:
        out = f"No se pudo hacer el kill: {str(pid)}. OS error({e.errno}): {e.strerror}"

    return json.dumps({"status": "".join(out), "hora": "".join(hora)})


@API.route("/getlogger")
def getlogger():
    """endpoint (/getlogger) - Permite ver el logueo que se está generando
    Retorno :
    - JSON con el contenido del log
    """
    file_path = f"""/{PROYECTO}/src/logs/root_logger.log"""
    try:
        with open(file_path, encoding="utf-8") as f:
            contents = f.read()
            print(contents)
            return json.dumps({"logger": "".join(contents)})

    except OSError as e:
        contents = f"No se pudo abrir el archivo. OS error({e.errno}): {e.strerror}"
        return json.dumps(
            {"logger": "".join(contents), "error": "".join(traceback.format_exc())}
        )


if __name__ == "__main__":
    API.run(debug=True, host="0.0.0.0", port=443)
