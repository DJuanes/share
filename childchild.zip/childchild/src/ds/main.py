"""Funciones principales"""
from typing import Dict

import pandas as pd

import data.data_process as dp
import ds.predict as pred
from functions import functions_utils as f_utils

cfgs: Dict[str, str] = {}


def elt_data(
    base: str = "TEST_BASE_CHILD-CHILD.csv",
    sensores: str = "Sensores.csv",
    eventos: str = "TEST_EVENTOS.csv",
    presiones: str = "TEST_PRESIONES.csv",
    eventos_presiones: str = "TEST_EVENTOS_PRESIONES.csv",
    clasificacion: str = "TEST_CLASIFICACION.csv",
) -> str:
    """
    Pre-procesamiento de los datos

    Args:
        base (str, optional): nombre de la base origen de child-child.
                              Defaults to "TEST_BASE_CHILD-CHILD.csv".
        sensores (str, optional): nombre de la base de sensores.
                                  Defaults to "Sensores.csv".
        eventos (str, optional): nombre de la base de eventos.
                                 Se genera a partir de la base de sensores y la base child-child.
                                 Defaults to "TEST_EVENTOS.csv".
        presiones (str, optional): nombre de la base de presiones.
                                   Defaults to "TEST_PRESIONES.csv".
        eventos_presiones (str, optional): nombre de la base de eventos con presiones.
                                           Defaults to "TEST_EVENTOS_PRESIONES.csv".
        clasificacion (str, optional): nombre de la base de clasificación.
                                       Esta es la base input del modelo.
                                       Defaults to "TEST_CLASIFICACION.csv".
    """

    f_utils.cfgs = cfgs
    config_strg = f_utils.leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])
    base_fp = config_strg["path_folder_data"] + config_strg["path_input"] + base
    sensores_fp = config_strg["path_folder_data"] + config_strg["path_input"] + sensores
    eventos_fp = config_strg["path_folder_data"] + config_strg["path_input"] + eventos
    eventos_procesados = "EVENTOS_PROCESADOS.csv"
    eventos_procesados_fp = (
        config_strg["path_folder_data"]
        + config_strg["path_output"]
        + eventos_procesados
    )
    presiones_fp = (
        config_strg["path_folder_data"] + config_strg["path_input"] + presiones
    )
    eventos_presiones_fp = (
        config_strg["path_folder_data"] + config_strg["path_input"] + eventos_presiones
    )
    clasificacion_fp = (
        config_strg["path_folder_data"] + config_strg["path_input"] + clasificacion
    )

    # armado_df_para_bajada_presiones
    input_schema = {
        "column_hijo": "HIJO",
        "column_tag_hijo": "TAG_P",
        "column_hermano": "HERMANO",
        "column_rig": "RIG",
        "column_inicio_frac": "INICIO_FRAC",
        "column_fin_frac": "FIN_FRAC",
        "column_inicio_bu": "INICIO_BU",
        "column_inicio_fo": "INICIO_FO",
        "column_evento_id": "ID_EVENTO",
        "column_etapa": "ETAPA",
    }
    fecha_minima = "2018-01-01 00:00:00"

    column_evento_id = input_schema.get("column_evento_id", "ID_EVENTO")
    eventos_procesados_list = dp.get_eventos_procesados(
        eventos_procesados_fp=eventos_procesados_fp, column_evento_id=column_evento_id
    )

    df_eventos = dp.armado_df_para_bajada_presiones(
        childchild_fp=base_fp,
        sensores_fp=sensores_fp,
        eventos_fp=eventos_fp,
        eventos_procesados=eventos_procesados_list,
        fecha_minima=fecha_minima,
        data_struct=input_schema,
    )
    df_eventos.to_csv(eventos_fp, index=False)

    if len(df_eventos.index) == 0:
        return "Sin datos"

    # bajada_presiones
    input_schema = {
        "column_evento_id": "ID_EVENTO",
        "column_inicio": "inicioBajadaDatos",
        "column_fin": "finBajadaDatos",
        "column_tag_hermano": "TAG_HERMANO",
    }

    df_presiones = dp.bajada_presiones(
        eventos_fp=eventos_fp,
        eventos_procesados=eventos_procesados_list,
        data_struct=input_schema,
    )
    df_presiones.to_csv(presiones_fp, index=False)

    # armado_df_para_clasificacion
    input_schema = {
        "column_id_evento": "ID_EVENTO",
        "column_index": "index",
        "column_inicio_frac": "INICIO_FRAC",
        "column_fin_frac": "FIN_FRAC",
        "column_inicio_bu": "INICIO_BU",
        "column_inicio_fo": "INICIO_FO",
        "column_evento": "evento",
        "column_tipo_evento": "tipoEvento",
        "column_name_evento": "Interferido",
        "column_hijo": "HIJO",
        "column_tag_hijo": "TAG_P",
        "column_hermano": "HERMANO",
        "column_time": "Timestamp",
        "column_presion": "Valor",
    }
    numero_datos = 35
    porcentaje_filtrado = 65
    time_limit = 30

    df_clasificacion = dp.armado_df_para_clasificacion(
        eventos_fp=eventos_fp,
        presiones_fp=presiones_fp,
        eventos_presiones_fp=eventos_presiones_fp,
        time_limit=time_limit,
        porcentaje_filtrado=porcentaje_filtrado,
        numero_datos=numero_datos,
        data_struct=input_schema,
    )
    if df_clasificacion is None:
        return "Sin datos"
    df_clasificacion.to_csv(clasificacion_fp, index=False)

    eventos_procesados_list = (
        eventos_procesados_list + df_eventos[column_evento_id].tolist()
    )
    dp.set_eventos_procesados(
        eventos=eventos_procesados_list,
        eventos_procesados_fp=eventos_procesados_fp,
        column_evento_id=column_evento_id,
    )

    return "elt_data finalizó correctamente"


def predict(
    model_fp: str = "../../models/modelo_muliclass_eventos_xgboost.joblib",
    eventos: str = "TEST_EVENTOS_PRESIONES.csv",
    clasificacion: str = "TEST_CLASIFICACION.csv",
    resultados: str = "TEST_RESULTADOS_COE_CHILD-CHILD.csv",
):
    """
    Realiza la clasificación (interferido, no interferido, etc.) para cada evento.
    También calcula los puntos caracteristicos.

    Args:
        model_fp (str, optional): file path a la ubicación del modelo.
        Defaults to "./models/modelo_muliclass_eventos_xgboost.joblib".
        eventos (str, optional): nombre de la base de eventos con sus presiones.
        Defaults to "TEST_EVENTOS_PRESIONES.csv".
        clasificacion (str, optional): nombre de la base de clasificación.
        Esta es la base input del modelo. Defaults to "TEST_CLASIFICACION.csv".
        resultados (str, optional): nombre del archivo final.
        Defaults to "TEST_RESULTADOS_COE_CHILD-CHILD.csv".
    """

    f_utils.cfgs = cfgs
    pred.cfgs = cfgs
    config_strg = f_utils.leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])
    eventos_fp = config_strg["path_folder_data"] + config_strg["path_input"] + eventos
    clasificacion_fp = (
        config_strg["path_folder_data"] + config_strg["path_input"] + clasificacion
    )
    resultado_fp = (
        config_strg["path_folder_data"] + config_strg["path_output"] + resultados
    )

    input_schema = {
        "column_id_evento": "ID_EVENTO",
        "column_index": "index",
        "column_inicio_frac": "INICIO_FRAC",
        "column_fin_frac": "FIN_FRAC",
        "column_inicio_bu": "INICIO_BU",
        "column_inicio_fo": "INICIO_FO",
        "column_evento": "evento",
        "column_tipo_evento": "tipoEvento",
        "column_name_evento": "Interferido",
        "column_hijo": "HIJO",
        "column_tag_hijo": "TAG_P",
        "column_hermano": "HERMANO",
        "column_time": "Timestamp",
        "column_presion": "Valor",
    }

    df_resultado_original = pd.read_csv(resultado_fp)
    df_resultado = pred.predict(
        model_fp=model_fp,
        eventos_fp=eventos_fp,
        clasificacion_fp=clasificacion_fp,
        data_struct=input_schema,
    )
    df_resultado_full = pd.concat([df_resultado_original, df_resultado])
    df_resultado_full.to_csv(resultado_fp, index=False)


def regenerate_eventos_procesados(
    column_evento_id: str = "ID_EVENTO",
    resultados: str = "TEST_RESULTADOS_COE_CHILD-CHILD.csv",
):
    """
    Genera el archivo de eventos procesados.

    Args:
        column_evento_id (str, optional): nombre de la columna que identifica el registro.
        Defaults to "ID_EVENTO".
        resultados (str, optional): nombre del archivo final.
        Defaults to "TEST_RESULTADOS_COE_CHILD-CHILD.csv".
    """
    f_utils.cfgs = cfgs
    config_strg = f_utils.leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])

    eventos_procesados = "EVENTOS_PROCESADOS.csv"
    eventos_procesados_fp = (
        config_strg["path_folder_data"]
        + config_strg["path_output"]
        + eventos_procesados
    )
    resultado_fp = (
        config_strg["path_folder_data"] + config_strg["path_output"] + resultados
    )

    dp.generate_eventos_procesados(
        resultado_fp=resultado_fp,
        eventos_procesados_fp=eventos_procesados_fp,
        column_evento_id=column_evento_id,
    )
