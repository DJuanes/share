"""Llamada al modelo de predicción"""
import logging as log
from typing import Dict

import pandas as pd
from joblib import load

import functions.function_for_childchild as f_child

cfgs: Dict[str, str] = {}


def predict(
    model_fp: str,
    eventos_fp: str,
    clasificacion_fp: str,
    **data_struct,
) -> pd.DataFrame:
    """
    Realiza la clasificación (interferido, no interferido, etc.) para cada evento.
    También calcula los puntos caracteristicos.

    Args:
        model_fp (str): file path a la ubicación del modelo.
        eventos_fp (str): file path de la base de eventos.
        clasificacion_fp (str): file path de la base input del modelo.

    Returns:
        pd.DataFrame: dataframe con los eventos clasificados
    """
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.info("Carga modelo desde %s", model_fp)

    # Levantamos el df y el modelo
    # Ya tenemos listo el df, aplicamos el modelo de clasificacion
    modelo = load(model_fp)
    p_logger.info("Modelo: %s, %s", model_fp, type(modelo))
    p_logger.info("Ejecutando predicción...")

    # Estructura del dataframe, con valores default
    column_id_evento = data_struct.get("column_id_evento", "ID_EVENTO")
    column_evento = data_struct.get("column_evento", "evento")
    column_tipo_evento = data_struct.get("column_tipo_evento", "tipoEvento")
    column_name_evento = data_struct.get("column_name_evento", "Interferido")
    column_time = data_struct.get("column_time", "Timestamp")
    column_inicio_frac = data_struct.get("column_inicio_frac", "INICIO_FRAC")

    df_eventos = pd.read_csv(eventos_fp)
    df_clasificacion = pd.read_csv(clasificacion_fp)

    df_final_for_model_predictions = f_child.apply_model(
        df_clasificacion,
        modelo,
        column_evento,
        column_tipo_evento,
    )

    list_for_features = df_final_for_model_predictions.columns[0:35].tolist() + [
        column_id_evento
    ]

    df_final_for_model_predictions_ptos_criticos = (
        f_child.calculate_critial_point_event_interf(
            df_final_for_model_predictions,
            df_eventos,
            column_id_evento,
            column_evento,
            column_name_evento,
            list_for_features,
        )
    )

    time_fo_cal = "timeFO_cal"
    time_pmax = "timePmax_cal"
    time_bu_cal = "timeBU_cal"
    name_fo_10min = "FO_cal+10min"
    pmax_cal = "Pmax_cal"
    bu_cal = "BU_cal"
    fo_cal = "FO_cal"
    amplitud_bu = "AMPLITUD_BU"
    amplitud_fo = "AMPLITUD_FO"
    intensidad_bu = "iBU"
    intensidad_fo = "iFO"

    df_final_for_model_predictions_final = f_child.calculate_p_fo_10min(
        df_final_for_model_predictions_ptos_criticos,
        df_eventos,
        column_name_evento,
        column_id_evento,
        column_time,
        time_fo_cal,
        name_fo_10min,
    )

    # Calculamos las amplitide e intensidades de BU y FO
    f_child.calculo_amplitudes(
        df_final_for_model_predictions_final,
        pmax_cal,
        bu_cal,
        amplitud_bu,
        column_name_evento,
    )

    # calculo intensidadBU----
    f_child.calculo_intensidades(
        df_final_for_model_predictions_final,
        time_pmax,
        time_bu_cal,
        amplitud_bu,
        intensidad_bu,
        column_name_evento,
    )

    # calculo amplituFO----
    f_child.calculo_amplitudes(
        df_final_for_model_predictions_final,
        fo_cal,
        name_fo_10min,
        amplitud_fo,
        column_name_evento,
    )

    # calculo intensidadFO----
    df_final_for_model_predictions_final_2 = f_child.calculo_intensidades(
        df_final_for_model_predictions_final,
        time_fo_cal,
        time_presion_final=None,
        name_colum_amplitud=amplitud_fo,
        name_new_column=intensidad_fo,
        evento=column_name_evento,
    )

    new_column_delay = "Time_delay[m]"

    # usamos como inicio de BU el valor calculado por el modelo == "timeBUcal"
    df_final_for_model_predictions_final_2 = f_child.calculate_t_delay(
        df_eventos,
        df_final_for_model_predictions_final_2,
        column_id_evento,
        column_evento,
        column_inicio_frac,
        time_bu_cal,
        new_column_delay,
    )

    # Generacion de df final que alimenta la APP----
    list_features = [
        column_id_evento,
        column_tipo_evento,
        amplitud_bu,
        amplitud_fo,
        intensidad_bu,
        intensidad_fo,
        time_bu_cal,
        time_pmax,
        time_fo_cal,
        new_column_delay,
    ]

    df_for_model_with_pred = f_child.generate_df_for_app(
        df_eventos.drop_duplicates(subset=[column_id_evento]),
        df_final_for_model_predictions_final_2,
        list_features,
    )

    p_logger.info("FINALIZA proceso predicción...")

    return df_for_model_with_pred
