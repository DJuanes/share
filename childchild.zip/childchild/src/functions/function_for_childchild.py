"""Módulo para las funciones DS especificas del proyecto"""
import traceback
import typing as tp

import numpy as np
import pandas as pd
from scipy.signal import argrelextrema
from xgboost.sklearn import XGBClassifier


def calculate_ptos_criticos_locales(
    df: pd.DataFrame, criterio: tp.Callable, cantidad_vecinos: int
) -> pd.DataFrame:
    """
    Calcular los puntos criticos locales

    Args:
        df (pd.DataFrame): dataframe que contiene las presiones
        criterio (callable): función a utilizar para comparar dos puntos de datos
        cantidadVecinos (int): cantidad puntos de cada lado para usar para la comparación

    Returns:
        pd.DataFrame: dataframe con los puntos criticos locales
    """
    valor_local = pd.DataFrame()
    while (valor_local.empty) & (cantidad_vecinos >= 1):
        valor_local = df.iloc[
            argrelextrema(df.values, criterio, order=cantidad_vecinos)[0]
        ]
        cantidad_vecinos = cantidad_vecinos - 1

    return valor_local


def find_closest(arr, val):
    """
    Busca el valor mínimo dentro de un array

    Args:
        arr (_type_): array de valores a buscar
        val (_type_): valor a excluir

    Returns:
        _type_: valor mínimo de un array
    """
    idx = np.abs(arr - val).argmin()

    return arr[idx]


def get_time_of_ptos(
    df_only_points: pd.DataFrame,
    df_original: pd.DataFrame,
    column_id_evento: str,
    column_presiones: str,
    column_timestamp: str,
    semi_window: int,
) -> pd.DataFrame:
    """
    Agrega el tiempo asociado a los puntos criticos

    Args:
        df_only_points (pd.DataFrame): dataframe con los puntos calculados
        df_original (pd.DataFrame): dataframe que contiene los eventos
        column_id_evento (str): nombre de la columna que identifica el registro
        column_presiones (str): nombre de la columna que contiene las presiones
        column_timestamp (str): nombre de la columna que contiene el timestamp de las presiones
        semi_window (int): tamaño de ventana

    Returns:
        pd.DataFrame: dataframe con los puntos calculados y sus tiempos asociados
    """
    for num in df_only_points[column_id_evento].unique():
        # lista de presiones por evento
        if not df_only_points[(df_only_points[column_id_evento] == num)][
            df_only_points.columns[1:7]
        ].empty:
            lista_ptoscaracteriticos_calculados = df_only_points[
                (df_only_points[column_id_evento] == num)
            ][df_only_points.columns[1:4]].values[0]
            # lista de puntos de presiones calculadas. Son tres puntos:
            #      1- Presion inicio BU
            #      2- Presion máxima
            #      3- Presion inicio FO
            lista_index_ptoscaracteriticos_calculados = df_only_points[
                (df_only_points[column_id_evento] == num)
            ][df_only_points.columns[4:7]].values[0]
            # lista de indices de los puntos de presiones calculads. Son tres puntos:
            #      4- Presion inicio BU --index
            #      5- Presion máxima--index
            #      6- Presion inicio FO--index

            listapresiones = df_original[(df_original[column_id_evento] == num)][
                column_presiones
            ].dropna()
            # Este loop recorre los tres puntos de presion calculados
            # y busca los valores de presion. Compara con la lista de presiones.
            # Esta función identifica el punto del listado de presiones mas cercano
            # a los puntos criticos. De acuqi sacamos los puntos criticos del listado original
            lista_name_times = ["timeBU_cal", "timePmax_cal", "timeFO_cal"]

            for pres, presindex, time_name in zip(
                lista_ptoscaracteriticos_calculados,
                lista_index_ptoscaracteriticos_calculados,
                lista_name_times,
            ):

                if (presindex - semi_window) >= 0:
                    index_minimo = presindex - semi_window
                else:
                    index_minimo = 0
                if (presindex + semi_window) < len(listapresiones) - 1:
                    index_maximo = presindex + semi_window
                else:
                    index_maximo = len(listapresiones) - 1

                if not listapresiones.iloc[int(index_minimo) : int(index_maximo)].empty:
                    presion_correcta = find_closest(
                        listapresiones.iloc[
                            int(index_minimo) : int(index_maximo)
                        ].values,
                        pres,
                    )

                    # Con este valor de presión, identificamos su tiempo asociado
                    time = df_original[
                        (df_original[column_id_evento] == num)
                        & (df_original[column_presiones] == presion_correcta)
                    ][column_timestamp].values[0]
                    df_only_points.loc[
                        df_only_points[column_id_evento] == num, time_name
                    ] = time

    return df_only_points


def calculate_ptos_interferencias(
    df: pd.DataFrame,
    df_original: pd.DataFrame,
    column_id_evento: str,
    evento: str,
    tipo_evento: str,
    list_features: list,
) -> pd.DataFrame:
    """
    Calular los maximos y moinimos locales de un set de datos.
    Para los fines de los eventos "interferidos", esots puntos deberia ser
    los ptos "inicio_BU" y "presion maxima".
    La lista "list_features" contiene la 35 columnas correspondientes a los puntos de presion,
    más el ID.

    Args:
        df (pd.DataFrame): dataframe que contiene las predicciones
        df_original (pd.DataFrame): dataframe que contiene los eventos
        column_id_evento (str): nombre de la columna que identifica el registro
        evento (str): nombre de la columna que contiene el evento
        tipo_evento (str): nombre de la columna que contiene el tipo del evento
        list_features (list): lista de features

    Returns:
        pd.DataFrame: dataframe con las predicciones + puntos criticos
    """

    df_inicio_bu_calc_index = pd.DataFrame(
        columns=[
            "ID_EVENTO",
            "BU_cal",
            "Pmax_cal",
            "FO_cal",
            "BU_cal_index",
            "Pmax_cal_index",
            "FO_cal_index",
        ]
    )

    df_presion = df[df[evento] == tipo_evento][list_features].transpose()
    df2 = df_presion.drop(df_presion.tail(1).index)
    vecinos_bu = 2
    vecinos_fo = 2

    for num, ids in zip(df2.columns, df_presion.loc[column_id_evento].values):
        # Minimos locales
        minim = calculate_ptos_criticos_locales(df2[num], np.less_equal, vecinos_bu)

        # Maximos locales y absoluto
        final_maxim = calculate_ptos_criticos_locales(
            df2[num].iloc[5:], np.greater_equal, vecinos_fo
        )
        final_maxim = pd.to_numeric(final_maxim)
        if (len(minim) > 0) & (len(final_maxim) > 0):
            df_inicio_bu_calc_index = df_inicio_bu_calc_index.append(
                {
                    "ID_EVENTO": ids,
                    "BU_cal": minim.values[0],
                    "Pmax_cal": final_maxim.max(),
                    "FO_cal": final_maxim.values[-1],
                    "BU_cal_index": float(minim.index[0]),
                    "Pmax_cal_index": float(final_maxim.idxmax()),
                    "FO_cal_index": float(final_maxim.index[-1]),
                },
                ignore_index=True,
                sort=False,
            )

    semi_window = 5

    dfprueba = get_time_of_ptos(
        df_inicio_bu_calc_index,
        df_original,
        "ID_EVENTO",
        "Valor",
        "Timestamp",
        semi_window,
    )

    print(
        "Luego del calculo de los tiempos de los puntos criticos = "
        + str(dfprueba.shape)
    )

    return dfprueba


def calculate_critial_point_event_interf(
    df_derivadas: pd.DataFrame,
    df_original: pd.DataFrame,
    column_id_evento: str,
    column_evento: str,
    name_evento: str,
    list_for_features: list,
) -> pd.DataFrame:
    """
    Calcular puntos criticos con los eventos interferidos

    Args:
        df_derivadas (pd.DataFrame): dataframe que contiene las predicciones
        df_original (pd.DataFrame): dataframe que contiene los eventos
        column_id_evento (str): nombre de la columna que identifica el registro
        column_evento (str): nombre de la columna que contiene el evento
        name_evento (str): nombre de la columna que contiene el tipo del evento
        list_for_features (list): lista de features

    Returns:
        pd.DataFrame: dataframe con las predicciones + puntos criticos
    """
    try:
        df = df_derivadas.copy()
        df_ptos_criticos = calculate_ptos_interferencias(
            df,
            df_original,
            column_id_evento,
            column_evento,
            name_evento,
            list_for_features,
        )

        for ids in df_ptos_criticos[column_id_evento].unique():
            for feature in df_ptos_criticos[
                (df_ptos_criticos[column_id_evento] == ids)
            ].columns[1:]:

                df.loc[
                    (df[column_id_evento] == ids) & (df[column_evento] == name_evento),
                    feature,
                ] = df_ptos_criticos[df_ptos_criticos[column_id_evento] == ids][
                    feature
                ].values[
                    0
                ]

    except Exception:  # pylint: disable=broad-except
        msg = f"Se produjo un error ejecutando el proceso. Error: {traceback.format_exc()}"
        print(msg)

    return df


def calculate_p_fo_10min(
    df: pd.DataFrame,
    df_original: pd.DataFrame,
    evento: str,
    column_id_evento: str,
    column_time: str,
    time_fo_cal: str,
    name_fo_10min: str,
) -> pd.DataFrame:
    """
    Calcula el FO + 10 min

    Args:
        df (pd.DataFrame): dataframe que contiene las predicciones
        df_original (pd.DataFrame): dataframe que contiene los eventos
        evento (str): nombre de la columna que contiene el evento.
        column_id_evento (str): nombre de la columna que identifica el registro
        column_time (str): nombre de la columna que contiene el timestamp de la presión
        time_fo_cal (str): nombre de la columna con el tiempo de fo
        name_fo_10min (str): nombre de la columna para fo + 10 min

    Returns:
        pd.DataFrame: dataframe con las predicciones + nueva columna calculada (name_fo_10min)
    """
    for index, row in df[df.evento == evento].iterrows():
        time_10min = find_closest(
            pd.to_datetime(
                df_original[(df_original[column_id_evento] == row[column_id_evento])][
                    column_time
                ].values
            ),
            pd.to_datetime(row[time_fo_cal]).to_numpy(),
        ) + np.timedelta64(10, "m")
        if (
            len(
                df_original[
                    (df_original[column_id_evento] == row[column_id_evento])
                    & (pd.to_datetime(df_original[column_time]) == time_10min)
                ].Valor.values
            )
            == 1
        ):
            pre = df_original[
                (df_original[column_id_evento] == row[column_id_evento])
                & (pd.to_datetime(df_original[column_time]) == time_10min)
            ].Valor.values[0]
            df.loc[df[column_id_evento] == row[column_id_evento], name_fo_10min] = pre

    return df


def calculo_amplitudes(
    df: pd.DataFrame,
    presion_inicial: str,
    presion_final: str,
    name_new_column: str,
    evento: str,
) -> pd.DataFrame:
    """
    Calculo de las amplitudes:
    # A_BU = P_max - P_BU
    # A_FO = P_FO - P_10min

    Args:
        df (pd.DataFrame): dataframe que contiene las predicciones
        presion_inicial (str): nombre de la columna que contiene la presión inicial.
        presion_final (str): nombre de la columna que contiene la presión final.
        name_new_column (str): nombre para la nueva columna calculada representando la amplitud.
        evento (str): nombre de la columna que contiene el evento.

    Returns:
        pd.DataFrame: dataframe con las predicciones + columna calculada (amplitud)
    """
    df.loc[df.evento == evento, name_new_column] = (
        df[presion_inicial] - df[presion_final]
    )

    return df


def calculo_intensidades(
    df: pd.DataFrame,
    time_presion_inicial: str = None,
    time_presion_final: str = None,
    name_colum_amplitud: str = None,
    name_new_column: str = None,
    evento: str = None,
) -> pd.DataFrame:
    """
    Calculo de las intensidades:
    # I_BU = P_max - P_BU /dt
    # I_FO = P_FO - P_10min /dt

    Args:
        df (pd.DataFrame): dataframe que contiene las predicciones
        time_presion_inicial (str, optional): nombre de la columna que contiene la hora
            de la presión inicial. Defaults to None.
        time_presion_final (str, optional): nombre de la columna que contiene la hora
            de la presión final. Defaults to None.
        name_colum_amplitud (str, optional): nombre de la columna que contiene
            la amplitud. Defaults to None.
        name_new_column (str, optional): nombre para la nueva columna calculada
            representando la intensidad. Defaults to None.
        evento (str, optional): nombre de la columna que contiene el evento. Defaults to None.

    Returns:
        pd.DataFrame: dataframe con las predicciones + columna calculada (intensidad)
    """
    if (time_presion_inicial is not None) & (time_presion_final is not None):
        df.loc[df.evento == evento, name_new_column] = df[name_colum_amplitud] / (
            pd.to_datetime(df[time_presion_inicial])
            - pd.to_datetime(df[time_presion_final])
        ).astype("timedelta64[m]")
    else:
        df.loc[df.evento == evento, name_new_column] = df[name_colum_amplitud] / 10

    return df


def rename_columns(
    df: pd.DataFrame, list_old_names: list, list_new_names: list
) -> pd.DataFrame:
    """
    Renombra las columnas de un dataframe

    Args:
        df (pd.DataFrame): dataframe que contiene las columnas a renombrar
        list_old_names (list): nombre de columnas originales
        list_new_names (list): nombre de columnas nuevos

    Returns:
        pd.DataFrame: dataframe con las columnas renombradas
    """
    for col, new_col in zip(list_old_names, list_new_names):
        df = df.rename(columns={col: new_col})

    return df


def generate_df_for_app(
    df_original: pd.DataFrame, df_withpredictions: pd.DataFrame, list_features: list
) -> pd.DataFrame:
    """
    Genera el df final

    Args:
        df_original (pd.DataFrame): dataframe que contiene los eventos
        df_withpredictions (pd.DataFrame): dataframe que contiene las predicciones
        list_features (list): lista con las columnas a incluir en el df final

    Returns:
        pd.DataFrame: df final (eventos + predicciones)
    """
    df = df_withpredictions.merge(df_original, on="ID_EVENTO", how="inner")

    df = df[list_features]
    list_of_columns_to_change_name = [
        "tipoEvento",
        "timeBU_cal",
        "timePmax_cal",
        "timeFO_cal",
    ]
    list_of_new_names = ["MODELO_COE", "INICIO_BU", "INICIO_FO", "TIME_P_MAX"]
    df = rename_columns(df, list_of_columns_to_change_name, list_of_new_names)

    return df


def df_with_time_limit(
    df_refencia: pd.DataFrame,
    column_fin_frac: str,
    column_timestamp: str,
    column_id_evento: str,
    time_limit: int,
) -> pd.DataFrame:
    """
    Acota la lista de valores de presiones a mediciones hechas hasta un limte temporal
    fijo para todos los tipos de eventos. Este limite es ajustable (time_limit)

    Args:
        df_refencia (pd.DataFrame): dataframe original
        column_fin_frac (str): nombre de la columna que representa el fin de fractura
        column_timestamp (str): nombre de la columna que contiene el timestamp de las presiones
        column_id_evento (str): nombre de la columna que identifica el registro
        time_limit (int): valor en minutos del límite de tiempo

    Returns:
        pd.DataFrame: dataframe resultante
    """
    list_final = []
    for ids in df_refencia[column_id_evento].unique():
        time_fin_fran = df_refencia[(df_refencia[column_id_evento] == ids)][
            column_fin_frac
        ].values[0]

        list_final.append(
            df_refencia[
                (df_refencia[column_id_evento] == ids)
                & (
                    df_refencia[column_timestamp]
                    <= time_fin_fran + np.timedelta64(time_limit, "m")
                )
            ]
        )

    return pd.concat(list_final)


def clean_data(
    df_original: pd.DataFrame,
    column_id_evento: str,
    column_presiones: str,
    porcentaje_filtrado: int,
) -> pd.DataFrame:
    """
    Filtrar registros cuyos datos Nan sean mayores a porcentaje_filtrado

    Args:
        df_original (pd.DataFrame): dataframe original a limpiar
        column_id_evento (str): nombre de la columna que identifica el registro
        column_presiones (str): nombre de la columna que contiene las presiones
        porcentaje_filtrado (int): porcentaje mínimo aceptable de datos sin nan

    Returns:
        pd.DataFrame: dataframe solo con eventos que cumplen la condición
    """
    df_original_clean = pd.DataFrame()

    df_original_clean = pd.DataFrame()
    for idx, val in enumerate(df_original[column_id_evento].unique()):
        datos_nan = (
            df_original[df_original[column_id_evento] == val][column_presiones]
            .isna()
            .sum()
        )
        porc_datos_nan = 100 * (
            datos_nan
            / df_original[df_original[column_id_evento] == val][column_presiones].shape[
                0
            ]
        )
        if porc_datos_nan < porcentaje_filtrado:
            df_original_clean = df_original_clean.append(
                df_original[df_original[column_id_evento] == val]
            )

    return df_original_clean


def ajuste_number_of_data_df_for_model(
    df_original_clean: pd.DataFrame,
    column_id_evento: str,
    column_presiones: str,
    numero_datos: int,
    back: bool = True,
) -> pd.DataFrame:
    """
    A partir de las columnas que quedaron, armamos un df con columns compuestas por
        distribuciones de presiones por evento. Aca se abren dos opciones:
            1 - cuando tenemos menos de 35 datos pot evento
            2 - cuando tenemos mas de 35 datos por evento
        Esto es lo que se hace debajo
        El parametro "numeroDatos" debe ser 35,
        a menos que querramos cambiar toda la estructura del df

    Args:
        df_original_clean (pd.DataFrame): dataframe de referencia
        column_id_evento (str): nombre de la columna que identifica el registro
        column_presiones (str): nombre de la columna que contiene las presiones
        numero_datos (int): cantidad de datos por evento
        back (bool, optional): si agregar presiones originales. Defaults to True.

    Returns:
        pd.DataFrame: dataframe resultante con la cantidad de datos ajustada
    """

    df1 = pd.DataFrame()
    for index, idx in enumerate(df_original_clean[column_id_evento].unique()):
        # Eventos con < 35 datos
        # En este caso, como el df necesita una cantidad fija de 35 datos y tiene menos,
        # rellenamos los datos faltantes con el ultimo dato medido
        if (
            df_original_clean[df_original_clean[column_id_evento] == idx][
                column_presiones
            ].shape[0]
            <= numero_datos
        ):
            list_of_data = df_original_clean[
                df_original_clean[column_id_evento] == idx
            ][column_presiones].values.tolist()
            cantidad_data = df_original_clean[
                df_original_clean[column_id_evento] == idx
            ][column_presiones].shape[0]
            ultimo_dato = df_original_clean[df_original_clean[column_id_evento] == idx][
                column_presiones
            ].values[-1]
            primer_dato = df_original_clean[df_original_clean[column_id_evento] == idx][
                column_presiones
            ].values[0]
            if back is False:
                df1[index] = (
                    list_of_data
                    + np.full(numero_datos - cantidad_data, ultimo_dato).tolist()
                )
            else:
                df1[index] = (
                    np.full(numero_datos - cantidad_data, primer_dato).tolist()
                    + list_of_data
                )
        else:
            df1[index] = df_original_clean[df_original_clean[column_id_evento] == idx][
                column_presiones
            ].values[0:numero_datos]
        df1.index = df1.index.map(str)

    return df1.transpose()


def ajuste_number_of_data_df_for_model_v2(
    df_original_clean: pd.DataFrame,
    column_id_evento: str,
    column_timestamp: str,
    column_presiones: str,
    numero_datos: int,
) -> pd.DataFrame:
    """
    Interpolar eventos desde inicio de fractura hasta fin de fractura + numero_datos

    Args:
        df_original_clean (pd.DataFrame): dataframe original
        column_id_evento (str): nombre de la columna que identifica el registro
        column_timestamp (str): nombre de la columna que contiene el timestamp de las presiones
        column_presiones (str): nombre de la columna que contiene las presiones
        numero_datos (int): numero de datos a interpolar

    Returns:
        pd.DataFrame: dataframe resultante con datos interpolados
    """
    df1 = pd.DataFrame()
    for index, idx in enumerate(df_original_clean[column_id_evento].unique()):
        x = df_original_clean[df_original_clean[column_id_evento] == idx][
            column_timestamp
        ]
        y = df_original_clean[df_original_clean[column_id_evento] == idx][
            column_presiones
        ]
        new_x = pd.DatetimeIndex(
            np.linspace(
                pd.Timestamp(np.min(x)).value,
                pd.Timestamp(np.max(x)).value,
                num=numero_datos,
            )
        )
        new_y = np.interp(new_x, x, y)
        df1[index] = new_y
        df1.index = df1.index.map(str)

    return df1.transpose()


def ajuste_number_of_data_df_for_model_with_id(
    df: pd.DataFrame,
    df_with_id: pd.DataFrame,
    column_id_evento: str,
    column_evento: str = None,
    column_tipo_evento: str = None,
) -> pd.DataFrame:
    """
    Agregamos las columanas de identificación. Si el evento no es clasificado,
    solo agregamos el ID del registro. Si el evento ya fue clasificado,
    adicionalmente agragamos las columnas evento y tipo de evento

    Args:
        df (pd.DataFrame): dataframe de referencia.
        df_with_id (pd.DataFrame): dataframe con id.
        column_id_evento (str): nombre de la columna que identifica el registro.
        column_evento (str): nombre de la columna que contiene el evento. Defaults to None.
        column_tipo_evento (str): nombre de la columna que contiene
                                  el tipo del evento. Defaults to None.

    Returns:
        pd.DataFrame: dataframe con identificador y, opcionalmente,
                      columnas de evento y tipo de evento.
    """
    df_tras = df.copy()

    df_tras[column_id_evento] = df_with_id[column_id_evento].unique()
    if column_evento is not None:
        df_tras[column_evento] = df_with_id[column_evento].unique()[0]
    if column_tipo_evento is not None:
        df_tras[column_tipo_evento] = df_with_id[column_tipo_evento].unique()[0]

    return df_tras


def calculate_derivadas(df: pd.DataFrame, columns_to_include: list) -> pd.DataFrame:
    """
    Como ya vimos en el modelado exporatorio, incluimos las derivadas (diferencias),
    ya que rescatan los cambios de pendiente de los eventos.
    En el pipeline del "df_derivadas" ponemos .iloc[1:0], ya que por defecto,
    luego de calcular las diferencias entre datos contiguos,
    el primer dato lo daja Nan, asi que de esta forma no lo consideramos
    (nos vana a quedar un punto menos que los datos de presiones)

    Args:
        df (pd.DataFrame): dataframe original
        columns_to_include (list): columnas a incluir en el df resultante

    Returns:
        pd.DataFrame: dataframe con las derivadas
    """
    df_derivadas = df.transpose().diff(periods=1).iloc[1:].transpose().copy()
    for col, new_col in zip(df_derivadas.columns, columns_to_include):
        df_derivadas = df_derivadas.rename(columns={col: new_col})

    return df_derivadas


def concat_dfder_dfpres(
    df_presiones_sin_id: pd.DataFrame,
    df_presiones_con_id: pd.DataFrame,
    df_derivadas: pd.DataFrame,
    column_id_evento: str,
    column_evento: str = None,
    column_tipo_evento: str = None,
) -> pd.DataFrame:
    """
    Concatenación de los tres df finales

    Args:
        df_presiones_sin_id (pd.DataFrame): dataframe de presiones sin identificador
        df_presiones_con_id (pd.DataFrame): dataframe de presiones con identificador
        df_derivadas (pd.DataFrame): dataframe de derivadas
        column_id_evento (str): nombre de la columna que identifica el registro.
        column_evento (str): nombre de la columna que contiene el evento. Defaults to None.
        column_tipo_evento (str): nombre de la columna que contiene
                                  el tipo del evento. Defaults to None.

    Returns:
        pd.DataFrame: dataframe final para el input del modelo
    """
    if (column_evento is not None) | (column_tipo_evento is not None):
        df_final_deriv = pd.concat(
            [
                df_presiones_sin_id,
                df_derivadas,
                df_presiones_con_id[
                    [column_id_evento, column_evento, column_tipo_evento]
                ],
            ],
            axis=1,
        )
    else:
        df_final_deriv = pd.concat(
            [df_presiones_sin_id, df_derivadas, df_presiones_con_id[column_id_evento]],
            axis=1,
        )

    return df_final_deriv


def apply_model(
    df: pd.DataFrame, modelo: XGBClassifier, column_evento: str, column_tipo_evento: str
) -> pd.DataFrame:
    """Aplicar el modelo de clasificación

    Args:
        df (pd.DataFrame): dataframe para clasificacr
        modelo (object): modelo de clasificación
        column_evento (str): nombre de la columna que contiene el evento
        column_tipo_evento (str): nombre de la columna que contiene el tipo del evento

    Returns:
        pd.DataFrame: dataframe con las clasificaciones
    """
    try:
        df[column_tipo_evento] = modelo.predict(df.drop(["ID_EVENTO"], axis=1))

        df.loc[df[column_tipo_evento] == 0, column_evento] = "No_interferido"
        df.loc[df[column_tipo_evento] == 1, column_evento] = "Interferido"
        df.loc[df[column_tipo_evento] == 2, column_evento] = "Indeterminado"

    except Exception:  # pylint: disable=broad-except
        msg = f"Se produjo un error ejecutando el proceso. Error: {traceback.format_exc()}"
        print(msg)

    return df


def calculate_t_delay(
    df_original: pd.DataFrame,
    df: pd.DataFrame,
    column_id_evento: str,
    colum_event: str,
    column_inicio_frac: str,
    column_inicio_bu: str,
    new_column_delay: str,
) -> pd.DataFrame:
    """_summary_

    Args:
        df_original (pd.DataFrame): dataframe que contiene los eventos
        df (pd.DataFrame): dataframe que contiene las predicciones
        column_id_evento (str): nombre de la columna que identifica el registro
        colum_event (str): nombre de la columna que contiene el evento.
        column_inicio_frac (str): nombre de la columna de inicio de fractura
        column_inicio_bu (str): nombre de la columna de inicio de build-up
        new_column_delay (str): nombre de la columna con el delay entre inicio fractura y BU

    Returns:
        pd.DataFrame: dataframe con las predicciones + columna delay
    """
    for ids in df[column_id_evento].unique():
        inicio_frac = pd.to_datetime(
            df_original[df_original[column_id_evento] == ids][
                column_inicio_frac
            ].values[0]
        ).to_numpy()
        inicio_bu = pd.to_datetime(
            df[df[column_id_evento] == ids][column_inicio_bu].values[0]
        ).to_numpy()

        df.loc[
            (df[column_id_evento] == ids) & (df[colum_event] == "Interferido"),
            new_column_delay,
        ] = np.abs((inicio_frac - inicio_bu).astype("timedelta64[m]").astype(float))
        df.loc[
            (df[column_id_evento] == ids) & (df[colum_event] != "Interferido"),
            new_column_delay,
        ] = np.nan

    return df
