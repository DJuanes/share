"""Módulo de funciones para interactuar con Azure Blob Storage"""
import logging as log
import traceback
from io import StringIO
from typing import Dict

import pandas
from azure.storage.blob import BlobServiceClient
from azure.storage.blob._shared.policies import AzureError

BLOBSERVICECLIENT = ""
CONTAINERCLIENT = ""
BLOBCLIENT = ""
cfgs: Dict[str, str] = {}


def instanciar_cliente_blobservice(connection_string):
    """instanciar_cliente_blobService - se instancia el cliente del servicio blob storage
    Parámetros :
    - connection_string: URI del storage account
    Retorno :
    - Instancia cliente del servicio blob storage
    """
    global BLOBSERVICECLIENT
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[instanciar_cliente_blobService] Inicia")

    try:
        # Instancia un BlobServiceClient usando un connection string
        BLOBSERVICECLIENT = BlobServiceClient.from_connection_string(connection_string)

        p_logger.debug("[instanciar_cliente_blobService] Finaliza")
        return BLOBSERVICECLIENT

    except AzureError as e:
        p_logger.error(
            "Hubo un error al tratar de instanciar "
            "el cliente del servicio Blob Storage: %s.",
            str(e),
        )
        p_logger.error("Error: %s", traceback.format_exc())
        return None


def instanciar_cliente_container(container_name):
    """instanciar_cliente_container - se instancia el cliente del container
    Parámetros :
    - container_name: nombre del container
    Retorno :
    - Instancia cliente del container
    """
    global CONTAINERCLIENT
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[instanciar_cliente_container] Inicia")

    # Crea cliente blob
    try:
        # Instancia un ContainerClient
        CONTAINERCLIENT = BLOBSERVICECLIENT.get_container_client(container_name)

        p_logger.debug("[instanciar_cliente_container] Finaliza")
        return CONTAINERCLIENT

    except AzureError as e:
        p_logger.error(
            "Hubo un error al intentar instanciar el cliente del container: %s", str(e)
        )
        p_logger.error("Error: %s", traceback.format_exc())
        return None


def instanciar_cliente_blob(blob_name):
    """instanciar_cliente_blob - se instancia el cliente del blob
    Parámetros :
    - blob_name: nombre del archivo
    Retorno :
    - Instancia cliente del blob
    """
    global BLOBCLIENT
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[instanciar_cliente_blob] Inicia")

    try:
        # Instancia un BlobClient
        BLOBCLIENT = CONTAINERCLIENT.get_blob_client(blob_name)

        p_logger.debug("[instanciar_cliente_blob] Finaliza")
        return BLOBSERVICECLIENT

    except AzureError as e:
        p_logger.error(
            "Hubo un error al intentar instanciar el cliente del blob: %s", str(e)
        )
        p_logger.error("Error: %s", traceback.format_exc())
        return None


def borrar_blob():
    """borrar_blob - elimina un archivo
    Parámetros :
    Retorno :
    - True si el archivo se eliminó correctamente
    - False si hubo problemas al eliminar el archivo
    """
    p_logger = log.getLogger(cfgs["logger_name"])
    try:
        p_logger.debug(
            "[borrar_blob] Inicia el borrado del archivo en el blob storage."
        )
        BLOBCLIENT.delete_blob()
        p_logger.debug(
            "[borrar_blob] Finaliza el borrado del archivo en el blob storage."
        )
        return True

    except AzureError as e:
        p_logger.error("No se pudo borrar el archivo. Error: %s", str(e))
        p_logger.error("Error: %s", traceback.format_exc())
        return False


def borrar_blobs(blob_list):
    """borrar_blobs - elimina los archivos indicados
    Parámetros :
    - blob_list: lista de archivos
    Retorno :
    - True si los archivos se eliminaron correctamente
    - False si hubo problemas al eliminar los archivos
    """
    p_logger = log.getLogger(cfgs["logger_name"])
    try:
        p_logger.debug(
            "[borrar_blobs] Inicia el borrado de archivos en el blob storage."
        )
        p_logger.debug("[borrar_blobs] blob_list: %s.", blob_list)
        CONTAINERCLIENT.delete_blobs(*blob_list)
        p_logger.debug(
            "[borrar_blobs] Finaliza el borrado de archivos en el blob storage."
        )
        return True

    except AzureError as e:
        p_logger.error(
            "No se pudo borrar los archivos %s. Error: %s", blob_list, str(e)
        )
        p_logger.error("Error: %s", traceback.format_exc())
        return False


def obtener_lista_blobs():
    """obtener_lista_blobs - obtiene el listado de todos los blobs de un container
    Retorno :
    - Listado con los blobs del container
    """
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[obtener_lista_blobs] Inicia")
    try:
        blob_list = CONTAINERCLIENT.list_blobs()
        p_logger.debug("[obtener_lista_blobs] Finaliza")
        return blob_list

    except AzureError as e:
        p_logger.error(
            "Hubo un error al intentar obtener la lista de blobs: %s", str(e)
        )
        p_logger.error("Error: %s", traceback.format_exc())
        return []


def download_blob_to_pandas(header=True):
    """download_blob_to_pandas - descarga un archivo del blob storage
    Parámetros :
    - header: True si tiene cabecera, None si no tiene cabecera
    Retorno :
    - df con el contenido del archivo
    """
    p_logger = log.getLogger(cfgs["logger_name"])
    try:
        p_logger.debug(
            "[download_blob_toPandas] Inicia descarga del archivo del blob storage."
        )
        # read blob content as string
        blobstring = BLOBCLIENT.download_blob().readall().decode("utf-8")
        if header:
            df = pandas.read_csv(StringIO(blobstring))
        else:
            df = pandas.read_csv(StringIO(blobstring), header=header)
        p_logger.debug(
            "[download_blob_toPandas] Finaliza descarga del archivo del blob storage."
        )
        return df

    except AzureError as e:
        p_logger.error("No se pudo desacargar el archivo. Error: %s", str(e))
        p_logger.error("Error: %s", traceback.format_exc())
        return None


def upload_blob_from_pandas(datos, index=True):
    """upload_blob_from_pandas - escribe un df en el blob storage
    Parámetros :
    - datos: contenido del archivo a subir
    - index: True para escribir con index, False para escribir sin index
    Retorno :
    - True si el archivo se subio correctamente
    - False si hubo problemas al subir el archivo
    """
    p_logger = log.getLogger(cfgs["logger_name"])
    try:
        p_logger.debug(
            "[upload_blob_fromPandas] Inicia escritura del archivo en el blob storage."
        )
        if index:
            output = datos.to_csv()
        else:
            output = datos.to_csv(index=False)
        BLOBCLIENT.upload_blob(output)
        p_logger.debug("[upload_blob_fromPandas] Finaliza escritura del archivo.")
        return True

    except AzureError as e:
        p_logger.error("No se pudo subir el archivo. Error: %s", str(e))
        p_logger.error("Error: %s", traceback.format_exc())
        return False


def download_blob_to_file(file_path):
    """download_blob_to_file - descarga un archivo del blob storage
    Parámetros :
    - file_path: path del archivo a bajar (destino)
    Retorno :
    - True si el archivo se bajo correctamente
    - False si hubo problemas al bajar el archivo
    """
    p_logger = log.getLogger(cfgs["logger_name"])
    try:
        p_logger.debug(
            "[download_blob_toFile] Inicia descarga del archivo del blob storage."
        )
        with open(file_path, "wb") as download_file:
            download_file.write(BLOBCLIENT.download_blob().readall())
        p_logger.debug(
            "[download_blob_toFile] Finaliza descarga del archivo del blob storage."
        )
        return True

    except AzureError as e:
        p_logger.error("No se pudo obtener el archivo %s. Error: %s", file_path, str(e))
        p_logger.error("Error: %s", traceback.format_exc())
        return False

    except OSError as e:
        p_logger.error(
            "Se produjo un error intentando leer el archivo = %s",
            file_path,
        )
        p_logger.error("OS error(%s): %s", e.errno, e.strerror)
        p_logger.error(traceback.format_exc())
        return False


def upload_blob_from_file(file_path):
    """upload_blob_from_file - sube un archivo al blob storage
    Parámetros :
    - file_path: path del archivo a subir (origen)
    Retorno :
    - True si el archivo se subió correctamente
    - False si hubo problemas al subir el archivo
    """
    p_logger = log.getLogger(cfgs["logger_name"])
    try:
        p_logger.debug(
            "[upload_blob_fromFile] Inicia subida del archivo en el blob storage."
        )
        with open(file_path, "rb") as data:
            BLOBCLIENT.upload_blob(data, overwrite=True)
        p_logger.debug(
            "[upload_blob_fromFile] Finaliza subida del archivo en el blob storage."
        )
        return True

    except AzureError as e:
        p_logger.error("No se pudo subir el archivo %s. Error: %s", file_path, str(e))
        p_logger.error("Error: %s", traceback.format_exc())
        return False

    except OSError as e:
        p_logger.error(
            "Se produjo un error intentando leer el archivo = %s",
            file_path,
        )
        p_logger.error("OS error(%s): %s", e.errno, e.strerror)
        p_logger.error(traceback.format_exc())
        return False


def copiar_blob(source_blob):
    """copiar_blob - copia un archivo del blob storage con otro nombre, dentro del mismo container
    Parámetros :
    - source_blob: el blob origen
    Retorno :
    - True si el archivo se copió correctamente
    - False si hubo problemas al copiar el archivo
    """
    p_logger = log.getLogger(cfgs["logger_name"])
    try:
        p_logger.debug(
            "[copiar_blob] Inicia el copiado del archivo en el blob storage."
        )
        # blob_url = blob.make_blob_url(container_name, path_origen)
        BLOBCLIENT.start_copy_from_url(source_blob)
        p_logger.debug(
            "[copiar_blob] Finaliza el copiado del archivo en el blob storage."
        )
        return True

    except AzureError as e:
        p_logger.error("No se pudo copiar el archivo: %s.", str(e))
        p_logger.error("Error: %s", traceback.format_exc())
        return False

    except OSError as e:
        p_logger.error("No se pudo copiar el archivo: %s.", str(e))
        p_logger.error("OS error(%s): %s", e.errno, e.strerror)
        p_logger.error(traceback.format_exc())
        return False
