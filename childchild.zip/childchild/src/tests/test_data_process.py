"""Pruebas unitarias para el módulo data.data_process"""
import os
import pathlib
import sys
from typing import Dict

import numpy as np
import pandas as pd
import pytest

CURRENTDIR = os.path.dirname(os.path.realpath(__file__))
PARENTDIR = os.path.dirname(CURRENTDIR)
sys.path.append(PARENTDIR)

import data.data_process as dp
from functions import functions_logger
from functions import functions_utils as f_utils

cfgs: Dict[str, str] = {}

BASE_HEADER = "ID_EVENTO,PAD,PAD_ESTIMULACION,HIJO,ETAPA,RIG,HERMANO,INICIO_FRAC,FIN_FRAC,\
INICIO_BU,CUM_VOL,AMPLITUD_BU,INICIO_FO,AMPLITUD_FO,iBU,iFO,CATEGORIA_COMENTARIO,COMENTARIO,\
FECHA_ACTUALIZACION_OW,ID_INTERPRETE,FECHA_INTERPRETACION"
BASE_EVENTO1 = "YPF.Nq.RDMN-5(h)-YPF.Nq.RDMN-6(h)-3,RDMN_PAD-2,RDMN_PAD-2,YPF.Nq.RDMN-5(h),\
3.0,SI-NOC-02,YPF.Nq.RDMN-6(h),2018-11-02 20:11:00.000000,2018-11-02 23:00:00.000000,\
2018-11-02 20:57:52.044600,,60.75490277438622,2018-11-02 22:45:01.790780,\
-0.5014726641911693,0.9698532957492269,-0.05014726641911693,,,2019-10-20 13:56:40.000000,,"
BASE_EVENTO2 = "YPF.Nq.LACh-413(h)-YPF.Nq.LACh-412(h)-1,LACh_PAD-109,LACh_PAD-109,\
YPF.Nq.LACh-413(h),1.0,TRON-16,YPF.Nq.LACh-412(h),2022-01-26 06:59:00,2022-01-26 09:21:00,,,\
0.0,,0.0,0.0,0.0,,,2022-10-07 14:58:41,RY26776,2022-11-29 17:48:50.278411"
BASE_EVENTO3 = "YPF.Nq.LLL-1624(h)-YPF.Nq.LLL-1623(h)-15,LC_PAD-284,LC_PAD-284,\
YPF.Nq.LLL-1624(h),15.0,TRON-24,YPF.Nq.LLL-1623(h),2021-01-15 15:55:00,2021-01-15 18:21:00,,,\
999.0,,999.0,999.0,999.0,,,2021-09-02 12:07:30,,"
EVENTOS_HEADER = "ID_EVENTO,HIJO,ETAPA,HERMANO,INICIO_FRAC,FIN_FRAC,TAG_P,\
inicioBajadaDatos,finBajadaDatos,TAG_HERMANO"
EVENTOS_EVENTO1 = "YPF.Nq.RDMN-5(h)-YPF.Nq.RDMN-6(h)-3,YPF.Nq.RDMN-5(h),3.0,YPF.Nq.RDMN-6(h),\
2018-11-02 20:11:00,2018-11-02 23:00:00,YPF-SA-Less-ANC-02_PRESION1,2018-11-02 20:11:00,\
2018-11-03 00:00:00,YPF-SA-Less-ANC-02_PRESION3"
EVENTOS_EVENTO2 = "YPF.Nq.LACh-413(h)-YPF.Nq.LACh-412(h)-1,YPF.Nq.LACh-413(h),1.0,\
YPF.Nq.LACh-412(h),2022-01-26 06:59:00,2022-01-26 09:21:00,MASE-16_PRESION2,\
2022-01-26 06:59:00,2022-01-26 10:21:00,MASE-16_PRESION1"
EVENTOS_EVENTO3 = "YPF.Nq.LLL-1624(h)-YPF.Nq.LLL-1623(h)-15,YPF.Nq.LLL-1624(h),15.0,\
YPF.Nq.LLL-1623(h),2021-01-15 15:55:00,2021-01-15 18:21:00,MASE-24_PRESION2,\
2021-01-15 15:55:00,2021-01-15 19:21:00,MASE-24_PRESION1"
PRESIONES_HEADER = "Timestamp,Valor,ID_EVENTO,Error"


@pytest.fixture(name="base_mock")
def fixture_base_mock():
    """
    Fixture para inicializar las variables utilizadas en armado_df_para_bajada_presiones
    """
    base_test = "UT_BASE_CHILD-CHILD.csv"
    sensores = "Sensores.csv"
    eventos_test = "UT_EVENTOS.csv"

    inicializar()

    f_utils.cfgs = cfgs
    config_strg = f_utils.leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])
    base_fp = (
        config_strg["path_folder_data"] + config_strg["path_input"] + "/" + base_test
    )
    sensores_fp = (
        config_strg["path_folder_data"] + config_strg["path_input"] + "/" + sensores
    )
    eventos_fp = (
        config_strg["path_folder_data"] + config_strg["path_input"] + "/" + eventos_test
    )

    input_schema = {
        "column_hijo": "HIJO",
        "column_tag_hijo": "TAG_P",
        "column_hermano": "HERMANO",
        "column_inicio_frac": "INICIO_FRAC",
        "column_fin_frac": "FIN_FRAC",
        "column_inicio_bu": "INICIO_BU",
        "column_inicio_fo": "INICIO_FO",
        "column_evento_id": "ID_EVENTO",
        "column_etapa": "ETAPA",
    }
    fecha_minima = "2018-01-01 00:00:00"

    base = pathlib.Path(base_fp)
    base.write_text(
        BASE_HEADER
        + "\n"
        + BASE_EVENTO1
        + "\n"
        + BASE_EVENTO2
        + "\n"
        + BASE_EVENTO3
        + "\n",
        encoding="utf-8",
    )

    eventos = pathlib.Path(eventos_fp)
    eventos.write_text(EVENTOS_HEADER + "\n", encoding="utf-8")

    yield (base_fp, sensores_fp, eventos_fp, input_schema, fecha_minima)

    # Clean
    base.unlink()
    eventos.unlink()


@pytest.fixture(name="eventos_mock")
def fixture_eventos_mock():
    """
    Fixture para inicializar las variables utilizadas en armado_df_para_bajada_presiones
    """
    eventos_test = "UT_EVENTOS.csv"
    presiones_test = "UT_PRESIONES.csv"

    inicializar()

    f_utils.cfgs = cfgs
    config_strg = f_utils.leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])
    eventos_fp = (
        config_strg["path_folder_data"] + config_strg["path_input"] + "/" + eventos_test
    )
    presiones_fp = (
        config_strg["path_folder_data"]
        + config_strg["path_input"]
        + "/"
        + presiones_test
    )

    input_schema = {
        "column_evento_id": "ID_EVENTO",
        "column_inicio": "inicioBajadaDatos",
        "column_fin": "finBajadaDatos",
        "column_tag_hermano": "TAG_HERMANO",
    }

    eventos = pathlib.Path(eventos_fp)
    eventos.write_text(
        EVENTOS_HEADER
        + "\n"
        + EVENTOS_EVENTO1
        + "\n"
        + EVENTOS_EVENTO2
        + "\n"
        + EVENTOS_EVENTO3
        + "\n",
        encoding="utf-8",
    )

    yield (eventos_fp, presiones_fp, input_schema)

    # Clean
    eventos.unlink()


@pytest.fixture(name="clasificacion_mock")
def fixture_clasificacion_mock():
    """
    Fixture para inicializar las variables utilizadas en armado_df_para_clasificacion
    """
    eventos_test = "UT_EVENTOS.csv"
    presiones_test = "UT_PRESIONES.csv"
    eventos_con_presiones_test = "UT_EVENTOS_PRESIONES.csv"
    clasificacion_test = "UT_CLASIFICACION.csv"

    inicializar()

    f_utils.cfgs = cfgs
    config_strg = f_utils.leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])
    eventos_fp = (
        config_strg["path_folder_data"] + config_strg["path_input"] + "/" + eventos_test
    )
    presiones_fp = (
        config_strg["path_folder_data"]
        + config_strg["path_input"]
        + "/"
        + presiones_test
    )
    eventos_presiones_fp = (
        config_strg["path_folder_data"]
        + config_strg["path_input"]
        + "/"
        + eventos_con_presiones_test
    )
    clasificacion_fp = (
        config_strg["path_folder_data"]
        + config_strg["path_input"]
        + "/"
        + clasificacion_test
    )

    input_schema = {
        "column_id_evento": "ID_EVENTO",
        "column_index": "index",
        "column_inicio_frac": "INICIO_FRAC",
        "column_fin_frac": "FIN_FRAC",
        "column_inicio_bu": "INICIO_BU",
        "column_inicio_fo": "INICIO_FO",
        "column_evento": "evento",
        "column_tipo_evento": "tipoEvento",
        "column_name_evento": "Interferido",
        "column_hijo": "HIJO",
        "column_tag_hijo": "TAG_P",
        "column_hermano": "HERMANO",
        "column_time": "Timestamp",
        "column_presion": "Valor",
    }
    numero_datos = 35
    porcentaje_filtrado = 65
    time_limit = 30

    eventos = pathlib.Path(eventos_fp)
    eventos.write_text(
        EVENTOS_HEADER
        + "\n"
        + EVENTOS_EVENTO1
        + "\n"
        + EVENTOS_EVENTO2
        + "\n"
        + EVENTOS_EVENTO3
        + "\n",
        encoding="utf-8",
    )

    yield (
        eventos_fp,
        presiones_fp,
        eventos_presiones_fp,
        clasificacion_fp,
        input_schema,
        numero_datos,
        porcentaje_filtrado,
        time_limit,
    )

    # Clean
    eventos.unlink()


def inicializar():
    """
    Acá colocamos todos los seteos iniciales de configuración
    """
    # Inicialización del logger
    logger_name = "ejecucion_test"
    logger_path_cfgs = "./src/config/config_api_logger.yml"

    functions_logger.crear_logger(logger_name=logger_name, config_file=logger_path_cfgs)

    blob_path_cfgs = "./src/config/config_archivos_blob.yml"

    # Inicialización de variables de configuración
    cfgs["logger_name"] = logger_name  # nombre del logger
    cfgs["path_cfg_loggers"] = logger_path_cfgs  # config logger
    cfgs["conf_arc_blob"] = blob_path_cfgs  # config path files
    cfgs["ambiente"] = "DEV"

    # Asignación de la variable de configuración en todos los modulos usados
    dp.cfgs = cfgs


def test_armado_df_para_clasificacion(clasificacion_mock):
    """
    Valido que la estructura del df resultante sea la esperada.
    Valido que el df resultante no este vacío
    Valido que no haya duplicados
    Valido que estén los eventos esperados
    Valido la cantidad de registros
    """
    (
        eventos_fp,
        presiones_fp,
        eventos_presiones_fp,
        clasificacion_fp,
        input_schema,
        numero_datos,
        porcentaje_filtrado,
        time_limit,
    ) = clasificacion_mock

    df_clasificacion = dp.armado_df_para_clasificacion(
        eventos_fp=eventos_fp,
        presiones_fp=presiones_fp,
        eventos_presiones_fp=eventos_presiones_fp,
        time_limit=time_limit,
        porcentaje_filtrado=porcentaje_filtrado,
        numero_datos=numero_datos,
        data_struct=input_schema,
    )
    df_clasificacion.to_csv(clasificacion_fp, index=False)
    df_clasificacion = pd.read_csv(clasificacion_fp)

    clasificacion_schema = [
        "0",
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "10",
        "11",
        "12",
        "13",
        "14",
        "15",
        "16",
        "17",
        "18",
        "19",
        "20",
        "21",
        "22",
        "23",
        "24",
        "25",
        "26",
        "27",
        "28",
        "29",
        "30",
        "31",
        "32",
        "33",
        "34",
        "1_diff",
        "2_diff",
        "3_diff",
        "4_diff",
        "5_diff",
        "6_diff",
        "7_diff",
        "8_diff",
        "9_diff",
        "10_diff",
        "11_diff",
        "12_diff",
        "13_diff",
        "14_diff",
        "15_diff",
        "16_diff",
        "17_diff",
        "18_diff",
        "19_diff",
        "20_diff",
        "21_diff",
        "22_diff",
        "23_diff",
        "24_diff",
        "25_diff",
        "26_diff",
        "27_diff",
        "28_diff",
        "29_diff",
        "30_diff",
        "31_diff",
        "32_diff",
        "33_diff",
        "34_diff",
        "ID_EVENTO",
    ]

    # La estructura del df es la esperada
    assert clasificacion_schema == df_clasificacion.columns.to_list()

    # El df no debe estar vacío
    assert not df_clasificacion.empty

    # El archivo no debe tener duplicados
    df_duplicados = df_clasificacion[df_clasificacion.duplicated()]
    assert df_duplicados.empty

    # Valido que estén los eventos esperados
    column_evento_id = input_schema.get("column_evento_id", "ID_EVENTO")
    eventos = df_clasificacion[column_evento_id].unique().tolist()

    assert eventos == [
        "YPF.Nq.RDMN-5(h)-YPF.Nq.RDMN-6(h)-3",
        "YPF.Nq.LLL-1624(h)-YPF.Nq.LLL-1623(h)-15",
    ]

    # El archivo resultante debe tener 2 registros
    assert df_clasificacion.shape[0] == 2


def test_bajada_presiones(eventos_mock):
    """
    Valido que la estructura del df resultante (presiones) sea la esperada.
    Valido que el df resultante no este vacío
    Valido que no haya duplicados
    Valido que estén los eventos esperados
    Valido la cantidad de registros
    Valido evento sin presiones
    """
    eventos_fp, presiones_fp, input_schema = eventos_mock

    df_presiones = dp.bajada_presiones(
        eventos_fp=eventos_fp, eventos_procesados=[], data_struct=input_schema
    )
    df_presiones.to_csv(presiones_fp, index=False)
    df_presiones = pd.read_csv(presiones_fp)

    presiones_schema = [
        "Timestamp",
        "Valor",
        "ID_EVENTO",
        "Error",
    ]

    # La estructura del df es la esperada
    assert presiones_schema == df_presiones.columns.to_list()

    # El df no debe estar vacío
    assert not df_presiones.empty

    # El archivo no debe tener duplicados
    df_duplicados = df_presiones[df_presiones.duplicated()]
    assert df_duplicados.empty

    # Valido que estén los eventos esperados
    column_evento_id = input_schema.get("column_evento_id", "ID_EVENTO")
    eventos = df_presiones[column_evento_id].unique().tolist()

    assert eventos == [
        "YPF.Nq.RDMN-5(h)-YPF.Nq.RDMN-6(h)-3",
        "YPF.Nq.LACh-413(h)-YPF.Nq.LACh-412(h)-1",
        "YPF.Nq.LLL-1624(h)-YPF.Nq.LLL-1623(h)-15",
    ]

    # El archivo resultante debe tener 126 registros
    assert df_presiones.shape[0] == 126

    # Valido evento sin presiones
    df_evento_sin_presion = df_presiones[
        df_presiones["ID_EVENTO"] == "YPF.Nq.LACh-413(h)-YPF.Nq.LACh-412(h)-1"
    ]
    assert df_evento_sin_presion["Error"].all() != ""


def test_armado_df_para_bajada_presiones(base_mock):
    """
    Valido que la estructura del df resultante (eventos) sea la esperada.
    Valido que el df resultante no este vacío
    Valido que no haya duplicados
    Valido tag hijo y tag hermano
    Valido que la fecha fin sea mayor a la fecha inicio
    """
    base_fp, sensores_fp, eventos_fp, input_schema, fecha_minima = base_mock

    df_eventos = dp.armado_df_para_bajada_presiones(
        childchild_fp=base_fp,
        sensores_fp=sensores_fp,
        eventos_procesados=[],
        fecha_minima=fecha_minima,
        data_struct=input_schema,
    )
    df_eventos.to_csv(eventos_fp, index=False)

    eventos_schema = [
        "ID_EVENTO",
        "HIJO",
        "ETAPA",
        "HERMANO",
        "INICIO_FRAC",
        "FIN_FRAC",
        "TAG_P",
        "inicioBajadaDatos",
        "finBajadaDatos",
        "TAG_HERMANO",
    ]

    # La estructura del df es la esperada
    assert eventos_schema == df_eventos.columns.to_list()

    # El df no debe estar vacío
    assert not df_eventos.empty

    # El archivo no debe tener duplicados
    df_duplicados = df_eventos[df_eventos.duplicated()]
    assert df_duplicados.empty

    # Lista de tags hijos esperados
    column_tag_hijo = input_schema.get("column_tag_hijo", "TAG_P")
    tag_hijo = df_eventos[column_tag_hijo].to_list()

    assert tag_hijo == [
        "YPF-SA-Less-ANC-02_PRESION1",
        "MASE-16_PRESION2",
        "MASE-24_PRESION2",
    ]

    # Lista de tags hermanos esperados
    column_tag_hermano = input_schema.get("column_tag_hermano", "TAG_HERMANO")
    tag_hermano = df_eventos[column_tag_hermano].to_list()

    assert tag_hermano == [
        "YPF-SA-Less-ANC-02_PRESION3",
        "MASE-16_PRESION1",
        "MASE-24_PRESION1",
    ]

    # Fecha fin debe ser mayor a fecha inicio
    column_inicio_bajada = input_schema.get(
        "column_inicioBajadaDatos", "inicioBajadaDatos"
    )
    column_fin_bajada = input_schema.get("column_finBajadaDatos", "finBajadaDatos")

    comparison_column = np.where(
        df_eventos[column_fin_bajada] > df_eventos[column_inicio_bajada], True, False
    )

    assert np.alltrue(comparison_column == [True, True, True])
