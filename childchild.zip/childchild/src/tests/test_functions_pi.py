"""Pruebas unitarias para el módulo functions.functions_pi"""
import os
import sys
from typing import Dict

import pytest
from requests.auth import HTTPBasicAuth, HTTPDigestAuth

CURRENTDIR = os.path.dirname(os.path.realpath(__file__))
PARENTDIR = os.path.dirname(CURRENTDIR)
sys.path.append(PARENTDIR)

import functions.functions_pi as pi
from functions import functions_logger

cfgs: Dict[str, str] = {}


@pytest.fixture(name="webapi")
def fixture_webapi() -> pi.PiWebapi:
    """
    Fixture para inicializar el objeto PiWebapi de manera correcta

    Returns:
        pi.PiWebapi: objeto PiWebapi con propiedades correctamente seteadas
    """
    pi_webapi_user = "YS01480"
    pi_webapi_password = "2gY7akMz"
    pi_webapi_security_method = "basic"
    pi_verify_ssl = False
    pi_webapi_url = "https://ssbuetmspi01/piwebapi"
    pi_path = "ssbuetmspi01"

    inicializar()

    pi_webapi = pi.PiWebapi(
        pi_webapi_url,
        pi_path,
        pi_webapi_security_method,
        pi_verify_ssl,
        pi_webapi_user,
        pi_webapi_password,
    )

    return pi_webapi


@pytest.fixture(name="webapi_bad")
def fixture_webapi_bad() -> pi.PiWebapi:
    """
    Fixture para inicializar el objeto PiWebapi de manera incorrecta

    Returns:
        pi.PiWebapi: objeto PiWebapi con propiedades incorrectamente seteadas
    """
    pi_webapi_user = ""
    pi_webapi_password = ""
    pi_webapi_security_method = "Kerberos"
    pi_verify_ssl = False
    pi_webapi_url = "https://pipepe/piwebapi"
    pi_path = "pipepe"

    inicializar()

    pi_webapi = pi.PiWebapi(
        pi_webapi_url,
        pi_path,
        pi_webapi_security_method,
        pi_verify_ssl,
        pi_webapi_user,
        pi_webapi_password,
    )

    return pi_webapi


def inicializar():
    """
    Acá colocamos todos los seteos iniciales de configuración
    """
    # Inicialización del logger
    logger_name = "ejecucion_api"
    logger_path_cfgs = "./src/config/config_api_logger.yml"
    # logger_path_cfgs = '../config/config_api_logger.yml'
    functions_logger.crear_logger(logger_name=logger_name, config_file=logger_path_cfgs)

    # Inicialización de variables de configuración
    cfgs["logger_name"] = logger_name  # nombre del logger
    cfgs["path_cfg_loggers"] = logger_path_cfgs  # config logger

    # Asignación de la variable de configuración en todos los modulos usados
    pi.cfgs = cfgs


def test_call_security_method_basic(caplog, webapi):
    """
    Chequeo que nos podamos conectar con metodo Basic.
    La función tiene que devolver un objeto HTTPBasicAuth
    En los logs que genera la función no debe haber warnings
    """

    security_auth = webapi.call_security_method()

    assert isinstance(security_auth, HTTPBasicAuth)
    for record in caplog.records:
        assert record.levelname != "WARNING"


def test_call_security_method_kerberos(caplog, webapi_bad):
    """
    Chequeo que no nos podamos conectar con metodo Kerberos.
    La función no tiene que devolver un objeto HTTPDigestAuth
    En los logs que genera la función debe haber warnings
    """

    security_auth = webapi_bad.call_security_method()

    assert not isinstance(security_auth, HTTPDigestAuth)
    assert caplog.records[0].levelname == "WARNING"


def test_generate_webid_from_path(webapi):
    """
    Chequeo que funcione de manera esparada la encodificación del tag
    """

    tag = "MASE-23_PRESION1"

    webid = webapi.generate_webid_from_path(rf"{webapi.path}\{tag}")

    assert webid == "P1AbEU1NCVUVUTVNQSTAxXE1BU0UtMjNfUFJFU0lPTjE="


@pytest.mark.xfail
def test_get_summary_data_bad_url(webapi_bad):
    """
    Chequeo que falle para una url errónea
    """

    webid = "P1AbEU1NCVUVUTVNQSTAxXE1BU0UtMjNfUFJFU0lPTjE="
    start_time = "2020-12-17 12:49:00.000"
    end_time = "2020-12-17 13:00:00.000"

    security_auth = webapi_bad.callSecurityMethod()

    webapi_bad.getSummaryData(security_auth, webid, start_time, end_time)
