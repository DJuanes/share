"""Pruebas unitarias para el módulo ds.predict"""
import os
import sys
from typing import Dict

import pytest

CURRENTDIR = os.path.dirname(os.path.realpath(__file__))
PARENTDIR = os.path.dirname(CURRENTDIR)
sys.path.append(PARENTDIR)

import ds.predict as pred
from functions import functions_logger
from functions import functions_utils as f_utils

cfgs: Dict[str, str] = {}


@pytest.fixture(name="predict_mock")
def fixture_predict_mock():
    """
    Fixture para inicializar las variables utilizadas en predict
    """
    eventos_test = "TEST_EVENTOS_PRESIONES.csv"
    clasificacion_test = "TEST_CLASIFICACION.csv"
    resultado_test = "TEST_RESULTADOS_COE_CHILD-CHILD.csv"

    inicializar()

    f_utils.cfgs = cfgs
    config_strg = f_utils.leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])
    model_fp = "./models/modelo_muliclass_eventos_xgboost.joblib"
    eventos_fp = (
        config_strg["path_folder_data"] + config_strg["path_input"] + "/" + eventos_test
    )
    clasificacion_fp = (
        config_strg["path_folder_data"]
        + config_strg["path_input"]
        + "/"
        + clasificacion_test
    )
    resultado_fp = (
        config_strg["path_folder_data"]
        + config_strg["path_input"]
        + "/"
        + resultado_test
    )

    input_schema = {
        "column_id_evento": "ID_EVENTO",
        "column_index": "index",
        "column_inicio_frac": "INICIO_FRAC",
        "column_fin_frac": "FIN_FRAC",
        "column_inicio_bu": "INICIO_BU",
        "column_inicio_fo": "INICIO_FO",
        "column_evento": "evento",
        "column_tipo_evento": "tipoEvento",
        "column_name_evento": "Interferido",
        "column_hijo": "HIJO",
        "column_tag_hijo": "TAG_P",
        "column_hermano": "HERMANO",
        "column_time": "Timestamp",
        "column_presion": "Valor",
    }

    return (
        model_fp,
        eventos_fp,
        clasificacion_fp,
        resultado_fp,
        input_schema,
    )


def inicializar():
    """
    Acá colocamos todos los seteos iniciales de configuración
    """
    # Inicialización del logger
    logger_name = "ejecucion_test"
    logger_path_cfgs = "./src/config/config_api_logger.yml"
    print(logger_path_cfgs)

    functions_logger.crear_logger(logger_name=logger_name, config_file=logger_path_cfgs)

    blob_path_cfgs = "./src/config/config_archivos_blob.yml"

    # Inicialización de variables de configuración
    cfgs["logger_name"] = logger_name  # nombre del logger
    cfgs["path_cfg_loggers"] = logger_path_cfgs  # config logger
    cfgs["conf_arc_blob"] = blob_path_cfgs  # config path files
    cfgs["ambiente"] = "DEV"

    # Asignación de la variable de configuración en todos los modulos usados
    pred.cfgs = cfgs


def test_predict(predict_mock):
    """
    Validación pendiente
    """

    (
        model_fp,
        eventos_fp,
        clasificacion_fp,
        resultado_fp,
        input_schema,
    ) = predict_mock

    df_final = pred.predict(
        model_fp=model_fp,
        eventos_fp=eventos_fp,
        clasificacion_fp=clasificacion_fp,
        data_struct=input_schema,
    )

    df_final.to_csv(resultado_fp, index=False)
    assert True
