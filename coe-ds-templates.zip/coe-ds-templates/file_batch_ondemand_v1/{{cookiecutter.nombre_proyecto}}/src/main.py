"""Workflow principal"""

import logging
import os
import re
from datetime import datetime
from typing import Dict

import numpy as np
import pandas as pd
import typer

from config import config
from config.config import logger
from src import predict as pred

# Inicializar la aplicación CLI de Typer
app = typer.Typer()


def transform_and_clean(df: pd.DataFrame) -> pd.DataFrame:
    """
    Transforma y limpia los datos de entrada a cada modelo

    Args:
        df (pd.DataFrame): dataframe con los datos de entrada

    Returns:
        pd.DataFrame: dataframe con los datos de entrada transformados y limpios
    """

    if "AT90" in df.columns:
        df.loc[df["AT90"] > 700, "AT90"] = 700
    if "RHOZ" in df.columns:
        df.loc[df["RHOZ"] > 3, "RHOZ"] = 3

    for feature in df.columns:
        if feature in ["LATITUD", "LONGITUD"]:
            df.loc[df[feature] > 0, feature] = np.nan
        else:
            df.loc[df[feature] < 0, feature] = np.nan

    return df.dropna()


def load_artifacts() -> Dict:
    """
    Cargar artefactos para la predicción.

    Returns:
        Dict: artefactos de ejecución.
    """
    artifacts_dir = config.MODELS_DIR
    logger.info("artifacts dir: %s", artifacts_dir)
    models = {}
    for objetivo in config.OBJETIVOS:
        model_fp = artifacts_dir.joinpath(config.MODELOS[objetivo])
        # models[objetivo]: model_with_IC = joblib.load(model_fp)
        logger.info("Carga modelo %s", config.MODELOS[objetivo])
    return models


def inicializar_logger(logfile: str) -> logging.Logger:
    """
    Inicializa el logging interno de DS

    Args:
        logfile (str): nombre del archivo de log

    Returns:
        logging.Logger: objeto logger
    """

    logname = "DS_log"
    loglevel = logging.INFO
    formatter = logging.Formatter("%(asctime)s :: %(name)s :: %(levelname)s :: %(message)s")
    ds_logger = logging.getLogger(logname)
    ds_logger.setLevel(loglevel)
    handler = logging.FileHandler(logfile)
    handler.setLevel(loglevel)
    handler.setFormatter(formatter)
    ds_logger.addHandler(handler)

    return ds_logger


def finalizar_logger(ds_logger: logging.Logger) -> None:
    """
    Cierra todos los handlers del logger

    Args:
        ds_logger (logging.Logger): objeto logger
    """
    if ds_logger is None:
        return
    for handler in list(ds_logger.handlers):
        handler.close()
        ds_logger.removeHandler(handler)


@app.command()
def predict(archivo: str) -> None:
    """
    Ejecuta la predicción

    Args:
        archivo (str): nombre del archivo
    """

    artifacts = load_artifacts()

    os.makedirs(config.DATA_OUTPUT_DIR.joinpath(archivo), exist_ok=True)

    logname = archivo[:-4] + ".log"
    logfile = config.DATA_OUTPUT_DIR.joinpath(archivo).joinpath(logname)
    ds_logger = inicializar_logger(logfile=logfile)
    ds_logger.info("INICIA PROCESO: %s", archivo)

    ds_logger.info("Lectura de datos desde el perfil %s", archivo)
    input_fp = config.DATA_INPUT_DIR.joinpath(archivo)
    try:
        # data = read_perfil_las(input_fp)
        pass
    except ValueError as e:
        ds_logger.critical("No se puede abrir el perfil %s", archivo)
        ds_logger.critical(e)
        ds_logger.info("No se pueden ejecutar los modelos de Mineralogía.")
        ds_logger.info("Moviendo archivo de la carpeta input a processed...")
        output_fp = config.DATA_PROCESSED_DIR.joinpath("/ERROR_LECTURA_" + archivo)
        os.rename(input_fp, output_fp)
        ds_logger.info("FIN PROCESO: %s", archivo)
        return

    # prediccion de los modelos individuales de cada mineral
    # en el dataframe df_predicciones se realizará el merge con las predicciones
    check_sum = 0
    df_predicciones = pd.DataFrame(index=data.index)
    for objetivo in config.OBJETIVOS[:10]:
        # ckeck de que existen las variables para predecir el modelo
        ok_features = set(config.MODEL_FEATURES[objetivo]).issubset(set(data.columns))
        ds_logger.info(
            "¿Están las columnas %s para el modelo %s?: %s",
            config.MODEL_FEATURES[objetivo],
            objetivo,
            str(ok_features),
        )
        # prediccion del modelo
        if ok_features:
            # transformaciones y check de la calidad de los datos
            df_aux = data[config.MODEL_FEATURES[objetivo]].copy()
            df_aux = transform_and_clean(df_aux)
            if df_aux.shape[0] == 0:
                ds_logger.info(
                    "Luego del check de calidad, no quedan registros para predición del modelo."
                )
            else:
                df_aux = pred.predict_model_mineral(model=artifacts[objetivo],
                                                    data=df_aux,
                                                    objetivo=objetivo)
                df_predicciones = df_predicciones.merge(df_aux, how='left',
                                                        left_index=True, right_index=True)
                check_sum += 1

    # reconciliacion de datos: hay que chequear que se hayan ejecutado los 10 modelos
    if check_sum == 0:
        ds_logger.critical("Luego del tratamiento de los datos quedó el DataFrame vacio.")
        ds_logger.info("No se pueden ejecutar los modelos de los minerales.")
        ds_logger.info("Moviendo archivo de la carpeta input a processed.")
        output_fp = config.DATA_PROCESSED_DIR.joinpath("/ERROR_PROCESAMIENTO_" + archivo)
        os.rename(input_fp, output_fp)
        ds_logger.info("FIN PROCESO: %s", archivo)
        return
    if check_sum < 10:
        ds_logger.warning("Solo se ejecutaron %s modelos. Revisar datos de entrada.", check_sum)
        ds_logger.info("No se puede realizar la reconciliciación de datos.")
        ds_logger.info("Escribiendo perfil de salida (LAS) %s", archivo[:-4] + "_COE.las")

        # se reordenan las columnas para que quede primero DEPTH
        data = data[['DEPTH']
                    + [col for col in sorted(data.columns) if col not in ['DEPTH']]]
        data.sort_values(by='DEPTH', inplace=True)

        # se unen las predicciones con los datos originales
        data = data.merge(df_predicciones, how='left',
                          left_index=True, right_index=True)

        # write_las_file(archivo=archivo, data=data)
        ds_logger.info("Moviendo archivo de la carpeta input a processed.")
        output_fp = config.DATA_PROCESSED_DIR.joinpath(archivo)
        os.rename(input_fp, output_fp)
        ds_logger.info("FIN PROCESO: %s", archivo)
        finalizar_logger(ds_logger=ds_logger)
        return

    if check_sum == 12:
        ds_logger.info("Se ejecutaron todos los modelos. Inicia reconciliación de datos.")

        # se reordenan las columnas para que quede primero DEPTH
        data = data[['DEPTH']
                    + [col for col in sorted(data.columns) if col not in ['DEPTH']]]
        data.sort_values(by='DEPTH', inplace=True)

        # ejecutar modelos de suma 1 para modelo de 10 minerales
        ds_logger.info("Reconciliación de datos para 10 minerales.")
        df_aux = pred.reconciliacion_datos_minimize(predicciones=df_predicciones.copy(),
                                                    objetivos=config.MODELO_10,
                                                    rmse=config.RMSE)
        data = data.merge(df_aux, how='left',
                          left_index=True, right_index=True)

        # ejecutar modelos de suma 1 para modelo de 6 minerales
        ds_logger.info("Reconciliación de datos para 6 minerales agrupados.")
        df_aux = pred.reconciliacion_datos_minimize(predicciones=df_predicciones.copy(),
                                                    objetivos=config.MODELO_6,
                                                    rmse=config.RMSE)
        data = data.merge(df_aux, how='left',
                          left_index=True, right_index=True)

        # guardar datos de los minerales reconciliados
        ds_logger.info("Escribiendo perfil de salida (LAS) %s", archivo[:-4] + "_COE.las")
        # write_las_file(archivo=archivo, data=data)
        ds_logger.info("Moviendo archivo de la carpeta input a processed.")
        output_fp = config.DATA_PROCESSED_DIR.joinpath(archivo)
        os.rename(input_fp, output_fp)
        ds_logger.info("FIN PROCESO: %s", archivo)
        finalizar_logger(ds_logger=ds_logger)
        return


if __name__ == "__main__":
    app()  # pragma: aplicación en vivo
