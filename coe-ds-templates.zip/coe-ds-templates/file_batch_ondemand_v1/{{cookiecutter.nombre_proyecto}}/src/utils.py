"""utilidades suplementarias"""

import shutil

from config import config
from config.config import logger


def comprimir_directorio(archivo_comprimido, directorio):
    """comprimir_directorio - crea un archivo zip con el contenido de un directorio
    Parámetros :
    - archivo_comprimido: nombre del archivo comprimido de destino
    - directorio: directorio origen a comprimir
    Retorno:
    - True si el directorio se comprimió correctamente
    - False si hubo problemas al comprimir el directorio
    """
    logger.debug("[comprimir_directorio] Inicia")
    logger.info(
        "[comprimir_directorio] \
        Comprimo directorio %s en archivo %s",
        directorio,
        archivo_comprimido,
    )
    try:
        shutil.make_archive(archivo_comprimido, "zip", directorio)
        return True

    except shutil.Error as ex:
        logger.error("[comprimir_directorio] No se pudo comprimir el directorio.")
        logger.error("Error: %s", ex.strerror)
        return False
