"""Módulo wrapper para functions.functions_blob_storage"""
import logging as log
import os
import re
from datetime import datetime
from typing import Dict

import functions.functions_blob_storage as blb_strg
import functions.functions_utils as utils

cfgs: Dict[str, str] = {}


def download_data_from_blob_storage() -> list:
    """
    Baja los archivos desde blob storage al destino que figura en el config

    Returns:
        list: lista de archivos que se bajaron
    """
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[download_data_from_blob_storage] Inicia")

    config_strg = utils.leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])

    # Instanciamos los clientes de blobService y de Container
    blb_strg.instanciar_cliente_blobservice(
        connection_string=config_strg["blob_connection_string"]
    )
    blb_strg.instanciar_cliente_container(container_name=config_strg["container_name"])

    files = []
    files.append(config_strg["path_input"] + "BASE_CHILD-CHILD.csv")
    files.append(config_strg["path_input"] + "TEST_BASE_CHILD-CHILD.csv")
    files.append(config_strg["path_input"] + "Sensores.csv")
    files.append(config_strg["path_input"] + "PRESIONES.csv")
    files.append(config_strg["path_input"] + "TEST_PRESIONES.csv")
    files.append(config_strg["path_input"] + "EVENTOS.csv")
    files.append(config_strg["path_input"] + "TEST_EVENTOS.csv")
    files.append(config_strg["path_input"] + "CLASIFICACION.csv")
    files.append(config_strg["path_input"] + "TEST_CLASIFICACION.csv")
    files.append(config_strg["path_output"] + "TEST_RESULTADOS_COE_CHILD-CHILD.csv")
    files.append(config_strg["path_output"] + "RESULTADOS_COE_CHILD-CHILD.csv")
    files.append(config_strg["path_output"] + "EVENTOS_PROCESADOS.csv")
    """
    blob_list = blb_strg.obtener_lista_blobs()
    re_comp = re.compile(config_strg["path_input"])
    df = pandas.DataFrame(
        [
            i.name
            for i in blob_list
            if re_comp.match(i.name)
            and i.name != "input/.keep"
            and i.name[:16] != "input/presiones/"
        ],
        columns=["Name"],
    )
    """
    for file in files:
        p_logger.info("[download_data_from_blob_storage] archivo: %s.", file)
        destination_folder = config_strg["path_folder_data"] + file
        blb_strg.instanciar_cliente_blob(blob_name=file)
        blb_strg.download_blob_to_file(file_path=destination_folder)

    return files


def upload_log_to_blob_storage() -> None:
    """
    Sube los logs al blob storage
    """
    config_strg = utils.leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])

    # Instanciamos los clientes de blobService y de Container
    blb_strg.instanciar_cliente_blobservice(
        connection_string=config_strg["blob_connection_string"]
    )
    blb_strg.instanciar_cliente_container(container_name=config_strg["container_name"])

    path_origen = "../logs/root_logger.log"
    path_destino = "logs/log_" + datetime.now().strftime("%Y%m%d") + ".log"
    blb_strg.instanciar_cliente_blob(blob_name=path_destino)
    blb_strg.upload_blob_from_file(path_origen)


def upload_data_to_blob_storage(runid: str = "", eliminar: bool = True) -> None:
    """
    Sube los archivos desde el origen que figura en el config al blob storage

    Args:
        runid (str, optional): Identificador de la ejecución. Defaults to "".
        eliminar (bool, optional): Si borramos los archivos en input. Defaults to True.
    """
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[upload_data_to_blob_storage] Inicia")

    config_strg = utils.leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])

    # Instanciamos los clientes de blobService y de Container
    blb_strg.instanciar_cliente_blobservice(
        connection_string=config_strg["blob_connection_string"]
    )
    blb_strg.instanciar_cliente_container(container_name=config_strg["container_name"])

    files = []
    files.append(config_strg["path_input"] + "PRESIONES.csv")
    files.append(config_strg["path_input"] + "TEST_PRESIONES.csv")
    files.append(config_strg["path_input"] + "EVENTOS.csv")
    files.append(config_strg["path_input"] + "TEST_EVENTOS.csv")
    files.append(config_strg["path_input"] + "CLASIFICACION.csv")
    files.append(config_strg["path_input"] + "TEST_CLASIFICACION.csv")
    files.append(config_strg["path_output"] + "EVENTOS_PROCESADOS.csv")
    files.append(config_strg["path_output"] + "TEST_RESULTADOS_COE_CHILD-CHILD.csv")
    files.append(config_strg["path_output"] + "RESULTADOS_COE_CHILD-CHILD.csv")

    for file in files:
        p_logger.info("[upload_data_to_blob_storage] archivo: %s.", file)

        path_origen = config_strg["path_folder_data"] + file
        blb_strg.instanciar_cliente_blob(blob_name=file)
        is_uploaded = blb_strg.upload_blob_from_file(path_origen)
        if is_uploaded & eliminar:
            os.remove(path_origen)

    """
    file_path = config_strg["path_folder_data"] + config_strg["path_output"] + runid
    lista_output = [
        f for f in os.listdir(file_path) if os.path.isfile(os.path.join(file_path, f))
    ]
    if lista_output:
        for file in lista_output:
            path_origen = (
                config_strg["path_folder_data"]
                + config_strg["path_output"]
                + runid
                + file
            )
            path_destino = config_strg["path_output"] + runid + file
            blb_strg.instanciar_cliente_blob(blob_name=path_destino)
            is_uploaded = blb_strg.upload_blob_from_file(path_origen)
            if is_uploaded & eliminar:
                os.remove(path_origen)

    file_path = config_strg["path_folder_data"] + config_strg["path_output"]
    lista_output = [
        f for f in os.listdir(file_path) if os.path.isfile(os.path.join(file_path, f))
    ]
    if lista_output:
        for file in lista_output:
            path_origen = (
                config_strg["path_folder_data"] + config_strg["path_output"] + file
            )
            path_destino = config_strg["path_output"] + file
            blb_strg.instanciar_cliente_blob(blob_name=path_destino)
            is_uploaded = blb_strg.upload_blob_from_file(path_origen)
            if is_uploaded & eliminar:
                os.remove(path_origen)
    """

    if eliminar:
        clean_data()


def clean_data() -> None:
    """
    Borramos todos los blobs en input
    """
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[clean_data_file] Inicia")

    config_strg = utils.leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])

    # Instanciamos los clientes de blobService y de Container
    blb_strg.instanciar_cliente_blobservice(
        connection_string=config_strg["blob_connection_string"]
    )
    blb_strg.instanciar_cliente_container(container_name=config_strg["container_name"])

    # input container
    blob_list = blb_strg.obtener_lista_blobs()
    re_comp = re.compile(config_strg["path_input"])
    blob_list_delete = [
        b.name for b in blob_list if re_comp.match(b.name) and b.name != "input/.keep"
    ]
    blb_strg.borrar_blobs(blob_list_delete)

    p_logger.debug("[clean_data_file] Finaliza")
