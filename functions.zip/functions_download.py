"""
Módulo para las funciones del ETL del proyecto
Created on Wed Sep 14 13:07:34 2022

@author: RY32053
"""
import numpy as np
import pandas as pd


def to_datetime(df: pd.DataFrame, list_from_str_to_datetime: list) -> pd.DataFrame:
    """
    Transformamos las columnas de tiempo que estan en "str" a numpy.datetime64()

    Args:
        df (pd.DataFrame): dataframe con la base childchild
        list_from_str_to_datetime (list): lista que contiene los features a convertir

    Returns:
        pd.DataFrame: dataframe con los features convertidos
    """
    for features in list_from_str_to_datetime:
        df[features] = pd.to_datetime(
            df[features], format="%Y-%m-%d %H:%M:%S"
        ).to_numpy()
    return df


def fecha_inicial(
    df: pd.DataFrame, column_inicio_frac: str, fecha_minima: str
) -> pd.DataFrame:
    """
    Filtra el dataframe de child child, dejando sólo los registros cuya
    fecha de inicio de fractura es superior a la fecha minima

    Args:
        df (pd.DataFrame): dataframe con la base childchild
        column_inicio_frac (str): columna que contiene el inicio de la fractura
        fecha_minima (str): fecha mínima para acotar los eventos

    Returns:
        pd.DataFrame: dataframe con los registros filtrados
    """
    df = df[df[column_inicio_frac] > fecha_minima]
    return df


def merge_dfs(
    df_childchild: pd.DataFrame,
    df_sensores: pd.DataFrame,
    column_hijo: str,
    column_hermano: str,
    column_rig: str,
) -> pd.DataFrame:
    """
    Unifica las bases childchild con la sensores

    Args:
        df_childchild (pd.DataFrame): dataframe con la base childchild
        df_sensores (pd.DataFrame): dataframe con la base de sensores
        column_hijo (str): nombre de la columna que contiene el pozo hijo
        column_hermano (str): nombre de la columna que contiene el pozo hermano
        column_rig (str): nombre de la columna que contiene el equipo de perforación

    Returns:
        pd.DataFrame: dataframe de eventos
    """
    df_hijo = pd.merge(
        df_childchild,
        df_sensores,
        left_on=[column_hijo, column_rig],
        right_on=[column_hijo, column_rig],
        how="inner",
    )

    df_merged = pd.merge(
        df_hijo,
        df_sensores,
        left_on=[column_hermano, column_rig],
        right_on=[column_hijo, column_rig],
        how="left",
    )

    return df_merged


def get_list_min_time(
    df: pd.DataFrame,
    inicio_bajada_datos: str,
    column_inicio_frac: str,
    column_inicio_bu: str,
    ref_maxtime: np.datetime64,
) -> pd.DataFrame:
    """
    Definimos el tiempo de inicio para la bajada de datos de tal forma que se corresponda
    con el 'INICIO_FRAC" o si hubo algun problema en el registro de los datos
    (si INICIO_BU < INICIO_FRAC --> absurdo), elegir el INICIO_BU como tiempo minimo

    Args:
        df (pd.DataFrame): dataframe con la base de eventos
        inicio_bajada_datos (str): nombre de la columna de inicio bajada datos
        column_inicio_frac (str): nombre de la columna de inicio de fractura
        column_inicio_bu (str): nombre de la columna de inicio de build-up
        ref_maxtime (np.datetime64): fecha máxima

    Returns:
        pd.DataFrame: dataframe con la base de eventos con inicioBajadaDatos
    """
    list_ini_bajada = []
    for i in range(df.shape[0]):
        list_ini_bajada.append(
            df[[column_inicio_frac, column_inicio_bu]]
            .fillna(ref_maxtime)
            .values[i]
            .min()
        )
    df.loc[:, inicio_bajada_datos] = list_ini_bajada

    if not df[inicio_bajada_datos].empty:
        print(" Se agrego la columna de tiempo minimo de referencia")
    return df.loc[:, inicio_bajada_datos]


def get_list_max_time(
    df: pd.DataFrame,
    name_feature_column: str,
    name_feature_ref: str,
    add_time_units: str,
    add_time_value: int,
) -> pd.DataFrame:
    """
    Lógica para calcular finBajadaDatos

    Args:
        df (pd.DataFrame): dataframe con la base de eventos
        name_feature_column (str): nombre de la columna feature
        name_feature_ref (str): nombre de la columna referencia
        add_time_units (str): unidad de medida del tiempo a añadir
        add_time_value (int): cantidad de tiempo a añadir

    Returns:
        pd.DataFrame: dataframe con la base de eventos con finBajadaDatos
    """
    temp_column = "temp"
    final = "final"

    min_time = np.datetime64("2000-08-09T17:47:00.000000000")
    df[temp_column] = df[name_feature_column] + np.timedelta64(
        add_time_value, add_time_units
    )
    list_fin_bajada = []
    for i in range(df.shape[0]):
        list_fin_bajada.append(
            df[[temp_column, name_feature_ref]].fillna(min_time).values[i].max()
        )
    df.loc[:, final] = list_fin_bajada
    if not df.loc[:, final].empty:
        print(" Se agrego la columna de maximo tiempo de referencia")
    return df.loc[:, final]


def features_in_df(df, list_input_features):
    """
    Chequeamos que todas las variables esten en los dfs de entrada

    Args:
        df (pd.DataFrame): dataframe con la base childchild
        list_input_features (list): lista de features

    Returns:
        list: lista que contiene las columnas diferentes de la lista de features
    """
    return np.setdiff1d(list_input_features, df.columns, list_input_features)


def load_events_from_file(eventos_fp: str) -> list:
    """
    Dado un archivo de eventos, devuelve una lista con los eventos a procesar

    Args:
        eventos_fp (str): file path de la base de eventos

    Returns:
        list: lista de eventos a procesar
    """
    with open(eventos_fp, "r", encoding="utf-8") as file:
        lines = file.read().splitlines()[1:]
        events = [line.split(",") for line in lines if line[0] != "#"]
    return events
