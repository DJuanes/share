"""Módulo de funciones helper para logging"""
import dataclasses
import logging
import logging.config
from datetime import datetime

import yaml
from pytz import timezone

from functions import functions_utils


def crear_logger(logger_name, config_file="config/cliente_api_scoring_logger.yml"):
    """crear_logger - creacion del logger
    Parámetros :
    - logger_name: nombre del logger
    - config_file: path donde se encuentra la configuración del logger
    Retorno :
    - logger: instancia del logger
    """

    print(config_file)
    with open(config_file, encoding="utf-8") as parameters:
        levantar_cfg = yaml.safe_load(parameters)

    logging.Formatter.converter = lambda *args: datetime.now(
        tz=timezone("America/Argentina/Buenos_Aires")
    ).timetuple()

    logging.config.dictConfig(levantar_cfg)
    logger = logging.getLogger(logger_name)

    logger.info("[crear_logger] Logger iniciado. ")

    return logger


def logger_default():
    """logger_default - generar un logger de consola default
    Retorno :
    - logger: instancia de logger
    """
    logger = logging.getLogger("root")

    logger.info("[logger_default] Logger iniciado. ")
    return logger


def get_logger_from_param(p_logger=None, prefix_msg="[LOGGER]"):
    """get_logger_from_param - obtiene una instancia del logger a partir de su nombre.
    Si no lo encuentra, retorna el default.
    Parámetros :
    - p_logger: nombre del logger
    - prefix_msg: prefijo para el mensaje
    Retorno :
    - current_logger: instancia del logger
    """
    current_logger = p_logger

    if current_logger is not None:
        current_msg = prefix_msg + " Logger ya configurado"
        current_logger.info(current_msg)

    if current_logger is None:
        current_logger = logger_default()
        current_msg = prefix_msg + " Iniciando logger default"
        current_logger.info(current_msg)

    return current_logger


@dataclasses.dataclass
class MailInfo:
    """
    Clase para encapsular los datos referidos al mail

    Args:
        msg (str): mensaje a enviar por mail
        to (str): destinatario/s del mail
        subject (str): asunto del mail
        body (str): contenido del mail
        p_cfg_param_post_url (str): url para envio de mail
    """

    msg: str
    to: str
    subject: str
    body: str
    p_cfg_param_post_url: str


def logger_and_mail(logger: logging.Logger, level: str, mailinfo: MailInfo):
    """
    Loguea en el logger pasado como argumento y envia un mail

    Args:
        logger (logging.Logger): instancia del logger
        level (str): nivel de logueo
        mailinfo (MailInfo): datos referidos al mail
    """
    # Logea en el logger pasado como argumento
    getattr(logger, level.lower())(mailinfo.msg)
    # Envia mail
    functions_utils.send_mail(
        mailinfo.to, mailinfo.subject, mailinfo.body, mailinfo.p_cfg_param_post_url
    )
