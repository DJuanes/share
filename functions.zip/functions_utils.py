"""Módulo para las funciones utilitarias"""
import logging as log
import shutil
import traceback
from typing import Dict

import requests
import yaml

cfgs: Dict[str, str] = {}


def change_fflag_status(new_status):
    """change_fflag_status - cambia el estado de la API.
    El estado de la API se encuentra escrito en el archivo fflag.txt
    y admite dos valores "PROCESANDO" y "STANDBY"
    Parámetros :
    - new_status: nuevo estado de la API
    """
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[change_fflag_status] Inicia")
    config_strg = leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])

    try:
        with open(config_strg["path_fflag"], "w", encoding="utf-8") as fflag:
            fflag.write(new_status)
            p_logger.info(
                "[ejecutar_proceso] Cambia archivo fflag.txt a %s", new_status
            )

        p_logger.debug("[change_fflag_status] Finaliza")

    except OSError as e:
        p_logger.error(
            "Se produjo un error intentando escribir \
            {config_strg['path_fflag']} con status = %s",
            new_status,
        )
        p_logger.error("OS error(%s): %s", e.errno, e.strerror)
        p_logger.error(traceback.format_exc())


def leer_configuracion(config_file, g_ambiente):
    """leer_configuracion - lee la configuración guardada en un archivo yaml
    Parámetros :
    - config_file: path del archivo de configuracion a leer
    - g_ambiente: ambiente en el que se está ejecutando
    Retorno:
    - resultado: diccionario con la configuracion
    """
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[leer_configuracion] Inicia")
    resultado = None
    try:
        with open(config_file, encoding="utf-8") as parameters:
            config_all = yaml.safe_load(parameters)
        config = config_all[g_ambiente]["SERVER"]
        resultado = config

    except OSError as e:
        p_logger.error("Error leyendo la configuracion.")
        p_logger.error("OS error(%s): %s", e.errno, e.strerror)
        p_logger.error(traceback.format_exc())
        resultado = None

    return resultado


def comprimir_directorio(archivo_comprimido, directorio):
    """comprimir_directorio - crea un archivo zip con el contenido de un directorio
    Parámetros :
    - archivo_comprimido: nombre del archivo comprimido de destino
    - directorio: directorio origen a comprimir
    Retorno:
    - True si el directorio se comprimió correctamente
    - False si hubo problemas al comprimir el directorio
    """
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[comprimir_directorio] Inicia")
    p_logger.info(
        "[comprimir_directorio] \
        Comprimo directorio %s en archivo %s",
        directorio,
        archivo_comprimido,
    )
    try:
        shutil.make_archive(archivo_comprimido, "zip", directorio)
        return True

    except OSError as e:
        p_logger.error("No se pudo comprimir el directorio.")
        p_logger.error("OS error(%s): %s", e.errno, e.strerror)
        p_logger.error(traceback.format_exc())
        return False


def send_mail(
    to,
    subject,
    body,
    p_cfg_param_post_url="http://10.1.33.63/EAI.Mail/SendEmail.asmx?WSDL",
):
    """envia  un mail.
    @param: to: destinatarios: mails separados por ; no separar por otro caracter que no sea ;
    @param: subject: titulo del mail
    @param: body: Cuerpo del mail, mensaje a enviar.
    @param: p_cfg_param_post_url: default:"http://10.1.33.63/EAI.Mail/SendEmail.asmx?WSDL";
        URL donde se postea el WSDL
    @param: p_logger: default = None.
        Logger, si no se instancia se crea una instancia nueva del logger.
    @return: si se mando o no se mando el mail
    @depends: funciones_utilidad,requests,html
    """
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[send_mail] Inicia")
    p_logger.info("[send_mail] Envio mail a %s, con subject: %s", to, subject)

    req = None

    try:
        header_fields = {
            "Accept": "text/xml, multipart/*",
            "Content-Type": "text/xml; charset='UTF-8'",
        }

        subject_to_send = subject
        body_to_send = body + "\n\n"

        body_object = (
            "<?xml version='1.0' encoding='UTF-8'?> \
                    <SOAP-ENV:Envelope xmlns:SOAP-ENV='http://schemas.xmlsoap.org/soap/envelope/' \
                        xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' \
                            xmlns:ns0='http://tempuri.org/' \
                                xmlns:ns1='http://schemas.xmlsoap.org/soap/envelope/'> \
                    <SOAP-ENV:Header/><ns1:Body> \
                    <ns0:SendEmail><ns0:to>"
            + to
            + "</ns0:to> \
                    <ns0:from>no-responder@ypftecnologia.com</ns0:from> \
                    <ns0:subject>[CoE YTEC] "
            + subject_to_send
            + "</ns0:subject> \
                    <ns0:body>"
            + body_to_send
            + "</ns0:body> \
                    <ns0:nameAttachments> </ns0:nameAttachments> \
                    <ns0:secHash>4633c6a0-7c44-4e12-b3a0-cc867db288e8</ns0:secHash> \
                    </ns0:SendEmail> \
                    </ns1:Body> \
                    </SOAP-ENV:Envelope>"
        )
        p_logger.info("[send_mail] body_object: %s", body_object)

        req = requests.post(
            p_cfg_param_post_url, data=body_object, headers=header_fields, timeout=30
        )

    except requests.RequestException as e:
        req = None
        p_logger.error("Se produjo un error al tratar de enviar un mail: %s.", str(e))

    envio_mail = False

    p_logger.info("[send_mail] req status: %s", req.status_code)
    if req is not None:
        if req.status_code == 200:
            envio_mail = True
        else:
            envio_mail = False
    else:
        envio_mail = False

    return envio_mail
