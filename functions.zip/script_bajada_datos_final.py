"""
"""

import logging as log
import sys
import time
from typing import Dict

import functions_download
import function_for_childchild
import numpy as np
import pandas as pd
from joblib import load

cfgs: Dict[str, str] = {}


def armado_df_para_bajada_presiones_por_evento(
    path,
    file_data,
    file_sensores,
    sheet_name_sensores,
    column_hijo,
    column_tag_hijo,
    column_hermano,
    column_inicio_frac,
    column_fin_frac,
    column_inicio_bu,
    column_inicio_fo,
    fecha_minima=None,
):

    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.info("1 -- Lectura de dos archivos:")
    p_logger.info(" (1) - archivo 1 --> datos de los eventos (Nombre : %s", file_data)
    p_logger.info(
        " (2) - archivo 2 --> datos de los TAGs de los eventos (Nombre : %s",
        file_sensores,
    )

    df = pd.read_csv(path + file_data)
    df_sensores = pd.read_excel(path + file_sensores, sheet_name=sheet_name_sensores)

    p_logger.info(
        'Transformamos las columnas de tiempo que estan en "str" a numpy.datetime64()'
    )

    column_tag_hermano = "TAG_HERMANO"
    list_features_df_childchild = [
        column_hijo,
        column_hermano,
        column_inicio_frac,
        column_fin_frac,
        column_inicio_bu,
        column_inicio_fo,
    ]

    # chequeamos que todas las variables esten en los dfs de entrada
    if len(functions_download.features_in_df(df, list_features_df_childchild)) > 0:
        p_logger.info(
            "faltan o cambiaron de nombre las siguientes variables %s",
            str(functions_download.features_in_df(df, list_features_df_childchild)),
        )
        p_logger.info("Esperando arreglar las variables...")
        time.sleep(20)

    # fecha inicio merge entre dfs
    # fechaMinima = '2022-02-01 00:00:00'
    # fechaMinima = '2022-10-01 00:00:00'

    list_from_str_to_datetime = [
        column_inicio_frac,
        column_fin_frac,
        column_inicio_bu,
        column_inicio_fo,
    ]
    df = functions_download.to_datetime(df, list_from_str_to_datetime)
    df_sensores = df_sensores.dropna(subset=[column_tag_hijo])

    #  'Opcional:'
    # ' Si queremos acotar los eventos luego de una determinada fecha'
    if fecha_minima is not None:
        p_logger.info(" Acotamos los eventos luego de una determinada fecha")
        p_logger.info(column_inicio_frac)
        p_logger.info(fecha_minima)
        df = functions_download.fecha_inicial(df, column_inicio_frac, fecha_minima)
        if df.empty:
            p_logger.info("No hay datos a partir de %s", fecha_minima)
            sys.exit()

    p_logger.info(
        '2 -- Unificamos en un solo archivo los datos particulares de cada evento '
        'con los TAG de los pozos "HIJO"'
    )
    p_logger.info("Registro de mas de un sensor/TAG por pozo HIJO (estimulado)")

    # IMPORTANTE: luego de conversar con Yann, él nos comento que el tiempo de inicio de FO,
    # la mayoria de las veces, es posterior a la fecha del fin de fractura,
    # por lo que nos conviene poner como tiempo de fin de bajada de datos
    # --> "finBajadaDatos" + 60 min, para segurarnos que tendremos el momento de inico de FO
    # registrado en los perfiles
    df_eventos_clasificados = functions_download.merge_dfs(
        df, df_sensores, column_hijo, column_tag_hijo, column_hermano, column_tag_hermano
    )

    df_eventos_clasificados = df_eventos_clasificados.rename(
        columns={"INICIO_FRAC_x": column_inicio_frac, "FIN_FRAC_x": column_fin_frac}
    )

    p_logger.info(df_eventos_clasificados.shape)
    p_logger.info("3 -- Agragamos dos columnas al df para fines de bajada de datos:")

    ref_maxtime = np.datetime64("2050-08-09T17:47:00.000000000")
    inicio_bajada_datos = "inicioBajadaDatos"
    fin_bajada_datos = "finBajadaDatos"
    add_timeunits = "m"
    add_timevalue = 60

    df_eventos_clasificados[inicio_bajada_datos] = functions_download.get_list_min_time(
        df_eventos_clasificados,
        inicio_bajada_datos,
        column_inicio_frac,
        column_inicio_bu,
        ref_maxtime,
    )

    #  fiecha final para bajar datos 'finBajadaDatos'
    df_eventos_clasificados[fin_bajada_datos] = functions_download.get_list_max_time(
        df_eventos_clasificados,
        column_fin_frac,
        column_inicio_fo,
        add_timeunits,
        add_timevalue,
    )

    p_logger.info("4 --  Archivo listo para bajar los datos de presion por evento")

    return df_eventos_clasificados


#  path y archivos de entrada:
PATH = "C:/../MisDocumentos/estimulacion/interferencias/data/"
FILE_DATA = "BASE_CHILD-CHILD_220914.csv"
FILE_SENSORES = "Sensores Y-N_220923_YFH.xlsx"
SHEET_NAME_SENSORES = "Diccionario de tags"
#  definicion de variables:
COLUMN_HIJO = "HIJO"
COLUMN_TAG_HIJO = "TAG_P"
COLUMN_HERMANO = "HERMANO"
COLUMN_INICIO_FRAC = "INICIO_FRAC"
COLUMN_FIN_FRAC = "FIN_FRAC"
COLUMN_INICIO_BU = "INICIO_BU"
COLUMN_INICIO_FO = "INICIO_FO"
#  fecha inicio merge entre dfs
FECHA_MINIMA = "2022-02-01 00:00:00"

dfFinal = armado_df_para_bajada_presiones_por_evento(
    PATH,
    FILE_DATA,
    FILE_SENSORES,
    SHEET_NAME_SENSORES,
    COLUMN_HIJO,
    COLUMN_TAG_HIJO,
    COLUMN_HERMANO,
    COLUMN_INICIO_FRAC,
    COLUMN_FIN_FRAC,
    COLUMN_INICIO_BU,
    COLUMN_INICIO_FO,
    fecha_minima=None,
)

#  Guardamos el df final:
#
#     RECORDAR: para bajar los perfiles de presion desde PI el siguiente data input:
#      1- fecha inicio, fecha fin, TAG
PATH_SALIDA = (
    "C:/../MisDocumentos/estimulacion/interferencias/ChildChild_API/data/input/"
)

dfFinal.reset_index()[
    [
        "ID_EVENTO",
        "PAD_x",
        "HIJO",
        "ETAPA",
        "HERMANO",
        "INICIO_FRAC",
        "FIN_FRAC",
        "TAG_P",
        "inicioBajadaDatos",
        "finBajadaDatos",
        "TAG_HERMANO",
    ]
].to_csv(PATH_SALIDA + "dfBajadaDatosInterferencias_220923.csv")

#  LISTO PASO 1-- DF LISTO PARA BAJAR DATOS DE PRESIONES

FOLDER = "C:/../MisDocumentos/estimulacion/interferencias/ChildChild_API/data/input/"
FILE_DATOS = "dfBajadaDatosInterferencias_220923.csv"
FILE_PRESIONES_POR_EVENTO = "presiones20220923.csv"

FOLDER_FOR_MODEL = "C:/../MisDocumentos/estimulacion/interferencias/data/modelos/"
MODEL = "modelo_muliclass_eventos_xgboost.joblib"

#  definicion de variables:
COLUMN_TIME = "Timestamp"
COLUMN_PRESION = "Valor"
COLUMN_ID_EVENTO = "ID_EVENTO"
COLUMN_ID = "ID"
COLUMN_INDEX = "index"
COLUMN_INICIO_FRAC = "INICIO_FRAC"
COLUMN_FIN_FRAC = "FIN_FRAC"
COLUMN_INICIO_BU = "INICIO_BU"
COLUMN_INICIO_FO = "INICIO_FO"
COLUMN_EVENTO = "evento"
COLUMN_TIPO_EVENTO = "tipoEvento"
NAME_EVENTO = "Interferido"
COLUMN_HIJO = "HIJO"
COLUMN_TAG_HIJO = "TAG_P"
COLUMN_HERMANO = "HERMANO"

# Tiempo posterior al fin de la fracturas al que vamos a considerar para cada enento
#
# timeLimit = 30
#
#   (1) Limpieza de Datos:
#
#     1a - Si cada evento ("ID") tiene mas del 65% de los datos Nan, lo quitamos del df
#
# porcentajeFiltrado = 65

# El parametro "numeroDatos" debe ser 35, a menos que querramos cambia toda la estructura del df
# numeroDatos = 35


def generacion_df_con_clasificacion_de_eventos(
    path,
    file_datos,
    file_presiones_por_evento,
    folder_for_model,
    column_evento,
    column_pad,
    column_tipo_evento,
    column_time,
    column_presion,
    column_id_evento,
    column_id,
    column_index,
    column_inicio_frac,
    column_fin_frac,
    column_inicio_bu,
    time_limit,
    porcentaje_filtrado,
    numero_datos,
    name_evento,
    valor_corte,
    list_of_pads_to_delete=None,
):

    p_logger = log.getLogger(cfgs["logger_name"])

    p_logger.info(
        "Lectura de los dos archivos: \n"
        "(1) primer archivo:  caracteristicas de las interferencias \n"
        "(2) segundo archivo:  distribucion de presiones por cada evento\n"
    )

    df_eventos_clasificados = pd.read_csv(path + file_datos)
    df_presiones = pd.read_csv(FOLDER + file_presiones_por_evento)

    #   Teneomos que la columna "Valor" es un str, la cambiamos a float
    #    Transformamos la columna 'Timestamp' de str a  numpy.datetime64()
    dfreferencia = df_eventos_clasificados.copy()

    df_presiones[column_presion] = pd.to_numeric(
        df_presiones[column_presion], errors="coerce"
    )
    df_presiones[column_time] = pd.to_datetime(df_presiones[column_time]).to_numpy()

    # Hacemos el merge entre el df de eventos clasidifcados y de presiones
    # de los pozos hermanos (este merge es un pozo rústico, ver si hay otras opciones
    # para mergeara las dos columnas del archivo de presiones de pozos hermanos como listas)
    df_eventos = (
        dfreferencia.reset_index()
        .rename(columns={column_index: column_id})
        .merge(df_presiones, how="inner", on=column_id_evento)
    )

    p_logger.info(df_eventos.columns)

    df_eventos = df_eventos.rename(
        columns={"INICIO_FRAC": column_inicio_frac, "FIN_FRAC": column_fin_frac}
    )

    list_from_str_to_datetime = [
        column_inicio_frac,
        column_fin_frac,
        column_inicio_bu,
        column_inicio_bu,
        column_time,
    ]

    for features in list_from_str_to_datetime:
        if features in df_eventos.columns:
            df_eventos[features] = pd.to_datetime(df_eventos[features]).to_numpy()

    # Ahora vamos a armar una unica funcion que va a compilar todas las anteriores
    #
    # Objetivos -->
    #   (1)  dado un set de datos de entrada, armar un df listo para aplicarsele el modelo
    #   (2) a este df con las predicciones, calcular los ptos criticos de los eventos interferidos
    # Esta funcion "acota" la lista de valores de presiones a medicionas hechas hasta
    # un limte temporal fijo para todos los tipos de eventos.
    # Por ejemplo, el limite puede ser FIN_FRAC + {timeLimit} min
    # Pero este limite es ajustable como parametro de entrada
    df_referencia_filtrado = function_for_childchild.calculateDFForModel(
        df_eventos,
        column_fin_frac,
        df_presiones,
        column_presion,
        column_id_evento,
        column_time,
        time_limit,
    )

    #   (1) Limpieza de Datos:
    #
    #     1a - Si cada evento ("ID") tiene mas del 50% de los datos Nan, lo quitamos del df
    #    porcentajeFiltrado = 65
    p_logger.info("(1) Limpieza de Datos:")
    p_logger.info(
        ' -  Si cada evento ("ID") tiene mas del %s porciento de los datos Nan, '
        'lo quitamos del df',
        porcentaje_filtrado,
    )

    p_logger.info(
        'Cantidad de eventos ("ID") -- > %s',
        str(len(df_referencia_filtrado[column_id_evento].unique())),
    )

    df_referencia_filtrado_clean = function_for_childchild.clean_data(
        df_referencia_filtrado, column_id_evento, column_presion, porcentaje_filtrado
    )

    p_logger.info(
        'Cantidad de eventos ("ID") luego de la limpieza -- > %s',
        str(len(df_referencia_filtrado_clean[column_id_evento].unique())),
    )

    #   Si fuera nesario eliminar algun evento, este es el momento:
    if list_of_pads_to_delete is not None:
        df_referencia_filtrado_clean = function_for_childchild.dropPADs_PumpDown(
            df_referencia_filtrado_clean, column_pad, list_of_pads_to_delete
        )
        p_logger.info(
            "Luego de quitar lo eventos con Pump Down, tenemos %s eventos",
            len(df_referencia_filtrado_clean.ID.unique()),
        )

    # (1) Interpolamos a {numeroDatos} puntos de presion
    # desde el inicio de la fractura hasta 30 min luego del fin del la fractura
    # A partir de aca, el df generado sólo contiene los puntos de presion por cada evnto
    df_referencia_filtrado_clean_norm = (
        function_for_childchild.ajuste_number_of_data_df_for_model_v2(
            df_referencia_filtrado_clean,
            column_id_evento,
            column_time,
            column_presion,
            numero_datos,
        )
    )

    p_logger.info('Agregamos los "ID" de cada evento ')
    df_referencia_filtrado_clean_norm_with_id = (
        function_for_childchild.ajuste_number_of_data_df_for_model_with_id(
            df_referencia_filtrado_clean_norm,
            df_referencia_filtrado_clean,
            column_id_evento,
        )
    )

    # Como ya vimos en el modelado exploratorio, incluimos las derivadas (diferencias),
    # ya que rescatan los cambios de pendiente de los eventos
    # En el pipeline del "dfDerivadas" ponemos .iloc[1:0], ya que por defecto,
    # luego de calcular las diferencias entre datos contiguos, le primer dato lo daja Nan,
    # asi que de esta forma no lo consideramos
    # (nos vana a quedar un punto menos que los datos de presiones)
    columns_to_include = [
        "1_diff",
        "2_diff",
        "3_diff",
        "4_diff",
        "5_diff",
        "6_diff",
        "7_diff",
        "8_diff",
        "9_diff",
        "10_diff",
        "11_diff",
        "12_diff",
        "13_diff",
        "14_diff",
        "15_diff",
        "16_diff",
        "17_diff",
        "18_diff",
        "19_diff",
        "20_diff",
        "21_diff",
        "22_diff",
        "23_diff",
        "24_diff",
        "25_diff",
        "26_diff",
        "27_diff",
        "28_diff",
        "29_diff",
        "30_diff",
        "31_diff",
        "32_diff",
        "33_diff",
        "34_diff",
    ]

    #  recive eventos por filas ( 1 evento = 1 fila)
    df_derivadas_presiones = function_for_childchild.calculate_derivadas(
        df_referencia_filtrado_clean_norm, columns_to_include
    )

    #    FInalmente concatemanmos POR COLUMNA las tres df
    df_final_for_model = function_for_childchild.concat_dfder_dfpres(
        df_referencia_filtrado_clean_norm,
        df_referencia_filtrado_clean_norm_with_id,
        df_derivadas_presiones,
        column_id_evento,
    )

    p_logger.info("Levantamos el df y el modelo")
    p_logger.info("Ya tenemos listo el df, aplicamos el modelo de clasificacion")

    modelo_limpio = load(folder_for_model + MODEL_LIMPIO)
    modelo_con_anomalias = load(folder_for_model + MODEL_CON_ANOMALIAS)

    #  Separamos los eventos con y sin anomalias en presión(entre otros, Pump down)
    def remove_df_for_pump_downs(df, valor_corte):

        list_df_without_anomalies = []
        list_df_with_anomalies = []
        for idx in df.index:
            if (df.iloc[idx].abs() < valor_corte).all() is True:
                list_df_without_anomalies.append(idx)
            else:
                list_df_with_anomalies.append(idx)

        return list_df_without_anomalies, list_df_with_anomalies

    def get_df_from_index(df, list_index):
        return df.iloc[list_index, :]

    #       Separamos los eventos en "limmpio" y "con anomalias"
    #
    #    Indices d elos enevntos limpios y los eventos con anomalias, respectivamente
    list_index, list_con_anomalias = remove_df_for_pump_downs(
        df_final_for_model[columns_to_include], valor_corte
    )

    #       De aqui, armamos los df con eventos limpios y con anomalias
    df_limpio = get_df_from_index(df_final_for_model, list_index)
    df_con_anomalias = get_df_from_index(df_final_for_model, list_con_anomalias)

    #      Aplicamos el
    #      1- modelo_limpio para los eventos sin anomalias
    #
    #      2- modelo_conAnomalias para los eventos con anomalias

    df_final_for_model_limpio_predictions = function_for_childchild.apply_model(
        df_limpio, modelo_limpio, column_evento, column_tipo_evento
    )

    df_final_for_nodel_con_anomalias_predictions = function_for_childchild.apply_model(
        df_con_anomalias, modelo_con_anomalias, column_evento, column_tipo_evento
    )

    #      Finalmente, cocatenamos ambos df para tener u df unico con las prediciones
    df_final_for_model_predictions = pd.concat(
        [
            df_final_for_model_limpio_predictions,
            df_final_for_nodel_con_anomalias_predictions,
        ],
        axis=1,
    )

    print("Para los evento Interfreridos, calculamos los ptos criticos")

    #    las sigientes variables se genera en la funcion "calculateCritialPoint_Event_Interf"
    inicio_bu_cal = "timeBU_cal"
    presion_max = "timePmax_cal"
    inicio_fo_cal = "timeFO_cal"

    list_for_features = df_final_for_model_predictions.columns[0:35].tolist() + [
        column_id_evento
    ]

    (
        df_final_for_model_predictions_ptos_criticos,
        _,
    ) = function_for_childchild.calculate_critial_point_event_interf(
        df_final_for_model_predictions,
        df_eventos,
        column_id_evento,
        column_evento,
        name_evento,
        inicio_bu_cal,
        presion_max,
        inicio_fo_cal,
        list_for_features,
    )

    time_fo_cal = "timeFO_cal"
    time_pmax = "timePmax_cal"
    time_bu_cal = "timeBU_cal"
    name_fo_10min = "FO_cal+10min"
    pmax_cal = "Pmax_cal"
    bu_cal = "BU_cal"
    fo_cal = "FO_cal"
    amplitud_bu = "AMPLITUD_BU"
    amplitud_fo = "AMPLITUD_FO"
    intensidad_bu = "iBU"
    intensidad_fo = "iFO"

    df_final_for_model_predictions_final = function_for_childchild.calculate_p_fo_10min(
        df_final_for_model_predictions_ptos_criticos,
        df_eventos,
        name_evento,
        column_id_evento,
        column_presion,
        column_time,
        time_fo_cal,
        name_fo_10min,
    )

    p_logger.info("calculo amplituBU----")
    function_for_childchild.calculo_amplitudes(
        df_final_for_model_predictions_final, pmax_cal, bu_cal, amplitud_bu, name_evento
    )

    p_logger.info("calculo intensidadBU----")
    function_for_childchild.calculo_intensidades(
        df_final_for_model_predictions_final,
        time_pmax,
        time_bu_cal,
        amplitud_bu,
        intensidad_bu,
        name_evento,
    )

    p_logger.info("calculo amplituFO----")
    function_for_childchild.calculo_amplitudes(
        df_final_for_model_predictions_final,
        fo_cal,
        name_fo_10min,
        amplitud_fo,
        name_evento,
    )

    p_logger.info("calculo intensidadFO----")
    df_final_for_model_predictions_final_2 = (
        function_for_childchild.calculo_intensidades(
            df_final_for_model_predictions_final,
            time_fo_cal,
            timePresionFinal=None,
            nameColumAmplitud=amplitud_fo,
            nameNewColumn=intensidad_fo,
            evento=name_evento,
        )
    )

    p_logger.info("calculo delay----")
    new_column_delay = "Time_delay[m]"
    column_name_event = "evento"

    #  usamos como inicio de BU el valor calculado por el modelo == "timeBUcal"
    df_final_for_model_predictions_final_2 = function_for_childchild.calculate_t_delay(
        df_eventos,
        df_final_for_model_predictions_final_2,
        column_id_evento,
        column_name_event,
        column_inicio_frac,
        time_bu_cal,
        new_column_delay,
    )

    p_logger.info("Generacion de df final que alimenta la APP----")
    list_features = [
        column_id_evento,
        column_tipo_evento,
        amplitud_bu,
        amplitud_fo,
        intensidad_bu,
        intensidad_fo,
        time_bu_cal,
        time_pmax,
        time_fo_cal,
        new_column_delay,
    ]

    df_final_for_model_predictions_final_2 = function_for_childchild.generate_df_for_app(
        df_eventos.drop_duplicates(subset=[column_id]),
        df_final_for_model_predictions_final_2,
        list_features,
    )

    return df_final_for_model_predictions_final_2


FOLDER = "C:/../MisDocumentos/estimulacion/interferencias/ChildChild_API/data/input/"
FILE_DATOS = "dfBajadaDatosInterferencias_220923.csv"
FILE_PRESIONES_POR_EVENTO = "presines_220923_concatenado.csv"

#  agregamoa un dePreseoins con el agregado de la coluna ID_EVENTO
# filePresionesPorEvento ='dfPresiones_Concatenado_Con_ID_EVENTO.csv'

FOLDER_FOR_MODEL = "C:/../MisDocumentos/estimulacion/interferencias/data/modelos/"
MODEL_LIMPIO = "modelo_class_Int_NoInt_rf_2023_eventos_limpios.joblib"
MODEL_CON_ANOMALIAS = "modelo_class_Int_NoInt_rf_2023_eventos_anomalos.joblib"

#  definicion de variables:
COLUMN_TIME = "Timestamp"
COLUMN_PRESION = "Valor"
COLUMN_ID_EVENTO = "ID_EVENTO"
COLUMN_PAD = "PAD_x"
COLUMN_ID = "ID"
COLUMN_INDEX = "index"
COLUMN_INICIO_FRAC = "INICIO_FRAC"
COLUMN_FIN_FRAC = "FIN_FRAC"
COLUMN_INICIO_BU = "INICIO_BU"
COLUMN_INICIO_FO = "INICIO_FO"
COLUMN_EVENTO = "evento"
COLUMN_TIPO_EVENTO = "tipoEvento"
NAME_EVENTO = "Interferido"


list_of_pads_to_delete = [
    "LACh_PAD-45",
    "LACh_PAD-40",
    "LC_PAD-271",
    "LC_PAD-279",
    "LC_PAD-293",
    "LC_PAD-300",
]


# Tiempo posterior al fin de la fracturas al que vamos a considerar para cada enento
TIME_LIMIT = 10
#   (1) Limpieza de Datos:
#
#     1a - Si cada evento ("ID") tiene mas del 65% de los datos Nan, lo quitamos del df
PORCENTAJE_FILTRADO = 65

# El parametro "numeroDatos" debe ser 35, a menos que querramos cambia toda la estructura del df
NUMERO_DATOS = 35
# El parametro "valorCorte" nos defina al valor del salto entre puntos consecutivos de presion
# (para un dado evento) a partir del cual se considero un evento "limpio" de uno con un pumpdown
# (o una anomalia en presión)
# EN base a esta naturaleza, los eventos seran clasificados por el modelo "limpio"
# o por el modelo que contempla anmlaias

VALOR_CORTE = 500

df_final_for_app = generacion_df_con_clasificacion_de_eventos(
    FOLDER,
    FILE_DATOS,
    FILE_PRESIONES_POR_EVENTO,
    FOLDER_FOR_MODEL,
    MODEL_LIMPIO,
    MODEL_CON_ANOMALIAS,
    COLUMN_EVENTO,
    COLUMN_PAD,
    COLUMN_TIPO_EVENTO,
    COLUMN_TIME,
    COLUMN_PRESION,
    COLUMN_ID_EVENTO,
    COLUMN_ID,
    COLUMN_INDEX,
    COLUMN_INICIO_FRAC,
    COLUMN_FIN_FRAC,
    COLUMN_INICIO_BU,
    COLUMN_INICIO_FO,
    TIME_LIMIT,
    PORCENTAJE_FILTRADO,
    NUMERO_DATOS,
    NAME_EVENTO,
    VALOR_CORTE,
    list_of_pads_to_delete,
)

FOLDER = "C:/../MisDocumentos/estimulacion/interferencias/ChildChild_API/data/input/"

df_final_for_app_v3 = df_final_for_app[df_final_for_app.index != 12615]


df_final_for_app_v3[
    [
        "ID_EVENTO",
        "MODELO_COE",
        "AMPLITUD_BU",
        "AMPLITUD_FO",
        "iBU",
        "iFO",
        "INICIO_BU",
        "INICIO_FO",
        "TIME_P_MAX",
        "Time_delay[m]",
    ]
].to_csv(FOLDER + "RESULTADOS_COE_CHILD-CHILD_25_11_2022_prueba_sinPD.csv", index=False)
