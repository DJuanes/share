import logging as log
import os
import re
from datetime import datetime

import pandas

import functions.functions_blob_storage as blb_strg
import functions.functions_utils as utils

cfgs = {}


def download_data_from_blob_storage():
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[download_data_from_blob_storage] Inicia")

    blb_strg.p_logger = p_logger
    config_strg = utils.leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])

    """Instanciamos los clientes de blobService y de Container"""
    blobService = blb_strg.instanciar_cliente_blobService(
        connection_string=config_strg["blob_connection_string"]
    )
    container = blb_strg.instanciar_cliente_container(
        container_name=config_strg["container_name"]
    )

    files = []
    blob_list = blb_strg.obtener_lista_blobs()
    re_comp = re.compile(config_strg["path_input"])
    df = pandas.DataFrame(
        [
            i.name
            for i in blob_list
            if re_comp.match(i.name) and i.name != "input/.keep"
        ],
        columns=["Name"],
    )
    for index, row in df.iterrows():
        file = row["Name"].split("/")[1]
        p_logger.info(f"""[download_data_from_blob_storage] archivo: {file}.""")
        files.append(file)
        destination_folder = (
            config_strg["path_folder_data"] + config_strg["path_input"] + file
        )
        blob = blb_strg.instanciar_cliente_blob(blob_name=row["Name"])
        blb_strg.download_blob_toFile(file_path=destination_folder)

    return files


def upload_log_to_blob_storage():
    config_strg = utils.leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])

    """Instanciamos los clientes de blobService y de Container"""
    blobService = blb_strg.instanciar_cliente_blobService(
        connection_string=config_strg["blob_connection_string"]
    )
    container = blb_strg.instanciar_cliente_container(
        container_name=config_strg["container_name"]
    )

    path_origen = "../logs/root_logger.log"
    path_destino = "logs/log_" + datetime.now().strftime("%Y%m%d") + ".log"
    blob = blb_strg.instanciar_cliente_blob(blob_name=path_destino)
    blb_strg.upload_blob_fromFile(path_origen)


def upload_data_to_blob_storage(runid=""):
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[upload_data_to_blob_storage] Inicia")

    blb_strg.p_logger = p_logger
    config_strg = utils.leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])

    """Instanciamos los clientes de blobService y de Container"""
    blobService = blb_strg.instanciar_cliente_blobService(
        connection_string=config_strg["blob_connection_string"]
    )
    container = blb_strg.instanciar_cliente_container(
        container_name=config_strg["container_name"]
    )

    file_path = config_strg["path_folder_data"] + config_strg["path_output"] + runid
    lista_output = [
        f for f in os.listdir(file_path) if os.path.isfile(os.path.join(file_path, f))
    ]
    if len(lista_output) > 0:
        for file in lista_output:
            path_origen = (
                config_strg["path_folder_data"]
                + config_strg["path_output"]
                + runid
                + file
            )
            path_destino = config_strg["path_output"] + runid + file
            blob = blb_strg.instanciar_cliente_blob(blob_name=path_destino)
            is_uploaded = blb_strg.upload_blob_fromFile(path_origen)
            if is_uploaded:
                os.remove(path_origen)

    file_path = config_strg["path_folder_data"] + config_strg["path_output"]
    lista_output = [
        f for f in os.listdir(file_path) if os.path.isfile(os.path.join(file_path, f))
    ]
    if len(lista_output) > 0:
        for file in lista_output:
            path_origen = (
                config_strg["path_folder_data"] + config_strg["path_output"] + file
            )
            path_destino = config_strg["path_output"] + file
            blob = blb_strg.instanciar_cliente_blob(blob_name=path_destino)
            is_uploaded = blb_strg.upload_blob_fromFile(path_origen)
            if is_uploaded:
                os.remove(path_origen)

    file_path = config_strg["path_folder_data"] + config_strg["path_processed"]
    lista_ant = [
        f for f in os.listdir(file_path) if os.path.isfile(os.path.join(file_path, f))
    ]
    if len(lista_ant) > 0:
        for file in lista_ant:
            path_origen = (
                config_strg["path_folder_data"] + config_strg["path_processed"] + file
            )
            path_destino = config_strg["path_processed"] + file
            blob = blb_strg.instanciar_cliente_blob(blob_name=path_destino)
            is_uploaded = blb_strg.upload_blob_fromFile(path_origen)
            if is_uploaded:
                os.remove(path_origen)
    clean_data()


def clean_data():
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[clean_data_file] Inicia")

    config_strg = utils.leer_configuracion(cfgs["conf_arc_blob"], cfgs["ambiente"])

    """Instanciamos los clientes de blobService y de Container"""
    blobService = blb_strg.instanciar_cliente_blobService(
        connection_string=config_strg["blob_connection_string"]
    )
    container = blb_strg.instanciar_cliente_container(
        container_name=config_strg["container_name"]
    )

    # input container
    blob_list = blb_strg.obtener_lista_blobs()
    re_comp = re.compile(config_strg["path_input"])
    blob_list_delete = [
        b.name for b in blob_list if re_comp.match(b.name) and b.name != "input/.keep"
    ]
    blb_strg.borrar_blobs(blob_list_delete)

    p_logger.debug("[clean_data_file] Finaliza")
