# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 11:51:30 2022

@author: RY25063
"""
import logging

import joblib
import pandas as pd
import shap

# Log file
logname = "DS_log"
logger = logging.getLogger(logname)


# Predicciones
# if OKOrganico :
def Predict_Organico(
    RUNID,
    ModelDir="model",
    OutputDir="output",
    objetivo="Np_210d_Kbbl_Norm_1000m",
    data=None,
):
    logger.info("COMIENZA proceso predicción ORGANICO...")
    # ORGANICO
    # Carga modelo
    path_modelo = (
        ModelDir
        + "/XGB_Petro1Data_organicomodel_Target_"
        + objetivo
        + "_Final_FULL.dat"
    )
    logger.info("Carga modelo desde " + path_modelo)
    fited_model = joblib.load(path_modelo)
    # Prediccion
    logger.info("Ejecutando predicción...")
    pred_y = fited_model.predict(data)

    # Generacion de SHAP values
    # Creo el explainer. En versiones anteriores se usaba TreeExplainer o algunos otros pero ahora cambió
    logger.info("Creando explainer SHAP...")
    explainer = shap.Explainer(fited_model)
    shap_values = explainer(data)

    # Escribo la salida
    path_salida = OutputDir + "/" + RUNID + "/" + RUNID + "_Organico_Predicted.xlsx"
    logger.info("Escribiendo salida " + path_salida)

    df_result = pd.concat(
        [
            data.reset_index(level=0),
            pd.DataFrame(pred_y, columns=["predicted"]),
            pd.DataFrame(shap_values.base_values, columns=["SHAP_base_value"]),
            pd.DataFrame(
                shap_values.values,
                columns=[
                    "SHAP_" + x
                    for x in shap_values.feature_names
                    if not str(x) == "nan"
                ],
            ),
        ],
        axis=1,
    )
    df_result = df_result.set_index("Pozo")
    df_result.to_excel(path_salida)
    logger.info("FINALIZA proceso predicción ORGANICO...")


# if OKCocina :
def Predict_Cocina(
    RUNID,
    ModelDir="model",
    OutputDir="output",
    objetivo="Np_210d_Kbbl_Norm_1000m",
    data=None,
):
    logger.info("COMIENZA proceso predicción COCINA...")
    # COCINA
    # Carga modelo
    path_modelo = (
        ModelDir + "/XGB_Petro1Data_cocinamodel_Target_" + objetivo + "_Final_FULL.dat"
    )
    logger.info("Carga modelo desde " + path_modelo)
    fited_model = joblib.load(path_modelo)
    # Prediccion
    logger.info("Ejecutando predicción...")
    pred_y = fited_model.predict(data)

    # Generacion de SHAP values
    # Creo el explainer. En versiones anteriores se usaba TreeExplainer o algunos otros pero ahora cambió
    logger.info("Creando explainer SHAP...")
    explainer = shap.Explainer(fited_model)
    shap_values = explainer(data)

    # Escribo la salida
    path_salida = OutputDir + "/" + RUNID + "/" + RUNID + "_Cocina_Predicted.xlsx"
    logger.info("Escribiendo salida " + path_salida)

    df_result = pd.concat(
        [
            data.reset_index(),
            pd.DataFrame(pred_y, columns=["predicted"]),
            pd.DataFrame(shap_values.base_values, columns=["SHAP_base_value"]),
            pd.DataFrame(
                shap_values.values,
                columns=[
                    "SHAP_" + x
                    for x in shap_values.feature_names
                    if not str(x) == "nan"
                ],
            ),
        ],
        axis=1,
    )
    df_result = df_result.set_index("Pozo")
    df_result.to_excel(path_salida)
    logger.info("FINALIZA proceso predicción COCINA...")
