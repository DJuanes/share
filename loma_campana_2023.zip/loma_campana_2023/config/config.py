import logging
import logging.config
import sys
from pathlib import Path

from rich.logging import RichHandler

# Directorios
BASE_DIR = Path(__file__).parent.parent.absolute()
CONFIG_DIR = Path(BASE_DIR, "config")
DATA_DIR = Path(BASE_DIR, "data")
DATA_INPUT_DIR = Path(DATA_DIR, "input")
DATA_OUTPUT_DIR = Path(DATA_DIR, "output")
DATA_PROCESSED_DIR = Path(DATA_DIR, "processed")
MODELS_DIR = Path(BASE_DIR, "models")
STORES_DIR = Path(BASE_DIR, "stores")
LOGS_DIR = Path(BASE_DIR, "logs")

# Stores
MODEL_REGISTRY = Path(STORES_DIR, "model")
BLOB_STORE = Path(STORES_DIR, "blob")

# Crear directorios
DATA_DIR.mkdir(parents=True, exist_ok=True)
DATA_INPUT_DIR.mkdir(parents=True, exist_ok=True)
DATA_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
DATA_PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
MODELS_DIR.mkdir(parents=True, exist_ok=True)
MODEL_REGISTRY.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)
BLOB_STORE.mkdir(parents=True, exist_ok=True)

# Logger
logging_config = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "minimal": {"format": "%(message)s"},
        "detailed": {
            "format": "%(levelname)s %(asctime)s [%(name)s:%(filename)s:%(funcName)s"
            ":%(lineno)d]\n%(message)s\n"
        },
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "stream": sys.stdout,
            "formatter": "minimal",
            "level": logging.DEBUG,
        },
        "info": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": Path(LOGS_DIR, "info.log"),
            "maxBytes": 10485760,  # 1 MB
            "backupCount": 10,
            "formatter": "detailed",
            "level": logging.INFO,
        },
        "error": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": Path(LOGS_DIR, "error.log"),
            "maxBytes": 10485760,  # 1 MB
            "backupCount": 10,
            "formatter": "detailed",
            "level": logging.ERROR,
        },
    },
    "root": {
        "handlers": ["console", "info", "error"],
        "level": logging.INFO,
        "propagate": True,
    },
}
logging.config.dictConfig(logging_config)
logger = logging.getLogger()
logger.handlers[0] = RichHandler(markup=True)

# Activos
STORAGE_ACCOUNT_NAME = "teczdstacoe004"
CONTAINER_NAME = "loma-campana-2023"
STORAGE_ACCOUNT_KEY = "DefaultEndpointsProtocol=https;AccountName=teczdstacoe004;AccountKey=5Gujy0/2hOx4v3AaBpk8N9J1vUah6IAhr/bSH7LEq/JbhDQHGEfMvilnC/dXw3DmilnCSGrd1YKEa2NbQBUMdA==;EndpointSuffix=core.windows.net"

# Configuración del modelo
OBJETIVOS = [
    "ANKERITE",
    "CALCITE",
    "DOLOMITE",
    "ILLITE",
    "MONTMORILLONITE",
    "N-FELDSPAR",
    "K-FELDSPAR",
    "QUARTZ",
    "PYRITE",
    "KEROGEN",
    "CARBONATOS",
    "CUARZOS"
]
MODELOS = {
    "ANKERITE": "ANKERITE_with_IC.joblib",
    "CALCITE": "CALCITE_with_IC.joblib",
    "DOLOMITE": "DOLOMITE_with_IC.joblib",
    "ILLITE": "ILLITE_with_IC.joblib",
    "K-FELDSPAR": "K-FELDSPAR_with_IC.joblib",
    "KEROGEN": "KEROGEN_with_IC.joblib",
    "MONTMORILLONITE": "MONTMORILLONITE_with_IC.joblib",
    "N-FELDSPAR": "N-FELDSPAR_with_IC.joblib",
    "PYRITE": "PYRITE_with_IC.joblib",
    "QUARTZ": "QUARTZ_with_IC.joblib",
    "CARBONATOS": "CARBONATOS_with_IC.joblib",
    "CUARZOS": "CUARZOS_with_IC.joblib"
}


# Errores de ajuste de los modelos usados en la reconciliacion de datos
RMSE = {
    "ANKERITE": 0.0134,
    "CALCITE": 0.0498,
    "DOLOMITE": 0.0306,
    "ILLITE": 0.0227,
    "K-FELDSPAR": 0.0018,
    "KEROGEN": 0.0114,
    "MONTMORILLONITE": 0.0044,
    "N-FELDSPAR": 0.0324,
    "PYRITE": 0.0064,
    "QUARTZ": 0.0376,
    "CARBONATOS": 0.047,
    "CUARZOS": 0.0364
}

# Este es el orden en que debe recibir las variables el modelo
MODEL_FEATURES = {
    "ANKERITE": [
        "RHOZ",
        "AT90",
        "DTCO",
        "NPHI"
    ],
    "CALCITE": [
        "AT90",
        "DTCO",
        "NPHI",
        "RHOZ",
        "RO",
        "VM",
        "LONGITUD",
        "LATITUD"
    ],
    "DOLOMITE": [
        "NPHI",
        "RHOZ",
        "DTCO"
    ],
    "ILLITE": [
        "AT90",
        "DTCO",
        "NPHI",
        "RHOZ",
        "RO",
        "LATITUD"
    ],
    "K-FELDSPAR": [
        "DISTANCIA_BOTTOM",
        "RHOZ",
        "NPHI",
        "AT90"
    ],
    "KEROGEN": [
        "AT90",
        "NPHI",
        "DTCO",
        "RHOZ"
    ],
    "MONTMORILLONITE": [
        "AT90",
        "DTCO",
        "NPHI",
        "RO",
        "RHOZ",
        "LATITUD"
    ],
    "N-FELDSPAR": [
        "AT90",
        "RO",
        "LATITUD",
        "DTCO",
        "NPHI"
    ],
    "PYRITE": [
        "NPHI",
        "RHOZ",
        "DTCO",
        "AT90",
        "DISTANCIA_BOTTOM"
    ],
    "QUARTZ": [
        "AT90",
        "DTCO",
        "RHOZ",
        "NPHI",
        "LATITUD"
    ],
    "CARBONATOS": [
        "DTCO",
        "NPHI",
        "AT90",
        "RHOZ",
        "LATITUD",
        "RO",
        "VM"
    ],
    "CUARZOS": [
        "DTCO",
        "NPHI",
        "AT90",
        "RHOZ",
        "VM",
        "LATITUD"
    ]
}
