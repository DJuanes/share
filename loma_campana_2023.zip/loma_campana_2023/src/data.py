"""utilidades de procesamiento de datos"""

from __future__ import annotations

import os
import urllib.parse as urlparse
from datetime import datetime
from pathlib import Path

from azure.storage.blob import BlobServiceClient


def download_data_from_blob_storage(
    storage_account_key: str, container_name: str, local_fp: Path, blob_name: str = None
) -> list[str]:
    """Descarga los archivos de Azure Blob Storage a una carpeta local

    Args:
        storage_account_key (str): clave de la cuenta de almacenamiento Azure Blob Storage
        container_name (str): nombre del container para los datos del proyecto
        local_fp (Path): carpeta local donde se guardarán los blobs
        blob_name (str, optional): nombre del archivo que queremos bajar.
                                   Si no le pasamos valor, bajará todos los blobs.
                                   Valor default es None.

    Returns:
        list[str]: lista de los archivos que fueron bajados
    """

    blob_service_client = BlobServiceClient.from_connection_string(storage_account_key)
    container_client = blob_service_client.get_container_client(container_name)
    files = []
    if blob_name is None:
        blob_list = container_client.list_blobs()
        for blob in blob_list:
            if blob.size > 0 and blob.name[0:6] == "input/":
                file_name = blob.name.split("/")[1]
                files.append(file_name)
                local_file = local_fp.joinpath(file_name)
                file_content = container_client.get_blob_client(blob).download_blob().readall()
                with open(file=local_file, mode="wb") as file:
                    file.write(file_content)
    else:
        files.append(blob_name)
        local_file = local_fp.joinpath(blob_name)
        file_content = (
            container_client.get_blob_client("input/" + blob_name).download_blob().readall()
        )
        with open(file=local_file, mode="wb") as file:
            file.write(file_content)

    return files


def upload_data_to_blob_storage(
    storage_account_key: str,
    container_name: str,
    output_fp: Path,
    processed_fp: Path,
):
    """Carga los archivos de las carpetas locales (output y processed) en Azure Blob Storage

    Args:
        storage_account_key (str): clave de la cuenta de almacenamiento Azure Blob Storage
        container_name (str): nombre del container para los datos del proyecto
        output_fp (Path): path de la carpeta Output
        processed_fp (Path): path de la carpeta Processed
    """

    blob_service_client = BlobServiceClient.from_connection_string(storage_account_key)
    container_client = blob_service_client.get_container_client(container_name)

    lista_output = [f for f in os.listdir(output_fp) if os.path.isfile(os.path.join(output_fp, f))]
    if len(lista_output) > 0:
        for file in lista_output:
            path_origen = output_fp.joinpath(file)
            path_destino = "output/" + file

            with open(path_origen, "rb") as data:
                container_client.upload_blob(name=path_destino, data=data, overwrite=True)

            # if is_uploaded:
            # os.remove(path_origen)

    lista_ant = [
        f for f in os.listdir(processed_fp) if os.path.isfile(os.path.join(processed_fp, f))
    ]
    if len(lista_ant) > 0:
        for file in lista_ant:
            path_origen = processed_fp.joinpath(file)
            path_destino = "processed/" + file

            with open(path_origen, "rb") as data:
                container_client.upload_blob(name=path_destino, data=data, overwrite=True)

            # if is_uploaded:
            # os.remove(path_origen)


def upload_log_to_blob_storage(storage_account_key: str, container_name: str, log_fp: Path):
    """Carga los archivos de log en Azure Blob Storage

    Args:
        storage_account_key (str): clave de la cuenta de almacenamiento Azure Blob Storage
        container_name (str): nombre del container para los datos del proyecto
    """

    blob_service_client = BlobServiceClient.from_connection_string(storage_account_key)
    container_client = blob_service_client.get_container_client(container_name)

    path_origen = log_fp.joinpath("info.log")
    path_destino = "logs/log_" + datetime.now().strftime("%Y%m%d") + ".log"

    with open(path_origen, "rb") as data:
        container_client.upload_blob(name=path_destino, data=data, overwrite=True)


def clean_data(storage_account_key: str, container_name: str):
    """Elimina los blobs de la carpeta input

    Args:
        storage_account_key (str): clave de la cuenta de almacenamiento Azure Blob Storage
        container_name (str): nombre del container para los datos del proyecto
    """

    blob_service_client = BlobServiceClient.from_connection_string(storage_account_key)
    container_client = blob_service_client.get_container_client(container_name)

    blob_list = container_client.list_blobs()
    blob_list_delete = [
        urlparse.quote(b.name.encode("utf8"))
        for b in blob_list
        if b.size > 0 and b.name[0:6] == "input/"
    ]
    if len(blob_list_delete) > 0:
        container_client.delete_blobs(*blob_list_delete)

def limpia_columna_repetida(df: pd.DataFrame) -> pd.DataFrame:
    """Función que toma un dataframe con perfiles y elimina los gnemonics
        que por estar repetidos en el .las fueron renombrados por lasio a :N
        No aceptamos mnemonics duplicados, nos quedamos con el primero
        La librería lasio agrega :N , siendo N un numero secuencial de comenzando en 1
        Entonces, si en los nombres de columna del archivo leíado hay :N debemos
        quedarnos con la primer columna :1 y dropear las demas.

    Args:
        df pd.DataFrame: dataframe a limpiar

    Returns:
        pd.DataFrame: Datos de los perfiles. Sin columnas duplicadas

        Utilizar esta funcion en read_perfil_las() antes del return y el append
        lasdf = limpia_columna_repetida(lasdf)
    """
    # La expresion regular esperada es :N donde N es un numero
    regexp = re.compile(r":[0-9]")
    for columna in df.columns:
        if regexp.search(columna):
            # Si la columna tiene la expresion regular
            # Separo nombre de numero
            nombre = columna.split(":", 1)[0]
            numero = columna.split(":", 1)[1]
            if numero == "1":
                # si es la numero 1 creo la columna con nombre solo
                df[nombre] = df[columna]
            df.drop(columna, axis=1, inplace=True)
    return df


def read_perfil_las(file: str) -> pd.DataFrame:
    """
    Genera un dataframe a partir de un archivo con formato las

    Args:
        file (str): archivo .las a cargar en un dataframe

    Returns:
        pd.DataFrame: dataframe con el contenido del .las
    """

    df_out = pd.DataFrame()

    # check de existencia de más de 1 columna en el archivo las
    try:
        with open(file, "r", encoding="utf-8") as f:
            arch = f.readlines()
        if len(arch) == 0:
            raise ValueError("El perfil está vacío.")
        columns = [x for x in arch[-2].split(" ") if x not in ["", "\n"]]
        if len(columns) < 2:
            raise ValueError("El perfil tiene menos de 2 columnas.")
    except Exception as e:
        raise ValueError(f"Error durante la lectura del archivo LAS. {e.args[0]}") from e

    try:
        las = lasio.read(file)
        df_out = las.df()
        df_out.reset_index(level=None, drop=False, inplace=True, col_level=0, col_fill="")
        # contenido de WELL en el header del .las
        df_out["WELL"] = las.well.WELL.value
        df_out = limpia_columna_repetida(df_out)

    except lasio.las.exceptions.LASHeaderError as e:
        raise ValueError(
            "Error durante la lectura de los datos del encabezado del archivo LAS."
        ) from e

    except lasio.las.exceptions.LASDataError as e:
        raise ValueError("Error durante la lectura de datos numéricos del archivo LAS.") from e

    except lasio.las.exceptions.LASUnknownUnitError as e:
        raise ValueError("Error de unidad desconocida en archivo LAS.") from e

    return df_out


def write_las_file(archivo: str, data: pd.DataFrame) -> None:
    """
    Guarda un dataframe como archivo .las

    Args:
        file_name (str): nombre del archivo .las
        well (str): nombre del pozo
        data (pd.DataFrame): dataframe con el contenido del archivo las
    """

    # ruta para guardar perfil
    archivo_las = archivo[:-4] + "_COE.las"
    path_salida_las = config.DATA_OUTPUT_DIR.joinpath(archivo, archivo_las)

    # procesamiento de datos
    for feature in data.dtypes[data.dtypes.values != object].index.to_list():
        if feature in ["LATITUD", "LONGITUD"]:
            data.loc[data[feature] > 0, feature] = np.nan
        else:
            data.loc[data[feature] < 0, feature] = np.nan

    # Creo el archivo las
    las = lasio.LASFile()
    las.well.WELL = data["WELL"].unique()[0]
    las.well.DATE = datetime.today().strftime("%d/%m/%Y")
    las.well.NULL = -999.0000
    for mnemonic in data.columns:
        if mnemonic != "WELL":
            las.append_curve(mnemonic, data[mnemonic])
    las.write(str(path_salida_las), version=2, mnemonics_header=True, data_section_header="~ASCII")


def transform_and_clean(df: pd.DataFrame) -> pd.DataFrame:
    """
    Transforma y limpia los datos de entrada a cada modelo

    Args:
        df (pd.DataFrame): dataframe con los datos de entrada

    Returns:
        pd.DataFrame: dataframe con los datos de entrada transformados y limpios
    """

    if "AT90" in df.columns:
        df.loc[df["AT90"] > 700, "AT90"] = 700
    if "RHOZ" in df.columns:
        df.loc[df["RHOZ"] > 3, "RHOZ"] = 3

    for feature in df.columns:
        if feature in ["LATITUD", "LONGITUD"]:
            df.loc[df[feature] > 0, feature] = np.nan
        else:
            df.loc[df[feature] < 0, feature] = np.nan

    return df.dropna()
