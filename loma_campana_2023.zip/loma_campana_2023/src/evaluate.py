"""componentes de evaluación"""
