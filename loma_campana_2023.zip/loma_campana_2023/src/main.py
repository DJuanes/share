"""Workflow principal"""

import json
import tempfile
import warnings
from argparse import Namespace
from pathlib import Path
from typing import Dict, List

import joblib
import optuna
import pandas as pd
import typer

from config import config
from config.config import logger
from src import data, predict, train, utils

warnings.filterwarnings("ignore")

# Inicializar la aplicación CLI de Typer
app = typer.Typer()


@app.command()
def elt_data():
    """Extraer, cargar y transformar nuestros activos de datos."""
    # Extract + Load

    # Transform

    logger.info("Datos guardados!")


@app.command()
def train_model(
    args_fp: str = "config/args.json",
    experiment_name: str = "baselines",
    run_name: str = "sgd",
) -> None:
    """Entrenar un modelo con argumentos dados.
    Args:
        args_fp (str): ubicación de args.
        experiment_name (str): nombre del experimento.
        run_name (str): nombre de la ejecución específica en el experimento.
    """
    # Cargar datos etiquetados

    # Entrenar
    # Logeo de métricas y parámetros
    # Logeo de artifacts

    # Guardar en config


@app.command()
def optimize(
    args_fp: str = "config/args.json", study_name: str = "optimization", num_trials: int = 20
) -> None:
    """Optimizar hiperparámetros.
    Args:
        args_fp (str): ubicación de args.
        study_name (str): nombre del estudio de optimización.
        num_trials (int): número de ensayos a ejecutar en el estudio.
    """
    # Cargar datos etiquetados

    # Optimizar

    # Mejor prueba


def load_artifacts(run_id: str = None) -> Dict:
    """Cargar artefactos para un run_id determinado.
    Args:
        run_id (str): ID de ejecución desde la que cargar artefactos.
    Returns:
        Dict: artefactos de ejecución.
    """
    if not run_id:
        with open(Path(config.CONFIG_DIR, "run_id.txt"), encoding="utf-8") as runid_fp:
            run_id = runid_fp.read()

    # Localizar el directorio específicos de los artefactos
    experiment_id = ""
    artifacts_dir = Path(config.MODEL_REGISTRY, experiment_id, run_id, "artifacts")

    # Cargar objetos desde la ejecución
    args = Namespace(**utils.load_dict(filepath=Path(artifacts_dir, "args.json")))
    model = joblib.load(Path(artifacts_dir, "modelo.pkl"))
    performance = utils.load_dict(filepath=Path(artifacts_dir, "performance.json"))

    return {
        "args": args,
        "model": model,
        "performance": performance,
    }


@app.command()
def predict_model_mineral(archivo: str) -> None:
    """Predecir etiqueta para texto.
    Args:
        text (str): texto de entrada para predecir la etiqueta.
        run_id (str, optional): run id para cargar artefactos para la predicción.
                                Valor default es None.
    """
    if not run_id:
        with open(Path(config.CONFIG_DIR, "run_id.txt"), encoding="utf-8") as runid_fp:
            run_id = runid_fp.read()
    logger.info("run id: %s", run_id)
    artifacts = load_artifacts(run_id=run_id)
    prediction = predict.predict(texts=[text], artifacts=artifacts)
    logger.info(json.dumps(prediction, indent=2))
    return prediction

    """
    Ejecuta la predicción

    Args:
        archivo (str): nombre del archivo
    """

    artifacts = load_artifacts()

    os.makedirs(config.DATA_OUTPUT_DIR.joinpath(archivo), exist_ok=True)

    logger.info("INICIA PROCESO")
    logger.info("Lectura de datos desde el perfil %s", archivo)
    input_fp = config.DATA_INPUT_DIR.joinpath(archivo)
    try:
        data = read_perfil_las(input_fp)
    except ValueError as e:
        logger.critical("No se puede abrir el perfil %s", archivo)
        logger.critical(e)
        logger.info("No se pueden ejecutar los modelos de Mineralogía.")
        logger.info("Moviendo archivo de la carpeta input a processed...")
        output_fp = config.DATA_PROCESSED_DIR.joinpath("/ERROR_LECTURA_" + archivo)
        os.rename(input_fp, output_fp)
        logger.info("FIN PROCESO: %s", archivo)
        return

    # prediccion de los modelos individuales de cada mineral
    # en el dataframe df_predicciones se realizará el merge con las predicciones
    check_sum = 0
    df_predicciones = pd.DataFrame(index=data.index)
    for objetivo in config.OBJETIVOS[:10]:
        # ckeck de que existen las variables para predecir el modelo
        ok_features = set(config.MODEL_FEATURES[objetivo]).issubset(set(data.columns))
        logger.info(
            "¿Están las columnas %s para el modelo %s?: %s",
            config.MODEL_FEATURES[objetivo],
            objetivo,
            str(ok_features),
        )
        # prediccion del modelo
        if ok_features:
            # transformaciones y check de la calidad de los datos
            df_aux = data[config.MODEL_FEATURES[objetivo]].copy()
            df_aux = transform_and_clean(df_aux)
            if df_aux.shape[0] == 0:
                logger.info(
                    "Luego del check de calidad, no quedan registros para predición del modelo."
                )
            else:
                df_aux = pred.predict_model_mineral(model=artifacts[objetivo],
                                                    data=df_aux,
                                                    objetivo=objetivo)
                df_predicciones = df_predicciones.merge(df_aux, how='left',
                                                        left_index=True, right_index=True)
                check_sum += 1

    # reconciliacion de datos: hay que chequear que se hayan ejecutado los 10 modelos
    if check_sum == 0:
        logger.critical("Luego del tratamiento de los datos quedó el DataFrame vacio.")
        logger.info("No se pueden ejecutar los modelos de los minerales.")
        logger.info("Moviendo archivo de la carpeta input a processed.")
        output_fp = config.DATA_PROCESSED_DIR.joinpath("/ERROR_PROCESAMIENTO_" + archivo)
        os.rename(input_fp, output_fp)
        logger.info("FIN PROCESO: %s", archivo)
        return
    if check_sum < 10:
        logger.warning("Solo se ejecutaron %s modelos. Revisar datos de entrada.", check_sum)
        logger.info("No se puede realizar la reconciliciación de datos.")
        logger.info("Escribiendo perfil de salida (LAS) %s", archivo[:-4] + "_COE.las")

        # se reordenan las columnas para que quede primero DEPTH
        data = data[['DEPTH']
                    + [col for col in sorted(data.columns) if col not in ['DEPTH']]]
        data.sort_values(by='DEPTH', inplace=True)

        # se unen las predicciones con los datos originales
        data = data.merge(df_predicciones, how='left',
                          left_index=True, right_index=True)

        write_las_file(archivo=archivo, data=data)
        logger.info("Moviendo archivo de la carpeta input a processed.")
        output_fp = config.DATA_PROCESSED_DIR.joinpath(archivo)
        os.rename(input_fp, output_fp)
        logger.info("FIN PROCESO: %s", archivo)
        finalizar_logger(logger=logger)
        return

    if check_sum == 12:
        logger.info("Se ejecutaron todos los modelos. Inicia reconciliación de datos.")

        # se reordenan las columnas para que quede primero DEPTH
        data = data[['DEPTH']
                    + [col for col in sorted(data.columns) if col not in ['DEPTH']]]
        data.sort_values(by='DEPTH', inplace=True)

        # ejecutar modelos de suma 1 para modelo de 10 minerales
        logger.info("Reconciliación de datos para 10 minerales.")
        df_aux = pred.reconciliacion_datos_minimize(predicciones=df_predicciones.copy(),
                                                    objetivos=config.MODELO_10,
                                                    rmse=config.RMSE)
        data = data.merge(df_aux, how='left',
                          left_index=True, right_index=True)

        # ejecutar modelos de suma 1 para modelo de 6 minerales
        logger.info("Reconciliación de datos para 6 minerales agrupados.")
        df_aux = pred.reconciliacion_datos_minimize(predicciones=df_predicciones.copy(),
                                                    objetivos=config.MODELO_6,
                                                    rmse=config.RMSE)
        data = data.merge(df_aux, how='left',
                          left_index=True, right_index=True)

        # guardar datos de los minerales reconciliados
        logger.info("Escribiendo perfil de salida (LAS) %s", archivo[:-4] + "_COE.las")
        write_las_file(archivo=archivo, data=data)
        logger.info("Moviendo archivo de la carpeta input a processed.")
        output_fp = config.DATA_PROCESSED_DIR.joinpath(archivo)
        os.rename(input_fp, output_fp)
        logger.info("FIN PROCESO: %s", archivo)
        finalizar_logger(logger=logger)
        return


if __name__ == "__main__":
    app()  # pragma: aplicación en vivo
