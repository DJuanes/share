"""utilidades de inferencia"""

import pandas as pd

import model_with_ic


def predict(model: model_with_ic, data: pd.DataFrame) -> pd.DataFrame:
    """
    Predecir el perfil sinteticos con el intervalo de confianza para un mineral

    Args:
        model (model_with_ic): clase que tiene el modelo entrenado con los intervalos de confianza.
        data (pd.DataFrame): dataframe con las columnas de features para realizar predicción.
        objetivo (str): nombre del mineral a predecir.
    """
    df_result = model.predict(data)
    df_result[df_result < 0] = 0

    return df_result
