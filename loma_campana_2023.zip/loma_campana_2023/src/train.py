"""utilidades de entrenamiento"""
from argparse import Namespace
from typing import Dict

import optuna
import pandas as pd

from config.config import logger
from src import data, evaluate, predict, utils


def train(args: Namespace, df: pd.DataFrame, trial: optuna.trial._trial.Trial = None) -> Dict:
    """Entrenar modelo en datos.
    Args:
        args (Namespace): argumentos a utilizar para el entrenamiento.
        df (pd.DataFrame): datos para entrenamiento.
        trial (optuna.trial._trial.Trial, optional): prueba de optimización.
                                                     Valor default es None.
    Raises:
        optuna.TrialPruned: detención anticipada de la prueba si su rendimiento es deficiente.
    Returns:
        Dict: artefactos de la ejecución.
    """


def objective(args: Namespace, df: pd.DataFrame, trial: optuna.trial._trial.Trial) -> float:
    """Función objetivo para pruebas de optimización.
    Args:
        args (Namespace): argumentos a utilizar para el entrenamiento.
        df (pd.DataFrame): datos para entrenamiento.
        trial (optuna.trial._trial.Trial): prueba de optimización.
    Returns:
        float: valor de la métrica que se utilizará para la optimización.
    """
