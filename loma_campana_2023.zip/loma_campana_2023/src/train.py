"""utilidades de entrenamiento"""
