"""utilidades de procesamiento de datos - test"""
