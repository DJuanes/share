"""utilidades de inferencia - test"""
