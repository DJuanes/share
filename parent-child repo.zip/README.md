# Parent-Child

Automatizacion deteccion interferencias Padre - Hijo (YCOE- 23802)

## Equipo

* Cientifico de datos: Lucas Baez
* Ingeniero de ml: Diego Juanes / Cristian Perez Andaur
* Líder técnico: Diego Gallart
* Domain owner: Pilar Alencastre
* Scrum master: Maria Florencia Fernandez
* Key user: Mariana Mamani / Miguel Ortiz
* Sponsor: MartÃ­n Foster

## Virtual environment

```bash
python3 -m venv venv
source ./venv/scripts/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -e ".[dev]"
pre-commit install
pre-commit autoupdate
```

## Directorio

```bash
src/
├── data.py                 - utilidades de procesamiento de datos
├── main.py                 - workflow principal (entrenamiento, optimización, procesamiento, predicción)
├── predict.py              - utilidades de inferencia
├── shared/
    ├── blob_storage.py     - modulo para mamejo de blobs
    ├── pi.py               - modulo para obtención de datos de pi
    └── utils.py            - utilidades suplementarias
```

## Automatización

```bash
make style                      # ejecuta el formato de estilo
make test                       # ejecuta pruebas sobre código, datos y modelos
```

## Documentación (Código)

```bash
python -m mkdocs serve          # disponibiliza la documentación localmente
python -m mkdocs build          # genera el site con la documentación
```

## Documentación (Datos)

```bash
great_expectations docs build   # disponibiliza la documentación localmente
```

## Workflow

```bash
python src/main.py elt-data "20230913092743_diego.juanes@ypf.com_Interpretar.xlsx"
python src/main.py predict-model "20230913092743_diego.juanes@ypf.com_Interpretar.xlsx"
```

## API

```bash
uvicorn app.api:app --host 0.0.0.0 --port 8000 --reload --reload-dir src --reload-dir app  # dev
gunicorn -c app/gunicorn.py -k uvicorn.workers.UvicornWorker app.api:app  # prod
```
