import os
from datetime import datetime
from functools import wraps
from http import HTTPStatus
from typing import Dict

import pandas as pd
from dotenv import load_dotenv
from fastapi import FastAPI, Request, BackgroundTasks
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.instrumentation.requests import RequestsInstrumentor
from opentelemetry.sdk.resources import SERVICE_NAME, Resource
from azure.monitor.opentelemetry.exporter import AzureMonitorTraceExporter

from app.schemas import Archivo
from config import config
from config.config import logger
from src import main, predict

load_dotenv()

# Definir aplicación
app = FastAPI(
    title="Parent-Child",
    description="Automatizacion deteccion interferencias Padre - Hijo (YCOE- 23802)",
    version="0.1",
)
app.mount("/static", StaticFiles(directory="./app/static"), name="static")

os.environ.get("APPLICATIONINSIGHTS_CONNECTION_STRING")
trace_exporter = AzureMonitorTraceExporter()

trace.set_tracer_provider(
    TracerProvider(
        resource=Resource.create({SERVICE_NAME: "parent-child"})
    )
)
tracer = trace.get_tracer(__name__)
trace.get_tracer_provider().add_span_processor(
    BatchSpanProcessor(trace_exporter)
)

FastAPIInstrumentor.instrument_app(app)
RequestsInstrumentor().instrument()


@app.get('/favicon.ico', include_in_schema=False)
async def favicon():
    file_path = os.path.join(app.root_path, "./app/static/favicon.ico")
    return FileResponse(path=file_path, headers={"Content-Disposition": "attachment; filename=favicon.ico"})


@app.on_event("startup")
@tracer.start_as_current_span("startup")
def load_artifacts():
    global artifacts
    artifacts = main.load_artifacts()
    logger.info("Listo para la inferencia!")


def construct_response(f):
    """Construir una respuesta JSON para un endpoint."""

    @wraps(f)
    def wrap(request: Request, *args, **kwargs) -> Dict:
        results = f(request, *args, **kwargs)
        response = {
            "message": results["message"],
            "method": request.method,
            "status-code": results["status-code"],
            "timestamp": datetime.now().isoformat(),
            "url": request.url._url,
        }
        if "data" in results:
            response["data"] = results["data"]
        return response

    return wrap


@app.get("/", tags=["General"])
@construct_response
@tracer.start_as_current_span("home")
def _index(request: Request) -> Dict:
    """Health check."""
    response = {
        "message": HTTPStatus.OK.phrase,
        "status-code": HTTPStatus.OK,
        "data": {},
    }
    return response


@app.get("/performance", tags=["Performance"])
@construct_response
@tracer.start_as_current_span("performance")
def _performance(request: Request, filter: str = None) -> Dict:
    """Obtener las métricas de performance."""
    performance = artifacts["performance"]
    data = {"performance": performance.get(filter, performance)}
    response = {
        "message": HTTPStatus.OK.phrase,
        "status-code": HTTPStatus.OK,
        "data": data,
    }
    return response


@app.get("/args/{arg}", tags=["Arguments"])
@construct_response
def _arg(request: Request, arg: str) -> Dict:
    """Obtener el valor de un parámetro específico utilizado para la ejecución."""
    response = {
        "message": HTTPStatus.OK.phrase,
        "status-code": HTTPStatus.OK,
        "data": {
            arg: vars(artifacts["args"]).get(arg, ""),
        },
    }
    return response


@app.get("/args", tags=["Arguments"])
@construct_response
def _args(request: Request) -> Dict:
    """Obtener todos los argumentos utilizados para la ejecución."""
    response = {
        "message": HTTPStatus.OK.phrase,
        "status-code": HTTPStatus.OK,
        "data": {
            "args": vars(artifacts["args"]),
        },
    }
    return response


@app.post("/predict", tags=["Prediction"])
@construct_response
@tracer.start_as_current_span("predict")
def _predict(request: Request, archivo: Archivo) -> Dict:
    """Interpretacion de las novedades"""
    try:
        cant_registros = main.predict_model(archivo=archivo.archivo)

        response = {
            "message": HTTPStatus.OK.phrase,
            "status-code": HTTPStatus.OK,
            "data": {"Cantidad de registros interpretados": str(cant_registros)},
        }
    except Exception as e:
        response = {
            "message": HTTPStatus.OK.phrase,
            "status-code": HTTPStatus.OK,
            "data": {
                "error": e.value,
            },
        }

    return response


@construct_response
@tracer.start_as_current_span("etl")
def elt_data(request: Request, archivo: Archivo) -> Dict:
    """Procesamiento de datos"""
    try:
        cant_archivos_pi, cant_registros_tow, cant_registros_se = main.elt_data(archivo.archivo)

        response = {
            "message": HTTPStatus.OK.phrase,
            "status-code": HTTPStatus.OK,
            "data": {
                "Cantidad archivos de presiones": cant_archivos_pi,
                "Cantidad de registros de estados": cant_registros_tow,
                "Cantidad de registros de sistemas de extracción": cant_registros_se,
            },
        }
    except (main.DatosInvalidos, ValueError) as e:
        response = {
            "message": HTTPStatus.OK.phrase,
            "status-code": HTTPStatus.OK,
            "data": {
                "error": e.value,
            },
        }

    return response


@app.post("/etl", tags=["Data"])
async def _etl(request: Request, background_tasks: BackgroundTasks, archivo: Archivo) -> Dict:
    """Procesamiento ETL"""
    background_tasks.add_task(elt_data, request, archivo)
    return {"message": "Extrayendo datos de PI y de TOW (Teradata)"}
