from pydantic import BaseModel


class Archivo(BaseModel):
    archivo: str

    class Config:
        schema_extra = {
            "example": {
                "archivo": "20230830141714_diego.juanes@ypf.com_Interpretar.xlsx",
            }
        }
