"""configuraciones del proyecto"""

import logging
import logging.config
import sys
import warnings
from pathlib import Path

from rich.logging import RichHandler

warnings.filterwarnings("ignore")


# Directorios
BASE_DIR = Path(__file__).parent.parent.absolute()
CONFIG_DIR = Path(BASE_DIR, "config")
DATA_DIR = Path(BASE_DIR, "data")
DATA_INPUT_DIR = Path(DATA_DIR, "input")
DATA_OUTPUT_DIR = Path(DATA_DIR, "output")
DATA_PROCESSED_DIR = Path(DATA_DIR, "processed")
MODELS_DIR = Path(BASE_DIR, "models")
STORES_DIR = Path(BASE_DIR, "stores")
LOGS_DIR = Path(BASE_DIR, "logs")

# Stores
MODEL_REGISTRY = Path(STORES_DIR, "model")
BLOB_STORE = Path(STORES_DIR, "blob")

# Crear directorios
DATA_DIR.mkdir(parents=True, exist_ok=True)
DATA_INPUT_DIR.mkdir(parents=True, exist_ok=True)
DATA_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
DATA_PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
MODELS_DIR.mkdir(parents=True, exist_ok=True)
MODEL_REGISTRY.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)
BLOB_STORE.mkdir(parents=True, exist_ok=True)

# Logger
logging_config = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "minimal": {"format": "%(message)s"},
        "detailed": {
            "format": "%(levelname)s %(asctime)s [%(name)s:%(filename)s:%(funcName)s"
            ":%(lineno)d]\n%(message)s\n"
        },
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "stream": sys.stdout,
            "formatter": "minimal",
            "level": logging.DEBUG,
        },
        "info": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": Path(LOGS_DIR, "info.log"),
            "maxBytes": 5242880,  # 5 MB
            "backupCount": 10,
            "formatter": "detailed",
            "level": logging.INFO,
        },
        "error": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": Path(LOGS_DIR, "error.log"),
            "maxBytes": 5242880,  # 5 MB
            "backupCount": 10,
            "formatter": "detailed",
            "level": logging.ERROR,
        },
    },
    "root": {
        "handlers": ["console", "info", "error"],
        "level": logging.INFO,
        "propagate": True,
    },
}
logging.config.dictConfig(logging_config)
logger = logging.getLogger()
logger.handlers[0] = RichHandler(markup=True)

# Activos
STORAGE_ACCOUNT_NAME = "teczdstacoe004"
CONTAINER_NAME = "parent-child"
STORAGE_ACCOUNT_KEY = "DefaultEndpointsProtocol=https;AccountName=teczdstacoe004;AccountKey=5Gujy0/2hOx4v3AaBpk8N9J1vUah6IAhr/bSH7LEq/JbhDQHGEfMvilnC/dXw3DmilnCSGrd1YKEa2NbQBUMdA==;EndpointSuffix=core.windows.net"

# Configuración del modelo
OBJETIVO = "objetivo"

MODELOS = {
    "model1": "model1_" + OBJETIVO + "_final.dat",
    "model2": "model2_" + OBJETIVO + "_final.dat",
}

# Features usadas por el modelo
MODEL_FEATURES = {
    "Default": [
        "PAD_HIJO",
        "PADRE",
        "ID_EVENTO"
    ],
}
