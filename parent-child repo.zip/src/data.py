"""utilidades de procesamiento de datos"""

import datetime
import json
import os
import time

import cmlapi
import pandas as pd
from dotenv import load_dotenv
from great_expectations.checkpoint.types.checkpoint_result import CheckpointResult
from great_expectations.data_context import DataContext

from config import config
from config.config import logger
from src.shared import blob_storage as blob
from src.shared import pi


def validate_input() -> bool:
    """Valida los datos de entrada ejecutando la suite de GE

    Returns:
        bool: Si los datos son validos o no
    """

    data_context: DataContext = DataContext(context_root_dir="./tests/great_expectations")

    result: CheckpointResult = data_context.run_checkpoint(
        checkpoint_name="novedades_gidi",
        batch_request=None,
        run_name=None,
    )

    return result.success


def get_novedades(archivo: str, runid: str) -> int:
    """Descarga de los archivos de novedades del blob storage

        Filtra el archivo input con los parametros dados por el usuario.
    Args:
        archivo (str): Nombre del archivo de novedades
    """

    blob.download_data_from_blob_storage(
        storage_account_key=config.STORAGE_ACCOUNT_KEY,
        container_name=config.CONTAINER_NAME,
        local_fp=config.DATA_INPUT_DIR,
        blob_name=archivo,
    )

    cant_registros = 0
    if archivo:
        df = pd.read_excel(config.DATA_INPUT_DIR.joinpath(archivo))

        filtro_uno = (df["D2D"] < 1200) & (df["DZ"] > -60) & (df["DZ"] < 100)
        filtro_dos = (df["D2D"] >= 1200) & (df["D2D"] < 1600) & (df["DZ"] > -20) & (df["DZ"] < 60)

        df_filtrado = df[~df["INTERPRETADO"]]
        df_filtrado = df_filtrado[filtro_uno | filtro_dos]
        cant_registros = df_filtrado["PADRE"].count()

        df_filtrado.to_csv(
            config.DATA_INPUT_DIR.joinpath(runid).joinpath("Interpretar.csv"), index=False
        )

        upload_data(runid=runid)

    return cant_registros


def load_pi_webapi() -> pi.PiWebapi:
    """Inicializa pi webapi

    Returns:
        pi.PiWebapi: Instancia de las clase PiWebapi
    """
    load_dotenv()
    return pi.PiWebapi(
        "https://swpnqntaspi23.grupo.ypf.com/piwebapi",
        "swpnqntaspi11",
        "basic",
        False,
        str(os.environ.get("PI_WEB_API_USER")),
        str(os.environ.get("PI_WEB_API_PASSWORD")),
    )


def get_tag(se_cod: str, pozo: str) -> str:
    """Genera el tag para un pozo teniendo en cuenta el sistema de extracción

    Args:
        se_cod (str): Código del sistema de extracción
        pozo (str): Pozo

    Returns:
        str: Tag correspondiente al pozo para el SE
    """
    tags = {
        "FA": "_PT:CABEZA.PV",
        "FC": "_PT:CABEZA.PV",
        "FG": "_PT:CABEZA.PV",
        "FL": "_PT:CABEZA.PV",
        "GL": "(GL)_PT:CABEZA.PV",
        "HY": "(BH)_PT:CABEZA.PV",
        "IN": "(INY)_PT:CABEZA.PV",
        "IS": "(INY)_PT:CABEZA.PV",
        "IT": "(INY)_PT:CABEZA.PV",
        "PC": "(PCP)_PT:CABEZA.PV",
        "PA": "(PL)_PT:CABEZA.PV",
        "PL": "(PL)_PT:CABEZA.PV",
        "PU": "(PL)_PT:CABEZA.PV",
        "SB": "(BES)_PT:CABEZA.PV",
        "SR": "(RPC)_PT:CABEZA.PV",
    }
    return pozo + tags.get(se_cod, "_PT:CABEZA.PV")


def process_pressure_data(df_data: pd.DataFrame, pad: str, pozo: str, runid: str) -> None:
    """Procesa los datos de presiones y genera un archivo de salida

    Args:
        df_data (pd.DataFrame): Dataframe con los datos de presiones
        pad (str): Pad
        pozo (str): Pozo
        runid (str): Identificador de la ejecución
    """
    df_data.rename(
        columns={
            "Value.Timestamp": "Timestamp",
            "Value.Value": "Valor",
            "Value.Errors": "Error",
        },
        inplace=True,
    )
    df_data["Timestamp"] = pd.to_datetime(df_data["Timestamp"]).dt.strftime("%Y-%m-%d %H:%M:%S")
    df_data["Timestamp"] = pd.to_datetime(df_data["Timestamp"]).to_numpy()
    df_data["Timestamp"] = df_data["Timestamp"] - datetime.timedelta(hours=3)
    df_data.insert(0, "Pad", pad)
    df_data.insert(1, "Pozo", pozo)

    archivo_salida = f"{pad}{pozo}.csv"
    df_data.to_csv(
        config.DATA_INPUT_DIR.joinpath(runid).joinpath(archivo_salida), mode="a", index=False
    )
    logger.info("Archivo de presiones generado: %s", archivo_salida)


def get_presiones(df_novedades: pd.DataFrame, runid: str) -> int:
    """Obtención de las presiones desde PI.
    Para cada PAD_HIJO + PADRE genera un csv con las presiones summary de PI.
    El rango de presiones abarca 7 días antes del primer inicio de fractura
    hasta 7 días despues del último fin de fractura.
    Las presiones son un promedio cada 5 minutos.

    Args:
        df_novedades (pd.DataFrame): Dataframe con las novedades
        runid (str): Carpeta donde se van a guardar los archivos

    Raises:
        ValueError: Si PI devuelve un código distinto de 200

    Returns:
        int: Cantidad de archivos generados
    """

    pi_webapi = load_pi_webapi()
    security_auth = pi_webapi.call_security_method()

    registros_erroneos = []
    for row in df_novedades.itertuples(index=False):
        pad, pozo, desde, hasta, se_cod = (
            row.PAD,
            row.POZO,
            row.INICIO,
            row.FIN,
            row.SE_COD,
        )
        tag = get_tag(se_cod, pozo)
        webid = pi_webapi.generate_webid_from_path(rf"{pi_webapi.path}\{tag}")

        presiones = pi_webapi.get_summary_data(
            security_auth=security_auth,
            webid=webid,
            start_time=desde,
            end_time=hasta,
            summary_type="Average",
            duration="300s",
        )

        if presiones[0] != 200:
            logger.error(
                "Ocurrió un error al consultar los datos de presiones en PI. "
                "Tag: %s. Code error: %s.",
                tag,
                presiones[0],
            )
            registros_erroneos.append({"Pad": pad, "Pozo": pozo, "Tag": tag, "Error": presiones[0]})
        else:
            process_pressure_data(
                pd.json_normalize(list(presiones[1].values())[0]), pad, pozo, runid
            )

    if registros_erroneos:
        pd.DataFrame(registros_erroneos).to_csv(
            config.DATA_INPUT_DIR.joinpath(runid).joinpath("registro_errores.csv"), index=False
        )

    return len(df_novedades.index)


def run_job_cdp(runid: str, job_id: str) -> str:
    """Ejecutar un job en CDP

    Args:
        runid (str): Carpeta donde se van a guardar los archivos
        job_id (str): Identificador del job

    Returns:
        str: Resultado de la ejecución del job
        ("ENGINE_SUCCEEDED" o "ENGINE_FAILED" o "ENGINE_STOPPED")
    """

    load_dotenv()

    api_client = cmlapi.default_client(
        url=os.environ.get("CML_API_URL"), cml_api_key=os.environ.get("CML_API_KEY")
    )
    projects = api_client.list_projects(search_filter=json.dumps({"name": "parent-child"}))
    project_id = projects.projects[0].id
    print("project_id: " + project_id)
    jobrun_body = cmlapi.CreateJobRunRequest(project_id, job_id, arguments="-runid " + runid)
    thread = api_client.create_job_run(jobrun_body, project_id, job_id, async_req=True)
    job_run = thread.get()

    status = ""
    while status not in ("ENGINE_SUCCEEDED", "ENGINE_FAILED", "ENGINE_STOPPED"):
        api_response = api_client.get_job_run(project_id, job_id, job_run.id)
        status = api_response.status
        print(status)
        time.sleep(10)

    return status


def run_job_estados(runid: str) -> int:
    """Obtención de los datos de horas de paro.
    Se ejecuta un job en CDP, ya que los datos están en Teradata

    Args:
        runid (str): Carpeta donde se van a guardar los archivos

    Raises:
        ValueError: Si hubo un error en el job de CDP

    Returns:
        int: Cantidad de registros generados
    """

    status = run_job_cdp(runid=runid, job_id="dfbg-u2s4-qeel-h1i1")

    estados = runid + "/Estados.csv"
    if status == "ENGINE_SUCCEEDED":
        blob.download_data_from_blob_storage(
            storage_account_key=config.STORAGE_ACCOUNT_KEY,
            container_name=config.CONTAINER_NAME,
            local_fp=config.DATA_INPUT_DIR,
            blob_name=estados,
        )
    else:
        raise ValueError("Ocurrió un error al ejecutar job CDP (datos TOW/Teradata).")

    df_estados = pd.read_csv(config.DATA_INPUT_DIR.joinpath(estados))

    return df_estados["PADRE"].count()


def run_job_se(runid: str) -> int:
    """Obtención de los datos de Sistemas de Extracción.
    Se ejecuta un job en CDP, ya que los datos están en Teradata

    Args:
        runid (str): Carpeta donde se van a guardar los archivos

    Raises:
        ValueError: Si hubo un error en el job de CDP

    Returns:
        int: Cantidad de registros generados
    """

    status = run_job_cdp(runid=runid, job_id="3j1o-h9yc-6rwe-8cvw")

    novedades = runid + "/Novedades_SE.csv"
    if status == "ENGINE_SUCCEEDED":
        blob.download_data_from_blob_storage(
            storage_account_key=config.STORAGE_ACCOUNT_KEY,
            container_name=config.CONTAINER_NAME,
            local_fp=config.DATA_INPUT_DIR,
            blob_name=novedades,
        )
    else:
        raise ValueError("Ocurrió un error al ejecutar job CDP (datos TOW/Teradata).")

    df_novedades = pd.read_csv(config.DATA_INPUT_DIR.joinpath(novedades))

    return df_novedades["POZO"].count()


def upload_log() -> None:
    """Copiar el archivo de logs al correspondiente contenedor de blobs"""
    blob.upload_log_to_blob_storage(
        storage_account_key=config.STORAGE_ACCOUNT_KEY,
        container_name=config.CONTAINER_NAME,
        log_fp=config.LOGS_DIR,
    )


def upload_data(runid: str = "") -> None:
    """Copiar los archivos generados al blob storage

    Args:
        runid (str): Carpeta donde se encuentran los archivos
    """
    input_path = None
    if runid != "":
        input_path = config.DATA_INPUT_DIR.joinpath(runid)

    blob.upload_data_to_blob_storage(
        runid=runid,
        storage_account_key=config.STORAGE_ACCOUNT_KEY,
        container_name=config.CONTAINER_NAME,
        output_fp=config.DATA_OUTPUT_DIR,
        processed_fp=config.DATA_PROCESSED_DIR,
        input_fp=input_path,
    )
