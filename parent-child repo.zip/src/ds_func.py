"""funciones de procesamiento"""

import logging

import pandas as pd

# Log file
logger = logging.getLogger(name="DS_log")


def procesa_pad(data, pad_hijo):
    """Procesa un PAD con sus diferentes PADRES potencialmente interferidos

    Args:
        data: recibe en un dataframe los datos relacionados al PAD
        PAD_HIJO: string con el nombre del PAD hijo a procesar
    Returns:
        Devuelve un dataframe con los datos de interpretación del PAD
    """
    df_interpreta_pad = pd.DataFrame()
    for padre in data.PADRE.unique():
        logger.info("Proceando PAD-PADRE : " + pad_hijo + "-" + padre)

        # Agrega la interpretación del PADRE al df de salida
        df_interpreta_pad = pd.concat(
            [df_interpreta_pad, procesa_padre(data, pad_hijo, padre)], ignore_index=True
        )

    # Evalua Necesidad de Iterpretacion con GUIA
    # procesa_padre_con_guia()
    # se reemplaza la interpretacion original por la con GUIA

    return df_interpreta_pad


def procesa_padre(data, pad_hijo, padre):
    """Procesa un PADRE para un PAD_HIJO

    Args:
        data: recibe en un dataframe los datos relacionados al PAD_HIJO/PADRE
        PAD_HIJO: string con el nombre del PAD hijo a procesar
        PADRE: string con el nombre del PADRE
    Returns:
        Devuelve un dataframe con los datos de interpretación del PADRE
    """

    # INTEGRA DATOS

    # DETECTA ANOMALIAS

    # LIMPIA ANOMALIAS

    # INTERPRETA

    # CALCULOS DELTA & INTENSIDAD

    # Provisorio
    df_interpreta_padre = data[data.PADRE == padre]

    return df_interpreta_padre


def procesa_padre_con_guia(data, pad_hijo, padre, padre_guia):
    """Procesa un PADRE para un PAD_HIJO

    Args:
        data: recibe en un dataframe los datos relacionados al PAD_HIJO/PADRE
        PAD_HIJO: string con el nombre del PAD hijo a procesar
        PADRE: string con el nombre del PADRE
    Returns:
        Devuelve un dataframe con los datos de interpretación del PADRE
    """

    # IDENTIFICA GUIA

    # ASIGNA VENTANAS SEGUN GUIA

    # CALCULOS DELTA & INTENSIDAD

    # Provisorio
    df_interpreta_padre_con_guia = data

    return df_interpreta_padre_con_guia
