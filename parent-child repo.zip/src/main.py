"""Workflow principal"""

import os
import sys
import warnings
from argparse import Namespace
from pathlib import Path
from typing import Dict, Tuple

import joblib
import pandas as pd
import typer
from opentelemetry import trace

from config import config
from config.config import logger
from src import data, predict
from src.shared import utils

warnings.filterwarnings("ignore")

# Inicializar la aplicación CLI de Typer
app = typer.Typer()

tracer = trace.get_tracer(__name__)


class DatosInvalidos(Exception):
    """Clase para lanzar excepción por datos inválidos

    Args:
        Exception (_type_): nombre del archivo
    """

    def __init__(self, value):
        self.value = value

    def __str__(self):
        return f"Hay un error en los datos: {self.value}"


@app.command()
def elt_data(archivo: str) -> Tuple[int, int, int]:
    """Extraer, cargar y transformar nuestros activos de datos.

    Args:
        archivo (str): Nombre del archivo de novedades

    Raises:
        DatosInvalidos: Si el archivo input no pasa las validaciones se lanza esta excepción

    Returns:
        tuple[int, int, int]: Cantidad de archivos de presiones generados (PI),
            cantidad de registros de horas de paro (Teradata)
            y cantidad de sistemas de extraccion (Teradata)
    """

    # Extract + Load
    logger.info("elt_data")

    # El siguiente código funciona localmente, pero no en la web app.
    # Hasta no hallar el motivo se deshabilita
    # datos_validos = data.validate_input()
    # if datos_validos is not True:
    #     raise DatosInvalidos("NOVEDADES_GIDI.csv")

    logger.info("Archivo de novedades: %s", archivo)
    archivo_split = archivo.split("_")
    runid = archivo_split[0] + "_" + archivo_split[1]
    os.makedirs(name=config.DATA_INPUT_DIR.joinpath(runid), exist_ok=True)
    data.get_novedades(archivo=archivo, runid=runid)

    # Defino variable con nombre del archivo filtrado
    cant_archivos_pi = 0
    cant_sistemas_extracion = 0
    cant_registros_tow = 0
    try:
        with tracer.start_as_current_span(name="etl.paro"):
            cant_registros_tow = data.run_job_estados(runid=runid)
            logger.info(
                "Carga horas de paro desde TOW (Teradata). Cantidad de registros: %s",
                cant_registros_tow,
            )

        with tracer.start_as_current_span(name="etl.se"):
            cant_sistemas_extracion = data.run_job_se(runid=runid)
            logger.info(
                "Carga Sistemas de Extraccion. Cantidad de registros: %s", cant_sistemas_extracion
            )

        with tracer.start_as_current_span(name="etl.presiones"):
            df_novedades = pd.read_csv(
                config.DATA_INPUT_DIR.joinpath(runid).joinpath("Novedades_SE.csv")
            )
            cant_archivos_pi = data.get_presiones(df_novedades=df_novedades, runid=runid)
            logger.info(
                "Carga presiones desde PI. Cantidad de archivos generados: %s", cant_archivos_pi
            )

        logger.info("Genero txt para disparar el predict")
        with open(
            config.DATA_INPUT_DIR.joinpath(runid).joinpath("fin.txt"),
            "w",
            encoding="utf-8",
        ) as _:
            pass

    except ValueError as e:
        logger.error(e)
        data.upload_log()
        sys.exit(1)

    data.upload_log()
    data.upload_data(runid=runid)

    return cant_archivos_pi, cant_registros_tow, cant_sistemas_extracion
    # Transform


def load_artifacts() -> Dict:
    """
    Cargar artefactos para la predicción.

    Returns:
        Dict: artefactos de ejecución.
    """
    # Cargar objetos desde la ejecución
    config_dir = config.CONFIG_DIR
    artifacts_dir = config.MODELS_DIR
    args = Namespace(**utils.load_dict(filepath=str(Path(config_dir, "args.json"))))
    models = {}
    for item in config.MODELOS.items():
        modelo_clave = item[0]
        modelo = item[1]
        model_fp = artifacts_dir.joinpath(modelo)
        models[modelo_clave] = joblib.load(str(model_fp))
        logger.info("Carga modelo %s", str(model_fp))

    performance = utils.load_dict(filepath=str(Path(config_dir, "performance.json")))

    return {
        "args": args,
        "model": models,
        "performance": performance,
    }


@app.command()
def predict_model(archivo: str) -> int:
    """Ejecuta el procesamiento de las novedades a interpretar

    Args:
        archivo (str): Nombre del archivo de novedades

    Returns:
        int: Cantidad de registros interpretados
    """
    archivo_split = archivo.split("_")
    runid = archivo_split[0] + "_" + archivo_split[1]

    cant_registros = predict.predict(runid=runid)
    logger.info(
        "Cantidad de registros interpretados: %s",
        cant_registros,
    )

    output_path = str(config.DATA_OUTPUT_DIR.joinpath(runid))
    utils.comprimir_directorio(archivo_comprimido=output_path, directorio=output_path)
    data.upload_log()
    data.upload_data()

    return cant_registros


if __name__ == "__main__":  # pragma: no cover
    app()
