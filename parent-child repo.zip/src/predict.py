"""utilidades de procesamiento"""

# Importamos para hacer el log del proceso de DS
import logging
import os
import sys
import warnings

# import numpy as np
import pandas as pd

from config import config
from src.ds_func import procesa_pad

warnings.filterwarnings("ignore")


def predict(runid: str) -> int:
    """Aunque la funcion se llama predict en este proyecto lo que hacemos
    es interpretar los casos. No hacemos predicciones.
    Para identificar la corrida utilizamos un RUNID unico que estara compuesto
    por un timestamp y un usuario YYYYMMDDhhmmss_usuario@ypf.com
    Entonces la funcion predict recibe ese RUNID y lee los archivos relacionados con esa corrida.

    Args:
        runid (string): id de ejecución formato YYYYMMDDhhmmss_usuario
    Returns:
        Escribe el archivo de salida en la carpeta output
        Escribe el log de ejecución en la carpeta output
    """

    # Crear directorio en output
    os.makedirs(name=config.DATA_OUTPUT_DIR.joinpath(runid), exist_ok=True)

    # Log file
    logfile = config.DATA_OUTPUT_DIR.joinpath(runid).joinpath(runid + ".log")
    formatter = logging.Formatter("%(asctime)s :: %(levelname)s :: %(message)s")
    handler = logging.FileHandler(logfile)
    handler.setFormatter(formatter)
    logger = logging.getLogger("DS_log")
    logger.setLevel(logging.INFO)
    logger.addHandler(handler)

    # Inicia proceso
    logger.info("INICIA PROCESO DE INTERPRETACION")

    # Lectura archivo input
    # Carga de datos desde excel (.xlsx)
    file = config.DATA_INPUT_DIR.joinpath(runid).joinpath("Interpretar.csv")
    logger.info("Lectura de datos desde %s", str(file))
    try:
        data = pd.read_csv(file)
    except (pd.errors.ParserError, IOError, UnicodeDecodeError) as err_read:
        try:
            # Mover a processed
            logger.info("Moviendo archivo de input a processed...")
            file_dest = config.DATA_PROCESSED_DIR.joinpath(runid + "_Interpretar_ERROR.xlsx")
            os.rename(file, file_dest)
            logger.critical(
                "El contenido del archivo %s no es el adecuado.\n%s", str(file), str(err_read)
            )
            sys.exit(1)
        except IOError as err_rename:
            logger.critical(
                "El contenido del archivo %s no es el adecuado.\n"
                "El archivo no pudo ser movido a %s\n%s",
                str(file),
                str(file_dest),
                str(err_rename),
            )
            sys.exit(1)

    # Preparo df de salida
    df_interpretado = pd.DataFrame()

    # Validamos que tenga las columnas necesarias
    ok_columnas = set(config.MODEL_FEATURES["Default"]).issubset(set(data.columns))
    if not ok_columnas:
        logger.info("Moviendo archivo de input a processed...")
        file_dest = config.DATA_PROCESSED_DIR.joinpath(runid + "_Interpretar_ERROR.xlsx")
        os.rename(file, file_dest)
        logger.critical(
            "El archivo %s no tiene las columnas necesarias \n"
            "FINALIZA PROCESO DE INTERPRETACION DE FORMA ANOMALA",
            str(file),
        )
        sys.exit(1)

    # Proceso archivo input
    # Primer loop por PAD_HIJO
    for pad_hijo in data.PAD_HIJO.unique():
        logger.info("Proceando PAD: %s", pad_hijo)
        # Agrega la interpretación del PADRE al df de salida
        df_interpretado = pd.concat(
            [df_interpretado, procesa_pad(data[data.PAD_HIJO == pad_hijo], pad_hijo)],
            ignore_index=True,
        )

    # Escribe output
    output_file = config.DATA_OUTPUT_DIR.joinpath(runid).joinpath(runid + "_Interpretaciones.xlsx")
    logger.info("Escribe archivo de salida: %s", str(output_file))
    df_interpretado.to_excel(output_file)

    # Mover el archivo de input a processed
    try:
        # Mover a processed
        logger.info("Moviendo archivo de input a processed...")
        file_dest = config.DATA_PROCESSED_DIR.joinpath(runid + "_Interpretar.xlsx")
        os.rename(file, file_dest)
    except IOError as err_rename:
        logger.critical(
            "El archivo %s no pudo ser movido a %s\n%s",
            str(file),
            str(file_dest),
            str(err_rename),
        )
        sys.exit(1)

    # Finaliza proceso
    logger.info("FINALIZA PROCESO DE INTERPRETACION")

    handler.close()
    # logging.shutdown()

    return df_interpretado["PADRE"].count()
