"""utilidades suplementarias"""

import json
import random
import shutil
import warnings
from typing import Dict

import numpy as np

from config.config import logger

warnings.filterwarnings("ignore")


def comprimir_directorio(archivo_comprimido: str, directorio: str) -> bool:
    """Crea un archivo zip con el contenido de un directorio

    Args:
        archivo_comprimido (str): nombre del archivo comprimido de destino
        directorio (str): directorio origen a comprimir

    Returns:
        bool: True si se comprimió correctamente. False caso contrario
    """
    logger.debug("[comprimir_directorio] Inicia")
    logger.info(
        "[comprimir_directorio] \
        Comprimo directorio %s en archivo %s",
        directorio,
        archivo_comprimido,
    )
    try:
        shutil.make_archive(archivo_comprimido, "zip", directorio)
        return True

    except shutil.Error as ex:
        logger.error("[comprimir_directorio] No se pudo comprimir el directorio.")
        logger.error("Error: %s", ex.strerror)
        return False


def load_dict(filepath: str) -> Dict:
    """Cargar un diccionario desde la ruta de archivo de un JSON.
    Args:
        filepath (str): ubicación del archivo.
    Returns:
        Dict: datos JSON cargados.
    """
    with open(filepath, encoding="utf-8") as file_path:
        diccionario = json.load(file_path)
    return diccionario


def save_dict(diccionario: Dict, filepath: str, cls=None, sortkeys: bool = False) -> None:
    """Guardar un diccionario en una ubicación específica.
    Args:
        d (Dict): datos a guardar.
        filepath (str): ubicación de dónde guardar los datos.
        cls (optional): codificador para usar en datos. Valor default es None.
        sortkeys (bool, optional): si ordenar las claves alfabéticamente. Valor default es False.
    """
    with open(filepath, "w", encoding="utf-8") as file_path:
        json.dump(diccionario, indent=2, fp=file_path, cls=cls, sort_keys=sortkeys)


def set_seeds(seed: int = 42) -> None:
    """Setear seeds.
    Args:
        seed (int, optional): número que se utilizará como seed. Valor default es 42.
    """
    # Set seeds
    np.random.seed(seed)
    random.seed(seed)
