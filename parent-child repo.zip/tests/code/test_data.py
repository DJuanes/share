"""utilidades de procesamiento de datos - test"""

import pandas as pd
import numpy as np
import os
from src.shared import pi
import shutil
import pytest
from unittest import mock
from config import config

from src.data import (
    get_presiones,
    run_job_estados,
    run_job_se,
    upload_log,
    upload_data,
    get_tag,
    get_novedades,
    load_pi_webapi,
)


@pytest.fixture
def setup_test_environment(tmp_path):
    # Configura el directorio de entrada de datos simulados
    config.DATA_INPUT_DIR = tmp_path / "input"

    # Copia datos de entrada simulados a tmp_path
    test_input_dir = os.path.join("tests", "code", "test_data", "input")
    shutil.copytree(test_input_dir, config.DATA_INPUT_DIR)

    yield

@pytest.fixture
def mock_blob_download_data_from_blob_storage():
    # Creamos un mock del método blob_storage.download_data_from_blob_storage()
    with mock.patch("src.shared.blob_storage.download_data_from_blob_storage") as mock_download:
        yield mock_download

@pytest.fixture
def mock_blob_upload_data_to_blob_storage():
    # Creamos un mock del método blob_storage.upload_data_to_blob_storage()
    with mock.patch("src.shared.blob_storage.upload_data_to_blob_storage") as mock_upload:
        yield mock_upload

@pytest.fixture
def mock_blob_upload_log_to_blob_storage():
    # Creamos un mock del método blob_storage.upload_log_to_blob_storage()
    with mock.patch("src.shared.blob_storage.upload_log_to_blob_storage") as mock_upload:
        yield mock_upload

@pytest.fixture
def mock_pi_webapi(monkeypatch):
    # Creamos un mock de la clase pi.PiWebapi
    class MockPiWebapi:
        def __init__(self, *args, **kwargs):
            self.webapi_url = "https://swpnqntaspi23.grupo.ypf.com/piwebapi"
            self.path = "swpnqntaspi11"
            self.webapi_security_method = "basic"
            self.verify_ssl = False
            self.webapi_user = os.environ.get("PI_WEB_API_USER")
            self.webapi_password = os.environ.get("PI_WEB_API_PASSWORD")
            pass

        def call_security_method(self):
            return "fake_security_auth"

        def generate_webid_from_path(self, path):
            return "P1AbEU1dQTlFOVEFTUEkxMVxZUEYuTlEuU09JTC0yNTIoSClfUFQ6Q0FCRVpBLlBW"

        def get_summary_data(self, security_auth, webid, start_time, end_time, summary_type, duration):
            # Devolvemos un conjunto de datos predefinido para pruebas
            data = {}
            data[0] = [
                {"Value.Timestamp": "2022-03-20T11:59:00Z", "Value.Value": 23.257789124534625, "Value.Errors": "nan"},
                {"Value.Timestamp": "2022-03-20T12:04:00Z", "Value.Value": 23.258218790836835, "Value.Errors": "nan"},
                {"Value.Timestamp": "2022-03-20T12:09:00Z", "Value.Value": 23.258648457139046, "Value.Errors": "nan"},
            ]
            return (200, data)

    # Hacemos que la función get_presiones() use nuestro MockPiWebapi en lugar de la original
    monkeypatch.setattr("src.data.pi.PiWebapi", MockPiWebapi)

@pytest.fixture
def mock_cmlapi_default_client():
    # Creamos un mock del método cmlapi.default_client()
    with mock.patch("src.data.cmlapi.default_client") as mock_client:
        yield mock_client

@pytest.fixture
def mock_read_excel():
    # Creamos un mock del método pd.read_excel()
    with mock.patch("src.data.pd.read_excel") as mock_excel:
        yield mock_excel

@pytest.fixture
def mock_read_csv():
    # Creamos un mock del método pd.read_csv()
    with mock.patch("src.data.pd.read_csv") as mock_csv:
        yield mock_csv

@pytest.fixture
def mock_to_csv():
    # Creamos un mock del método pd.to_csv()
    with mock.patch("src.data.pd.DataFrame.to_csv") as mock_to_csv:
        yield mock_to_csv

def test_get_tag():
    # Prueba una asignación válida
    assert get_tag("PA", "POZO123") == "POZO123(PL)_PT:CABEZA.PV"
    # Prueba una asignación inválida
    assert get_tag("INVALIDO", "POZO456") == "POZO456_PT:CABEZA.PV"

def test_get_presiones(
    mock_read_excel,
    mock_blob_download_data_from_blob_storage,
    mock_blob_upload_data_to_blob_storage,
    mock_pi_webapi,
    mock_to_csv
    ):
    # Mock para pandas.read_excel para devolver los datos de prueba
    mock_read_excel.return_value = pd.DataFrame({
        "PAD_HIJO": ["LACh_PAD-124"],
        "PADRE": ["YPF.Nq.LACh-93(h)"],
        "INICIO_FRAC": ["2022-03-27 08:59:00"],
        "FIN_FRAC": ["2022-04-10 13:38:00"],
    })

    # Configuramos el mock para que blob.download_data_from_blob_storage() no haga nada
    mock_blob_download_data_from_blob_storage.return_value = None

    df_novedades = pd.DataFrame({
        "ID_EVENTO": ["1001"],
        "PAD": ["PAD001"],
        "POZO": ["POZO123"],
        "INICIO": ["2023-01-01T00:00:00Z"],
        "FIN": ["2023-01-01T00:00:00Z"],
        "SE_COD": ["FA"]
    })

    runid = "20230101120000"

    # Llamamos a la función que queremos probar
    result = get_presiones(df_novedades, runid)

    # Comprobamos que la función devuelve un int
    assert isinstance(result, int)

    # Comprobamos que la función devuelve un solo registro
    assert result == 1


def test_run_job_estados(mock_read_csv, mock_cmlapi_default_client, mock_blob_download_data_from_blob_storage):
    # Mock para pandas.read_csv para devolver los datos de prueba
    mock_read_csv.return_value = pd.DataFrame({
        "PADRE": ["YPF.Nq.LACh-95(h)", "YPF.Nq.LACh-95(h)"],
        "UWI": ["AR0300021359", "AR0300021359"],
        "FECHA": ["2022-03-30", "2022-03-31"],
        "HORAS_DE_PARO": [7, 24],
    })

    # Configuramos el mock de cmlapi.default_client() para que devuelva un cliente mock
    mock_api_client = mock.MagicMock()
    mock_cmlapi_default_client.return_value = mock_api_client

    # Configuramos el mock para que la respuesta de la API de cmlapi tenga el estado correcto
    mock_job_run_response = mock.MagicMock()
    mock_job_run_response.status = "ENGINE_SUCCEEDED"
    mock_api_client.get_job_run.return_value = mock_job_run_response

    # Configuramos el mock para que blob.download_data_from_blob_storage() no haga nada
    mock_blob_download_data_from_blob_storage.return_value = None

    # Llamamos a la función que queremos probar
    result = run_job_estados("runid")

    # Comprobamos que la función devuelve un int
    assert isinstance(result, np.int64)

    # Comprobamos que la función devuelve dos registros
    assert result == 2

    # Verificamos que se haya llamado a cmlapi.default_client() con los argumentos esperados
    mock_cmlapi_default_client.assert_called_once_with(url=mock.ANY, cml_api_key=mock.ANY)

    # Verificamos que se haya llamado a cmlapi.get_job_run() con los argumentos esperados
    mock_api_client.get_job_run.assert_called_once_with(mock.ANY, mock.ANY, mock.ANY)

    # Verificamos que se haya llamado a blob.download_data_from_blob_storage() con los argumentos esperados
    mock_blob_download_data_from_blob_storage.assert_called_once_with(
        storage_account_key=mock.ANY,
        container_name=mock.ANY,
        local_fp=mock.ANY,
        blob_name="runid/Estados.csv",
    )

def test_run_job_se(mock_read_csv, mock_cmlapi_default_client, mock_blob_download_data_from_blob_storage):
    # Mock para pandas.read_csv para devolver los datos de prueba
    mock_read_csv.return_value = pd.DataFrame({
        "PAD": ["LACh_PAD-124"],
        "POZO": ["YPF.Nq.LACh-95(h)"],
        "UWI": ["AR0300021359"],
        "INICIO_SE": ["2021-02-11"],
        "FIN_SE": ["2022-11-12"],
        "INICIO": ["2022-03-20"],
        "FIN": ["2022-04-17"],
        "SE_COD": ["FL"],
    })

    # Configuramos el mock de cmlapi.default_client() para que devuelva un cliente mock
    mock_api_client = mock.MagicMock()
    mock_cmlapi_default_client.return_value = mock_api_client

    # Configuramos el mock para que la respuesta de la API de cmlapi tenga el estado correcto
    mock_job_run_response = mock.MagicMock()
    mock_job_run_response.status = "ENGINE_SUCCEEDED"
    mock_api_client.get_job_run.return_value = mock_job_run_response

    # Configuramos el mock para que blob.download_data_from_blob_storage() no haga nada
    mock_blob_download_data_from_blob_storage.return_value = None

    # Llamamos a la función que queremos probar
    result = run_job_se("runid")

    # Comprobamos que la función devuelve un int
    assert isinstance(result, np.int64)

    # Comprobamos que la función devuelve un registro
    assert result == 1

    # Verificamos que se haya llamado a cmlapi.default_client() con los argumentos esperados
    mock_cmlapi_default_client.assert_called_once_with(url=mock.ANY, cml_api_key=mock.ANY)

    # Verificamos que se haya llamado a cmlapi.get_job_run() con los argumentos esperados
    mock_api_client.get_job_run.assert_called_once_with(mock.ANY, mock.ANY, mock.ANY)

    # Verificamos que se haya llamado a blob.download_data_from_blob_storage() con los argumentos esperados
    mock_blob_download_data_from_blob_storage.assert_called_once_with(
        storage_account_key=mock.ANY,
        container_name=mock.ANY,
        local_fp=mock.ANY,
        blob_name="runid/Novedades_SE.csv",
    )

def test_upload_log(mock_blob_upload_log_to_blob_storage):
    upload_log()
    mock_blob_upload_log_to_blob_storage.assert_called_once()

def test_upload_data(mock_blob_upload_data_to_blob_storage):
    upload_data("runid")
    mock_blob_upload_data_to_blob_storage.assert_called_once()

def test_load_pi_webapi():
    pi_test = load_pi_webapi()
    assert isinstance(pi_test, pi.PiWebapi)

def test_get_novedades(setup_test_environment, tmp_path, mock_blob_download_data_from_blob_storage, mock_blob_upload_data_to_blob_storage):
    runid = "20230919092935_diego.juanes@ypf.com"
    input_file = tmp_path / "input" / f"{runid}_Interpretar.xlsx"
    novedades = tmp_path / "input" / f"{runid}/Interpretar.csv"

    cant = get_novedades(input_file, runid)
    mock_blob_download_data_from_blob_storage.assert_called_once()
    assert novedades.exists()
    assert cant == 2992
