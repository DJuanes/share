"""Workflow principal - test"""

import warnings
from argparse import Namespace
import pytest
from unittest.mock import MagicMock, patch, Mock

import pandas as pd

from src.main import load_artifacts, predict_model, elt_data, DatosInvalidos
from src.data import validate_input, get_presiones, run_job_estados

warnings.filterwarnings("ignore")

@pytest.fixture
def mock_upload_log_to_blob_storage():
    # Creamos un mock del método blob_storage.upload_log_to_blob_storage()
    with patch("src.shared.blob_storage.upload_log_to_blob_storage") as mock_upload:
        yield mock_upload

@pytest.fixture
def mock_read_csv():
    # Creamos un mock del método pd.read_csv()
    with patch("src.main.pd.read_csv") as mock_csv:
        yield mock_csv

# Simular el objeto 'tracer' y el contexto de 'trace' para las pruebas
class MockSpan(Mock):
    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

class MockTracer:
    def start_as_current_span(self, *args, **kwargs):
        return MockSpan()

tracer = MockTracer()


def test_elt_data(mocker, mock_read_csv):
    # Mock para pandas.read_csv para devolver los datos de prueba
    mock_read_csv.return_value = pd.DataFrame({
        "PAD": ["LACh_PAD-124"],
        "POZO": ["YPF.Nq.LACh-95(h)"],
        "UWI": ["AR0300021359"],
        "INICIO_SE": ["2021-02-11"],
        "FIN_SE": ["2022-11-12"],
        "INICIO": ["2022-03-20"],
        "FIN": ["2022-04-17"],
        "SE_COD": ["FL"],
    })

    mocker.patch('src.main.data.get_novedades')
    mocker.patch('src.main.os.makedirs')
    mocker.patch('src.main.tracer', tracer)
    mocker.patch('src.main.open')
    mocker.patch('src.main.data.upload_log')
    mocker.patch('src.main.data.upload_data')
    mock_get_presiones = mocker.patch('src.main.data.get_presiones')
    mock_run_job_estados = mocker.patch('src.main.data.run_job_estados')
    mock_run_job_se = mocker.patch('src.main.data.run_job_se')

    mock_get_presiones.return_value = 5
    mock_run_job_estados.return_value = 10
    mock_run_job_se.return_value = 2

    result = elt_data("20230824110000_diego.juanes@ypf.com_archivo.xlsx")

    assert result == (5, 10, 2)
    mock_get_presiones.assert_called_once_with(df_novedades=mock_read_csv.return_value, runid="20230824110000_diego.juanes@ypf.com")
    mock_run_job_estados.assert_called_once_with(runid="20230824110000_diego.juanes@ypf.com")
    mock_run_job_se.assert_called_once_with(runid="20230824110000_diego.juanes@ypf.com")


def test_load_artifacts():
    # Arrange
    expectedResult = {
        "args": Namespace(),
        "model": {},
        "performance": {},
    }

    # Act
    result = load_artifacts()

    # Assert
    assert result.keys() == expectedResult.keys()
    assert isinstance(result["args"], Namespace)
    assert isinstance(result["model"], dict)
    assert isinstance(result["performance"], dict)
