"""Módulo de funciones para interactuar con PI - test"""

from unittest.mock import Mock
import pytest
from src.shared.pi import PiWebapi
import requests

# Fixture para simular el objeto de respuesta HTTP
@pytest.fixture
def mock_response():
    response = Mock()
    response.status_code = 200
    response.text = '{"key": "value"}'
    return response

# Fixture para simular la autenticación básica
@pytest.fixture
def mock_basic_auth():
    return ("username", "password")

# Prueba para la función generate_webid_from_path
def test_generate_webid_from_path():
    pi = PiWebapi("webapi_url", "path", "basic", True, "user", "pass")
    webid = pi.generate_webid_from_path("test_path")
    assert isinstance(webid, str)
    assert webid.startswith("P1AbE")

# Prueba para la función call_security_method con autenticación básica
def test_call_security_method_with_basic_auth():
    pi = PiWebapi("webapi_url", "path", "basic", True, "user", "pass")
    security_auth = pi.call_security_method()
    assert security_auth is not None
    assert security_auth.username == "user"
    assert security_auth.password == "pass"

# Prueba para la función call_security_method con autenticación Kerberos
def test_call_security_method_with_kerberos_auth():
    pi = PiWebapi("webapi_url", "path", "kerberos", True, "user", "pass")
    security_auth = pi.call_security_method()
    assert security_auth is None

# Prueba para la función get_summary_data exitosa
def test_get_summary_data_success(mock_response, mock_basic_auth, mocker):
    mocker.patch("requests.get", return_value=mock_response)
    pi = PiWebapi("webapi_url", "path", "basic", True, "user", "pass")
    status, data = pi.get_summary_data(mock_basic_auth, "webid")

    assert status == 200
    assert isinstance(data, dict)
    assert "key" in data

# Prueba para la función get_summary_data no exitosa
def test_get_summary_data_failed(mock_response, mock_basic_auth, mocker):
    mocker.patch("requests.get", return_value=mock_response)
    pi = PiWebapi("webapi_url", "path", "basic", True, "user", "pass")
    # Simula una respuesta no exitosa
    mock_response.status_code = 404
    status, data = pi.get_summary_data(mock_basic_auth, "webid")

    assert status == 404
    assert data == ""

# Prueba para la función get_summary_data con exception
def test_get_summary_data_exception(mock_response, mock_basic_auth, mocker):
    # Simula una excepción
    mocker.patch("requests.get", return_value=mock_response, side_effect=requests.RequestException)
    pi = PiWebapi("webapi_url", "path", "basic", True, "user", "pass")
    status, data = pi.get_summary_data(mock_basic_auth, "webid")

    assert status == 0
    assert data == ""

# Prueba para la función get_recorded_data exitosa
def test_get_recorded_data_success(mock_response, mock_basic_auth, mocker):
    mocker.patch("requests.get", return_value=mock_response)
    pi = PiWebapi("webapi_url", "path", "basic", True, "user", "pass")
    status, data = pi.get_recorded_data(mock_basic_auth, "webid")

    assert status == 200
    assert isinstance(data, dict)
    assert "key" in data

# Prueba para la función get_recorded_data no exitosa
def test_get_recorded_data_failed(mock_response, mock_basic_auth, mocker):
    mocker.patch("requests.get", return_value=mock_response)
    pi = PiWebapi("webapi_url", "path", "basic", True, "user", "pass")
    # Simula una respuesta no exitosa
    mock_response.status_code = 404
    status, data = pi.get_recorded_data(mock_basic_auth, "webid")

    assert status == 404
    assert data == ""

# Prueba para la función get_recorded_data con exception
def test_get_recorded_data_exception(mock_response, mock_basic_auth, mocker):
    # Simula una excepción
    mocker.patch("requests.get", return_value=mock_response, side_effect=requests.RequestException)
    pi = PiWebapi("webapi_url", "path", "basic", True, "user", "pass")
    status, data = pi.get_recorded_data(mock_basic_auth, "webid")

    assert status == 0
    assert data == ""
