"""utilidades de procesamiento - test"""

import os
import pytest
import shutil
import pandas as pd
from src.predict import predict
from config import config

@pytest.fixture
def setup_test_environment(tmp_path):
    # Configura el directorio de salida de datos para las pruebas
    config.DATA_OUTPUT_DIR = tmp_path / "output"
    config.DATA_OUTPUT_DIR.mkdir()

    # Configura el directorio de entrada de datos simulados
    config.DATA_INPUT_DIR = tmp_path / "input"

    # Configura el directorio de los archivos procesados para las pruebas
    config.DATA_PROCESSED_DIR = tmp_path / "processed"
    config.DATA_PROCESSED_DIR.mkdir()

    # Copia datos de entrada simulados a tmp_path
    test_input_dir = os.path.join("tests", "code", "test_data", "input")
    shutil.copytree(test_input_dir, config.DATA_INPUT_DIR)

    yield

def test_predict_successful(setup_test_environment, tmp_path):
    # Prueba la función predict con datos de entrada válidos
    runid = "20230919092932_diego.juanes@ypf.com"
    input_file = tmp_path / "input" / f"{runid}/Interpretar.csv"
    output_file = tmp_path / "output" / f"{runid}/{runid}_Interpretaciones.xlsx"
    processed_err_file = tmp_path / "processed" / f"{runid}_Interpretar_ERROR.xlsx"

    result = predict(runid)

    assert output_file.exists()
    assert result > 0
    assert not processed_err_file.exists()

def test_predict_input_invalido(setup_test_environment, tmp_path):
    # Prueba la función predict con un archivo de entrada inválido
    runid = "20230919092933_diego.juanes@ypf.com"
    input_file = tmp_path / "input" / f"{runid}/Interpretar.csv"
    output_file = tmp_path / "output" / f"{runid}/{runid}_Interpretaciones.xlsx"
    processed_err_file = tmp_path / "processed" / f"{runid}_Interpretar_ERROR.xlsx"

    with pytest.raises(SystemExit) as e:
        predict(runid)

    assert not output_file.exists()
    assert processed_err_file.exists()

def test_predict_columna_faltante(setup_test_environment, tmp_path):
    # Prueba la función predict con un archivo de entrada que falta de columnas necesarias
    runid = "20230919092934_diego.juanes@ypf.com"
    input_file = tmp_path / "input" / f"{runid}/Interpretar.csv"
    output_file = tmp_path / "output" / f"{runid}/{runid}_Interpretaciones.xlsx"
    processed_err_file = tmp_path / "processed" / f"{runid}_Interpretar_ERROR.xlsx"

    with pytest.raises(SystemExit) as e:
        predict(runid)

    assert not output_file.exists()
    assert processed_err_file.exists()
