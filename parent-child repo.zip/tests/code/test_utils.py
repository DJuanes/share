"""utilidades suplementarias - test"""

import tempfile
import warnings
from pathlib import Path
import os
import zipfile

import numpy as np

from src.shared import utils

warnings.filterwarnings("ignore")


def test_save_and_load_dict():
    with tempfile.TemporaryDirectory() as dp:
        d = {"hello": "world"}
        fp = Path(dp, "d.json")
        utils.save_dict(diccionario=d, filepath=fp)
        d = utils.load_dict(filepath=fp)
        assert d["hello"] == "world"


def test_set_seed():
    utils.set_seeds()
    a = np.random.randn(2, 3)
    b = np.random.randn(2, 3)
    utils.set_seeds()
    x = np.random.randn(2, 3)
    y = np.random.randn(2, 3)
    assert np.array_equal(a, x)
    assert np.array_equal(b, y)


def test_comprimir_directorio_correctamente():
    # Crear un directorio temporal y agregar algunos archivos ficticios
    with tempfile.TemporaryDirectory() as temp_dir:
        for i in range(5):
            with open(os.path.join(temp_dir, f"archivo{i}.txt"), "w") as f:
                f.write(f"Contenido del archivo {i}")

        # Llamar a la función a probar
        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as temp_zip:
            archivo_comprimido = os.path.splitext(temp_zip.name)[0]
        resultado = utils.comprimir_directorio(archivo_comprimido, temp_dir)
        archivo_comprimido = archivo_comprimido + ".zip"

        # Verificar que el resultado sea True (comprimió correctamente)
        assert resultado is True

        # Verificar que el archivo comprimido existe
        assert os.path.exists(archivo_comprimido)

        # Verificar que el archivo comprimido es un archivo zip válido
        try:
            with zipfile.ZipFile(archivo_comprimido) as zip_file:
                assert len(zip_file.namelist()) == 5
        except zipfile.BadZipFile:
            assert False, "El archivo comprimido no es un archivo ZIP válido."


def test_comprimir_directorio_error():
    # Intentar comprimir un directorio inexistente
    with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as temp_zip:
        archivo_comprimido = os.path.splitext(temp_zip.name)[0]

    with tempfile.TemporaryDirectory() as temp_dir:
        directorio_inexistente = os.path.join(temp_dir, "directorio_inexistente")
        resultado = False
        try:
            resultado = utils.comprimir_directorio(archivo_comprimido, directorio_inexistente)
        except:
            pass

        archivo_comprimido = archivo_comprimido + ".zip"

        # Verificar que el resultado sea False (no se pudo comprimir)
        assert resultado is False

        # Verificar que el archivo comprimido no es un archivo zip válido
        try:
            with zipfile.ZipFile(archivo_comprimido) as zip_file:
                assert len(zip_file.namelist()) == 5
        except zipfile.BadZipFile:
            assert True, "El archivo comprimido no es un archivo ZIP válido."
