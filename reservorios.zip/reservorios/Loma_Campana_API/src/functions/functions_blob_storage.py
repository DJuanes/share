import logging as log
import traceback
from io import StringIO

import pandas
from azure.storage.blob import BlobClient, BlobServiceClient, ContainerClient

blobServiceClient = ""
containerClient = ""
blobClient = ""
cfgs = {}

##---------------------------------------------------------------------------##
## instanciar_cliente_blobService - se instancia el cliente del servicio blob storage
## Parámetros :
##    - connection_string: URI del storage account
## Retorno :
##    - Instancia cliente del servicio blob storage
##---------------------------------------------------------------------------##
def instanciar_cliente_blobService(connection_string):
    global blobServiceClient
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[instanciar_cliente_blobService] Inicia")

    try:
        # Instancia un BlobServiceClient usando un connection string
        blobServiceClient = BlobServiceClient.from_connection_string(connection_string)

        p_logger.debug("[instanciar_cliente_blobService] Finaliza")
        return blobServiceClient
    except Exception as e:
        p_logger.critical(
            "[instanciar_cliente_blobService] Hubo un error al intentar instanciar el cliente del servicio Blob Storage"
        )
        p_logger.critical(e)
        return e


##---------------------------------------------------------------------------##
## instanciar_cliente_container - se instancia el cliente del container
## Parámetros :
##    - container_name: nombre del container
## Retorno :
##    - Instancia cliente del container
##---------------------------------------------------------------------------##
def instanciar_cliente_container(container_name):
    global containerClient
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[instanciar_cliente_container] Inicia")

    # Crea cliente blob
    try:
        # Instancia un ContainerClient
        containerClient = blobServiceClient.get_container_client(container_name)

        p_logger.debug("[instanciar_cliente_container] Finaliza")
        return containerClient
    except Exception as e:
        p_logger.critical(
            "[instanciar_cliente_container] Hubo un error al intentar instanciar el cliente del container"
        )
        p_logger.critical(e)
        return e


##---------------------------------------------------------------------------##
## instanciar_cliente_blob - se instancia el cliente del blob
## Parámetros :
##    - blob_name: nombre del archivo
## Retorno :
##    - Instancia cliente del blob
##---------------------------------------------------------------------------##
def instanciar_cliente_blob(blob_name):
    global blobClient
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[instanciar_cliente_blob] Inicia")

    try:
        # Instancia un BlobClient
        blobClient = containerClient.get_blob_client(blob_name)

        p_logger.debug("[instanciar_cliente_blob] Finaliza")
        return blobServiceClient
    except Exception as e:
        p_logger.critical(
            "[instanciar_cliente_blob] Hubo un error al intentar instanciar el cliente del blob"
        )
        p_logger.critical(e)
        return e


##---------------------------------------------------------------------------##
## borrar_blob - elimina un archivo
## Parámetros :
## Retorno :
##    - True si el archivo se eliminó correctamente
##    - False si hubo problemas al eliminar el archivo
##---------------------------------------------------------------------------##
def borrar_blob():
    p_logger = log.getLogger(cfgs["logger_name"])
    try:
        p_logger.debug(
            "[borrar_blob] Inicia el borrado del archivo en el blob storage."
        )
        blobClient.delete_blob()
        p_logger.debug(
            "[borrar_blob] Finaliza el borrado del archivo en el blob storage."
        )
        return True
    except:
        p_logger.error(f"""[borrar_blob] No se pudo borrar el archivo.""")
        p_logger.error(f"""Error : {traceback.format_exc()}""")
        return False


##---------------------------------------------------------------------------##
## borrar_blobs - elimina los archivos indicados
## Parámetros :
##    - blob_list: lista de archivos
## Retorno :
##    - True si los archivos se eliminaron correctamente
##    - False si hubo problemas al eliminar los archivos
##---------------------------------------------------------------------------##
def borrar_blobs(blob_list):
    p_logger = log.getLogger(cfgs["logger_name"])
    try:
        p_logger.debug(
            "[borrar_blobs] Inicia el borrado de archivos en el blob storage."
        )
        p_logger.debug(f"""[borrar_blobs] blob_list: {blob_list}.""")
        containerClient.delete_blobs(*blob_list)
        p_logger.debug(
            "[borrar_blobs] Finaliza el borrado de archivos en el blob storage."
        )
        return True
    except:
        p_logger.error(
            f"""[borrar_blobs] No se pudo borrar los archivos {blob_list}."""
        )
        p_logger.error(f"""Error : {traceback.format_exc()}""")
        return False


##---------------------------------------------------------------------------##
## obtener_lista_blobs - obtiene el listado de todos los blobs de un container
## Retorno :
##    - Listado con los blobs del container
##---------------------------------------------------------------------------##
def obtener_lista_blobs():
    p_logger = log.getLogger(cfgs["logger_name"])
    p_logger.debug("[obtener_lista_blobs] Inicia")
    try:
        blob_list = containerClient.list_blobs()
        p_logger.debug("[obtener_lista_blobs] Finaliza")
        return blob_list
    except Exception as e:
        p_logger.error(
            "[obtener_lista_blobs] Hubo un error al intentar obtener la lista de blobs"
        )
        p_logger.error(e)
        return []


##---------------------------------------------------------------------------##
## download_blob_toPandas - descarga un archivo del blob storage
## Parámetros :
##    - header: True si tiene cabecera, None si no tiene cabecera
## Retorno :
##    - df con el contenido del archivo
##---------------------------------------------------------------------------##
def download_blob_toPandas(header=True):
    p_logger = log.getLogger(cfgs["logger_name"])
    try:
        p_logger.debug(
            "[download_blob_toPandas] Inicia descarga del archivo del blob storage."
        )
        blobstring = (
            blobClient.download_blob().readall().decode("utf-8")
        )  # read blob content as string
        if header:
            df = pandas.read_csv(StringIO(blobstring))
        else:
            df = pandas.read_csv(StringIO(blobstring), header=header)
        p_logger.debug(
            "[download_blob_toPandas] Finaliza descarga del archivo del blob storage."
        )
        return df
    except:
        p_logger.error(f"""[download_blob_toPandas] No se pudo descargar el archivo.""")
        p_logger.error(f"""Error : {traceback.format_exc()}""")
        return pandas.DataFrame()


##---------------------------------------------------------------------------##
## upload_blob_fromPandas - escribe un df en el blob storage
## Parámetros :
##    - datos: contenido del archivo a subir
##    - index: True para escribir con index, False para escribir sin index
## Retorno :
##    - True si el archivo se subio correctamente
##    - False si hubo problemas al subir el archivo
##---------------------------------------------------------------------------##
def upload_blob_fromPandas(datos, index=True):
    p_logger = log.getLogger(cfgs["logger_name"])
    try:
        p_logger.debug(
            "[upload_blob_fromPandas] Inicia escritura del archivo en el blob storage."
        )
        if index:
            output = datos.to_csv()
        else:
            output = datos.to_csv(index=False)
        blobClient.upload_blob(output)
        p_logger.debug("[upload_blob_fromPandas] Finaliza escritura del archivo.")
        return True
    except:
        p_logger.error(f"""[upload_blob_fromPandas] No se pudo subir el archivo.""")
        p_logger.error(f"""Error : {traceback.format_exc()}""")
        return False


##---------------------------------------------------------------------------##
## download_blob_toFile - descarga un archivo del blob storage
## Parámetros :
##    - file_path: path del archivo a bajar (destino)
## Retorno :
##    - True si el archivo se bajo correctamente
##    - False si hubo problemas al bajar el archivo
##---------------------------------------------------------------------------##
def download_blob_toFile(file_path):
    p_logger = log.getLogger(cfgs["logger_name"])
    try:
        p_logger.debug(
            "[download_blob_toFile] Inicia descarga del archivo del blob storage."
        )
        with open(file_path, "wb") as download_file:
            download_file.write(blobClient.download_blob().readall())
        p_logger.debug(
            "[download_blob_toFile] Finaliza descarga del archivo del blob storage."
        )
        return True
    except:
        p_logger.error(f"""[download_blob_toFile] No se pudo obtener el archivo.""")
        p_logger.error(f"""Error : {traceback.format_exc()}""")
        return False


##---------------------------------------------------------------------------##
## upload_blob_fromFile - sube un archivo al blob storage
## Parámetros :
##    - file_path: path del archivo a subir (origen)
## Retorno :
##    - True si el archivo se subió correctamente
##    - False si hubo problemas al subir el archivo
##---------------------------------------------------------------------------##
def upload_blob_fromFile(file_path):
    p_logger = log.getLogger(cfgs["logger_name"])
    try:
        p_logger.debug(
            "[upload_blob_fromFile] Inicia subida del archivo en el blob storage."
        )
        with open(file_path, "rb") as data:
            blobClient.upload_blob(data, overwrite=True)
        p_logger.debug(
            "[upload_blob_fromFile] Finaliza subida del archivo en el blob storage."
        )
        return True
    except:
        p_logger.error(
            f"""[upload_blob_fromFile] No se pudo subir el archivo {file_path}."""
        )
        p_logger.error(f"""Error : {traceback.format_exc()}""")
        return False


##---------------------------------------------------------------------------##
## copiar_blob - copia un archivo del blob storage con otro
## nombre, dentro del mismo container
## Parámetros :
##    - source_blob: el blob origen
## Retorno :
##    - True si el archivo se copió correctamente
##    - False si hubo problemas al copiar el archivo
##---------------------------------------------------------------------------##
def copiar_blob(source_blob):
    p_logger = log.getLogger(cfgs["logger_name"])
    try:
        p_logger.debug(
            "[copiar_blob] Inicia el copiado del archivo en el blob storage."
        )
        # blob_url = blob.make_blob_url(container_name, path_origen)
        blobClient.start_copy_from_url(source_blob)
        p_logger.debug(
            "[copiar_blob] Finaliza el copiado del archivo en el blob storage."
        )
        return True
    except:
        p_logger.error(f"""[copiar_blob] No se pudo copiar el archivo.""")
        p_logger.error(f"""Error : {traceback.format_exc()}""")
        return False
