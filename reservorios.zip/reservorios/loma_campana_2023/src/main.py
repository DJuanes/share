"""Workflow principal"""

import json
import os
import sys
import tempfile
import warnings
from argparse import Namespace
from pathlib import Path
from typing import Dict, List

import joblib
import optuna
import pandas as pd
import typer

from config import config
from config.config import logger
from src import data, predict, train, utils

warnings.filterwarnings("ignore")

# Inicializar la aplicación CLI de Typer
app = typer.Typer()


@app.command()
def elt_data():
    """Extraer, cargar y transformar nuestros activos de datos."""
    # Extract + Load

    # Transform

    logger.info("Datos guardados!")


@app.command()
def train_model(
    args_fp: str = "config/args.json",
    experiment_name: str = "baselines",
    run_name: str = "sgd",
) -> None:
    """Entrenar un modelo con argumentos dados.
    Args:
        args_fp (str): ubicación de args.
        experiment_name (str): nombre del experimento.
        run_name (str): nombre de la ejecución específica en el experimento.
    """
    # Cargar datos etiquetados

    # Entrenar
    # Logeo de métricas y parámetros
    # Logeo de artifacts

    # Guardar en config


@app.command()
def optimize(
    args_fp: str = "config/args.json", study_name: str = "optimization", num_trials: int = 20
) -> None:
    """Optimizar hiperparámetros.
    Args:
        args_fp (str): ubicación de args.
        study_name (str): nombre del estudio de optimización.
        num_trials (int): número de ensayos a ejecutar en el estudio.
    """
    # Cargar datos etiquetados

    # Optimizar

    # Mejor prueba


def load_artifacts() -> Dict:
    """
    Cargar artefactos para la predicción.

    Returns:
        Dict: artefactos de ejecución.
    """
    # Cargar objetos desde la ejecución
    args = Namespace(**utils.load_dict(filepath=Path(artifacts_dir, "args.json")))
    artifacts_dir = config.MODELS_DIR
    logger.info("artifacts dir: %s", artifacts_dir)
    models = {}
    for modelo in config.MODELOS:
        model_fp = artifacts_dir.joinpath(config.MODELOS[modelo])
        models[modelo] = joblib.load(model_fp)
        logger.info("Carga modelo %s", config.MODELOS[modelo])

    performance = utils.load_dict(filepath=Path(artifacts_dir, "performance.json"))

    return {
        "args": args,
        "model": models,
        "performance": performance,
    }


@app.command()
def predict_model(archivo: str) -> None:
    """Predecir etiqueta para texto.
    Args:
        text (str): texto de entrada para predecir la etiqueta.
        run_id (str, optional): run id para cargar artefactos para la predicción.
                                Valor default es None.
    """
    artifacts = load_artifacts()

    os.makedirs(config.DATA_OUTPUT_DIR.joinpath(archivo), exist_ok=True)

    input_fp = config.DATA_INPUT_DIR.joinpath(archivo)
    output_fp = config.DATA_PROCESSED_DIR.joinpath(archivo + "_predecir.csv")
    try:
        data = pd.read_csv(input_fp)
        try:
            data = data.set_index("Pozo")
        except:
            logger.warning(
                "El archivo de entrada no tiene id de Pozo. Se asigna un ID secuencial de 0 a n"
            )
            data.index.name = "Pozo"
    except Exception as e:
        try:
            # Mover a processed
            logger.info("Moviendo archivo de input a processed...")
            os.rename(input_fp, output_fp)
            logger.critical(
                "El contenido del archivo " + archivo + " no es el adecuado.\n" + str(e)
            )
            sys.exit(1)
        except Exception as e:
            logger.critical(
                "El contenido del archivo "
                + archivo
                + " no es el adecuado. \n El archivo no pudo ser movido a "
                + output_fp
                + "\n"
                + str(e)
            )
            sys.exit(1)

    # Predice Organico?
    features_organico = config.MODEL_FEATURES["ORGANICOMODELVARS"]
    ok_organico = set(features_organico).issubset(set(data.columns))
    logger.info("Columnas Orgánico? " + str(ok_organico))
    # Predice Cocina?
    features_cocina = config.MODEL_FEATURES["COCINAMODELVARS"]
    ok_cocina = set(features_cocina).issubset(set(data.columns))
    logger.info("Columnas Cocina? " + str(ok_cocina))

    if ok_organico:
        modelo = artifacts["model"]
        data = features_organico

    if ok_cocina:
        modelo = artifacts["model"]
        data = features_cocina

    predict.predict(model=modelo, data=data)

    # Mover a processed
    logger.info("Moviendo archivo de input a processed...")
    os.rename(input_fp, output_fp)

    # FINALIZA PROCESO
    logger.info("FIN PROCESO :" + archivo)


if __name__ == "__main__":
    app()  # pragma: aplicación en vivo
