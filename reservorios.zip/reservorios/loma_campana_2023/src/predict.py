"""utilidades de inferencia"""

import joblib
import shap


def predict(model, data):
    """_summary_

    Args:
        model (_type_): _description_
        data (_type_): _description_

    Returns:
        _type_: _description_
    """
    # Carga modelo
    fited_model = joblib.load(model)
    # Prediccion
    pred_y = fited_model.predict(data)

    # Generacion de SHAP values
    # Creo el explainer. En versiones anteriores se usaba TreeExplainer o algunos otros pero ahora cambió
    explainer = shap.Explainer(fited_model)
    shap_values = explainer(data)

    return pred_y, shap_values
