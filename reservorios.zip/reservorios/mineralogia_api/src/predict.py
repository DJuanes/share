"""utilidades de inferencia"""

import logging
from typing import Dict

import numpy as np
import pandas as pd
from scipy.optimize import minimize

import model_with_IC


def predict_model_mineral(model: model_with_IC, data: pd.DataFrame, objetivo: str):
    """
    Predecir el perfil sinteticos con el intervalo de confianza para un mineral

    Args:
        model (model_with_IC): clase que tiene el modelo entrenado con los intervalos de confianza.
        data (pd.DataFrame): dataframe con las columnas de features para realizar predicción.
        objetivo (str): nombre del mineral a predecir.
    """
    # Loggers
    lognames = "DS_log.predict"
    loggers = logging.getLogger(lognames)

    # predicción
    loggers.info("Ejecutando predicción del modelo %s.", objetivo)
    df_result = model.predict(data)
    df_result[df_result < 0] = 0
    loggers.info("Finaliza predicción del modelo %s.", objetivo)
    return df_result


def objective(x: tuple, obs: tuple, rmse: tuple):
    """_summary_: función que calcula la suma de las diferencias al cuadrado del dato propuesto
    y la salida del modelo, pesado por el error rmse del modelo.

    Args:
        x (tuple): valores propuestos por el optimizados
        obs (tuple): valores a reconciliar (args[0] del minimize)
        rmse (tuple): rmse de los modelos (args[1] del minimize)

    Returns:
        suma (float): suma a minimizar
    """
    suma: float = 0.0
    for i, j in enumerate(x):
        suma += (j - obs[i]) ** 2 / rmse[i]
    return suma


def constraint(x):
    """Constraint: suma de los valores propuestos debe ser 1.0"""
    return sum(x) - 1.0


def reconciliacion_datos_minimize(
        predicciones: pd.DataFrame,
        objetivos: list,
        rmse: Dict):
    """
    Reconciliar datos para que la suma de los 10 minerales sea igual al 100%.
    Se utiliza el metodo explicado en:
    "https://en.wikipedia.org/wiki/Data_validation_and_reconciliation"
    Se implementa con scipy.minimize

    Args:
        data (pd.DataFrame): dataframe con los minerales predichos por los modelos individuales.
        features (list): lista de los nombres de los minerales.
        rmse (Dict): diccionario con los errores estándar de los modelos de ajuste de lo minerales.
    """
    # Loggers
    lognames = "DS_log.predict"
    loggers = logging.getLogger(lognames)

    # Reconciliación de datos
    loggers.info("Inicia ejecución de reconciliación de datos (método minimize).")

    # se alislan prediciones para filtrar las filas donde se ejecutaron los 10 modelos
    columnas = []
    for mineral in objetivos:
        columnas.append(mineral)
        columnas.append(f"{mineral}_SUP")
        columnas.append(f"{mineral}_INF")
    predicciones = predicciones[columnas].copy()
    predicciones.dropna(inplace=True)

    # si luego del filtrado no hay filas se retorna el dataframe original
    if predicciones.shape[0] == 0:
        loggers.critical("No se puede ejecutar reconciliación de datos. Sin datos luego de \
filtrar las filas donde se ejecutaron todos los modelos.")
        return predicciones

    # se crea dataframe para guardar los datos reconcilidados
    # se usa el index del dataframe predicciones para el merge final
    # la columna "R" final indica si se pudo reconciliar los datos: 0 - False, 1 - True
    columnas = [x + "_R" for x in objetivos] + ["R"]
    reconciliado = pd.DataFrame(columns=columnas)

    # constraint para la suma de los minerales
    cons = {"type": "eq", "fun": constraint}

    # se itera sobre las filas del dataframe y se va realizando la reconciliación
    for index in predicciones.index:
        bounds = []
        obs = []
        rmse_ = []
        for mineral in objetivos:
            obs.append(predicciones.loc[index, mineral])
            bounds.append(
                (
                    predicciones.loc[index, mineral + "_INF"],
                    predicciones.loc[index, mineral + "_SUP"],
                )
            )
            rmse_.append(rmse[mineral])

        res = minimize(
            fun=objective,
            x0=tuple(obs),
            args=(tuple(obs), tuple(rmse_)),
            method="SLSQP",
            bounds=tuple(bounds),
            constraints=cons,
        )
        reconciliado = pd.concat(
            [
                reconciliado,
                pd.DataFrame(
                    columns=columnas,
                    data=np.append(res.x, np.array([res.success])).reshape(1, -1),
                    index=(index,),
                ),
            ],
            axis=0,
        )

    # si es el modelo de 10 minerales
    if len(objetivos) == 10:

        # se agregan los datos reconciliados al dataframe original
        predicciones = predicciones.merge(reconciliado, how='left',
                                          left_index=True, right_index=True)

        # se crea columna con la suma de los minerales para control de calidad
        predicciones['SUMA'] = predicciones[objetivos].sum(axis=1)

        # se eliminan las predicciones originales del modelo
        # se renombran las columnas reconciliadas
        for objetivo in objetivos:
            predicciones.drop(columns=[objetivo], inplace=True)
            predicciones.rename(
                columns={f"{objetivo}_R": objetivo}, inplace=True)

        # se reordenan las columnas de predicciones y se elimina 'R'
        predicciones = predicciones[[x for x in sorted(
            predicciones.columns) if x not in ['R']]]

    else:  # si es el modelo de 6 minerales

        # se renombran las columnas reconciliadas
        columnas = [x[:5] + '_SUM' for x in objetivos] + ['R']
        reconciliado.columns = columnas

        # se agregan los datos reconciliados al dataframe original
        predicciones = predicciones.merge(reconciliado, how='left',
                                          left_index=True, right_index=True)

        # se crea columna con la suma de los minerales para control de calidad
        predicciones['SUMA_SUM'] = predicciones[objetivos].sum(axis=1)

        # se eliminan las predicciones originales del modelo
        # se renombran los intervalos de confianza
        for objetivo in objetivos:
            predicciones.drop(columns=[objetivo], inplace=True)
            predicciones.rename(
                columns={f"{objetivo}_INF": f"{objetivo[:5]}_SUM_INF"}, inplace=True)
            predicciones.rename(
                columns={f"{objetivo}_SUP": f"{objetivo[:5]}_SUM_SUP"}, inplace=True)

        # se reordenan las columnas de predicciones y se elimina 'R'
        predicciones = predicciones[[x for x in sorted(
            predicciones.columns) if x not in ['R']]]

    # Reconciliación de datos
    loggers.info("Finaliza ejecución de reconciliación de datos (método minimize).")
    return predicciones


def reparte_proporcional(vector: np.array, proporciones: np.array, valor_a_repartir: float):
    """
    recibe vector con los valores originales, proporciones que tiene la misma cantidad
    de elementos que vector, una proporción por cada elemento de vector y valor_a_repartir
    es el valor a repartir según las proporciones.
    Reparto el valor_a_repartir en las columnas del vector según proporciones.
    Si alguna columna se vuelve negativa, la pongo en cero y reparto el resto
    en las demas recursivamente. Hasta que no quede nada que repatir.
    No estoy considerando si se pasa del IC INF o SUP, podría ser una mejor a futuro
    que si se sale del intervalo quede en el borde y se reparta en los demas.

    """
    # Si no hay nada que repartir devuelve el mismo vector
    if valor_a_repartir == 0:
        return vector

    a_repartir_proporcional = [prop * valor_a_repartir for prop in proporciones]

    # Se asigna el valor a repartir a cada columna
    valor_a_repartir_2 = 0  # variable donde se guarda lo que sobre a repartir por caso negativo
    for i in range(len(vector)):
        vector[i] += a_repartir_proporcional[i]

        # Si algún valor queda negativo, lo fijamos en cero y repartimos lo sobrante en los demas
        if vector[i] < 0:
            valor_a_repartir_2 += vector[i]
            vector[i] = 0
            # se anulan las proporciones para ese elemento

    # Si sobra alguna proporcion para repartir, se llama recursivamente a la funcion
    if valor_a_repartir_2 < 0:
        # Recalculamos la proporción sin el valor cero porque no puede bajar mas
        # se fija en cero el valor de la proporcion que llegó a cero
        total_sin_cero = sum(p for p in proporciones if p != 0)
        proporciones = [p / total_sin_cero if p != 0 else 0 for p in proporciones]

        # Invoco nuevamente recursivo
        vector = reparte_proporcional(vector, proporciones, valor_a_repartir_2)

    return vector


def ajusta_suma(
    df: pd.DataFrame,
    suma: float = 1,
    modo: str = "directo",  # directo o ponderado
    df_intervalos: pd.DataFrame = None,
):
    """
    Función que realiza el ajuste de la suma los minerales al 100%, usando dos metodos diferentes.
    Uno es pesar por la proporción del mineral y el otro por el rango del Intervalo de Confianza.

    Args:
        df (pd.DataFrame): dataframe con las columnas que deberían sumar la proporción.
        suma (float): valor que deben sumar las columnas.
        modo (str): modo utilizado para repartir las proporciones sobrantes o faltantes
                    modo="directo" reparte las proporciones faltante/sobrante \
                        pesando con las columnas de df.
                    modo="ponderado" reparte las proporciones faltante/sobrante \
                        pesando por el rango del IC.
        df_intervalos (pd.DataFrame): dataframe con los intervalos de confianza de las columnas.
    """

    suma_columnas = df.sum(axis=1)
    valor_a_repartir = suma - suma_columnas

    # Se calculan las proporciones para repartir las diferencias
    # Creamos un nuevo dataframe para guardar las proporciones
    df_proporciones = pd.DataFrame(columns=df.columns)

    # Si el modo es directo se reparte proporcional a las proporciones estimadas
    if modo == "directo" or modo != "ponderado":
        df_proporciones = df.copy()
    # Si el modo es ponderado se calculan las proporciones según el ancho de los IC
    if modo == "ponderado":
        # se calcula la suma de los IC
        # el df_intervalos tiene el intervalo SUP e INF de a pares y en ese orden
        # se recorren las filas y se rentan las columnas de a pares
        for i, row in df_intervalos.iterrows():
            # se inicializa la variable que contendrá la suma de los ICs
            sum_IC = 0
            # armo un array con los espesores de los IC
            ICs = np.empty((0,))
            for j in range(0, len(row), 2):
                # se resta la columna de la derecha (INF) a la columna de la izquierda (SUP)
                IC = row[j] - row[j + 1]
                # se suma el resultado a la variable de suma de IC
                sum_IC += IC
                # se crea una nueva columna con el IC de la variable
                ICs = np.append(ICs, IC)
            # se crea una columna con la suma de las operaciones por fila
            df_proporciones = df_proporciones.append(
                pd.Series(ICs / ICs.sum(), index=df_proporciones.columns), ignore_index=True
            )

    # recorrer todas las filas y columnas del DataFrame y agregar el valor a cada celda
    fila = 0
    for index, row in df.iterrows():
        vector = reparte_proporcional(
            df.loc[index].values, df_proporciones.iloc[fila].values, valor_a_repartir.values[fila]
        )
        # Asigno los nuevos valores
        df.loc[index] = vector
        fila += 1
    return df


def reconciliacion_datos_proporcional(data: pd.DataFrame, objetivos: list):
    """
    Reconciliar datos para que la suma de los 10 minerales sea igual al 100%.
    Se utiliza el metodo de repartir los diferencias pesando por el ancho del intervalo de
    confianza. Si el intervalo de confianza de un mineral es muy ancho, se corrige más ese mineral.

    Args:
        data (pd.DataFrame): dataframe con los minerales predichos por los modelos individuales.
        features (list): lista de los nombres de los minerales.
    """
    # Loggers
    lognames = "DS_log.predict"
    loggers = logging.getLogger(lognames)

    # Reconciliación de datos
    loggers.info("Inicia ejecución de reconciliación de datos (método proporcional).")

    # se alislan prediciones para filtrar las filas donde se ejecutaron los 10 modelos
    columnas_ic = []
    for mineral in objetivos:
        columnas_ic.append(f"{mineral}_SUP")
        columnas_ic.append(f"{mineral}_INF")
    predicciones = data[objetivos + columnas_ic].copy()
    predicciones.dropna(inplace=True)

    # si luego del filtrado no hay filas se retorna el dataframe original
    if predicciones.shape[0] == 0:
        loggers.critical(
            "No se puede ejecutar reconciliación de datos. Sin datos luego de \
filtrar las filas donde se ejecutaron todos los modelos."
        )
        return data

    # se crea dataframe para guardar los datos reconcilidados
    # se usa el index del dataframe predicciones para el merge final
    # la columna "P" final indica si se pudo reconciliar los datos:
    # P = 0 - si el dato reconciliado quedó fuera del intervalo de confianza
    # P = 1 - si el dato reconciliado quedó dentro del intervalo de confianza
    reconciliado = ajusta_suma(
        df=predicciones[objetivos],
        suma=1.0,
        modo="ponderado",
        df_intervalos=predicciones[columnas_ic],
    )

    # se cambia el nombre de las columnas
    reconciliado.columns = [x + "_P" for x in objetivos]

    # se agrega indicador para chequear que la correción no se haya ido fuera del IC
    reconciliado["P"] = 1
    for mineral in objetivos:
        reconciliado.loc[
            (reconciliado[f"{mineral}_P"] < reconciliado[f"{mineral}_INF"])
            | (reconciliado[f"{mineral}_P"] > reconciliado[f"{mineral}_SUP"]),
            "P",
        ] = 0

    # se agregan los datos reconciliados al dataframe original
    data = data.merge(reconciliado, how="left", left_index=True, right_index=True)

    # Reconciliación de datos
    loggers.info("Finaliza ejecución de reconciliación de datos (método proporcional ).")
    return data
